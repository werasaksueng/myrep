// HelloBean.java
package mybeans;
public class HelloBean {
	public String greet(String name) {
		return "Hello! " + name;
	}
}