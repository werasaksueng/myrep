// HelloController.java
package myctl;
import mybeans.*;
import javax.servlet.http.*;
import org.springframework.web.servlet.ModelAndView;
import org.springframework.web.servlet.mvc.AbstractController;
public class HelloController extends AbstractController {
	private HelloBean helloBean;
	public void setHelloBean(HelloBean helloBean) { this.helloBean = helloBean; }
	protected ModelAndView handleRequestInternal(
			HttpServletRequest req,	HttpServletResponse res) throws Exception {
		String name = req.getParameter("name");
		String msg = helloBean.greet(name);
		return new ModelAndView("hellopage",	// logical name of a view
			"greetmsg", msg);		// name, value
	}
}