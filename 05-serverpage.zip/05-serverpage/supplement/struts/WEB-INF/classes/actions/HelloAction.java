// HelloAction.java
package actions;
import org.apache.struts.action.*;
import javax.servlet.http.*;
import beans.HelloForm;
public class HelloAction extends Action {
	public ActionForward execute(ActionMapping mapping,
				ActionForm form,
				HttpServletRequest req,
				HttpServletResponse res) throws Exception {
		
		HelloForm hf = (HelloForm) form;
		String name = hf.getName();
		String password = hf.getPassword();
		if (isCancelled(req)) {
			hf.setName("");
			hf.setPassword("");
			return mapping.findForward("cancel");
		}
		if (name.equals("john") && password.equals("hello"))
			return mapping.findForward("success");
		return mapping.findForward("failure");
	}
}