// MyBean.java
import javax.faces.event.*;
public class MyBean {
	private String name = null;
	public String getName() { return name; }
	public void setName(String name) { this.name = name; }

	private String msg = null;
	public void setMsg(String greetMsg) { this.msg = msg; }
	public String getMsg() { return msg; }

	public String greet() {
		if (name.equals("john"))
			return "john";
		return "notJohn";
	}

	public void doGreet(ActionEvent e) {
		if (name.equals("john"))
			msg = "Hi! " + name;
		else
			msg = "Hello! " + name;
	}
}
/* There are two types of action events, 
	- those that affect navigation. (action methods)
	- those that don't. (action listener methods)

   action methods accept zero parameters and return String 
   action listener methods accept ActionEvent as a parameter and return void
   action listener methods can access the component that fired the event.
   after the action listener method is executed, the page will be redisplayed.
*/