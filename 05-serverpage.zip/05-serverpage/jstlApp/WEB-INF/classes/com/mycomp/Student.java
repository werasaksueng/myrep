package com.mycomp;
public class Student {
	private String id;
	private String name;
	private double gpa;
	public Student(String id, String name, double gpa) {
		this.id = id; this.name = name; this.gpa = gpa;
	}
	public void setId(String id) { this.id = id; }
	public String getId() { return id; }
	public void setName(String name) { this.name = name; }
	public String getName() { return name; }
	public void setGpa(double gpa) { this.gpa = gpa; }
	public double getGpa() { return gpa; }
	public String getComment() {
		if (gpa > 3.5)
			return "Excellent";
		if (gpa > 3.0)
			return "Good";
		if (gpa > 2.0)
			return "So-so";
		if (gpa > 1.0)
			return "Not so good";
		return "Get a new life";
	}
}