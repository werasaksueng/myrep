package com.mycomp;
import java.util.*;
public class MyBean {
	private String names[] = {"john", "jack", "joe"};
	public void setNames(String names[]) { this.names = names; }
	public String[] getNames() { return names; }
}