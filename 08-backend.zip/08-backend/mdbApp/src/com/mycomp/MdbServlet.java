package com.mycomp;
import java.io.*;
import javax.jms.*;
import javax.servlet.ServletException;
import javax.servlet.http.*;
import javax.annotation.Resource;
import javax.servlet.annotation.WebServlet;

@WebServlet("/MdbServlet")
public class MdbServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;

	@Resource(name = "jms/MyConnectionFactory")
	private ConnectionFactory cf;

	@Resource(name = "jms/MyQueue")
	private Queue queue;

	protected void doGet(HttpServletRequest req, HttpServletResponse res) throws ServletException, IOException {
		String name = req.getParameter("name");
		try (Connection ct = cf.createConnection(); ) {
			Session ses = ct.createSession(false,  Session.AUTO_ACKNOWLEDGE);
			TextMessage m = ses.createTextMessage("Message from: " + name);
			MessageProducer mp = ses.createProducer(queue);
			ct.start();
			mp.send(m);
			
			PrintWriter pw = res.getWriter();
			pw.print("Send Ok.");
		} catch(JMSException ex) {
			ex.printStackTrace();
		}
	} 
}
