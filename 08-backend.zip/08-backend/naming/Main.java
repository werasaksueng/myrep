/* JNDI provides:
 - Name:value lookup across the enterprise.
 - Abstract complex object creations.
 - Enforce singletpn.

javax.naming allows embedded and transient JNDI service. */

import java.util.Hashtable;
import javax.naming.Context;
import javax.naming.InitialContext;
import javax.naming.NamingException;
class MyContext {
	private static final Hashtable<String, String> CTX = new Hashtable<String, String>();
	public static Context ROOT_CTX = null;
	public static Context JAVA_CTX = null;
	static {
		CTX.put(Context.INITIAL_CONTEXT_FACTORY, "org.apache.naming.java.javaURLContextFactory");
		CTX.put(Context.URL_PKG_PREFIXES,"org.apache.naming");
		try {
			// Create a root context.
			ROOT_CTX = new InitialContext(CTX); 

			// Create a "java:comp" subcontext.
			JAVA_CTX = ROOT_CTX.createSubcontext("java:comp");
		} catch (NamingException e) {
			e.printStackTrace();
		}
	}
}
// Context provides name space hierarchy for bind/lookup name:values.
public class Main {
	public static void main(String args[]) {
		try {
			MyContext.ROOT_CTX.bind("john", "rambo.com");
			System.out.println(MyContext.ROOT_CTX.lookup("john"));

			MyContext.JAVA_CTX.bind("jack", "ripper.com");
			System.out.println(MyContext.JAVA_CTX.lookup("jack"));


			MyContext.ROOT_CTX.bind("java:comp/joe", "green.com");
			System.out.println(MyContext.ROOT_CTX.lookup("java:comp/joe"));
		} catch(NamingException e) {
			System.out.println(e);
		}
	}
}
/* A bound name must be unbind() before binding a new value.
rebind() allows binding a new value without unbind(). */