package com.mycomp;
import java.io.*;
import javax.inject.Inject;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.*;
import com.mycomp.mybeans.MyBean;

@WebServlet("/MyServlet")
public class MyServlet extends HttpServlet {
	// Field Injection
	@Inject
	private MyBean mb;

	protected void doGet(HttpServletRequest req, HttpServletResponse res) throws IOException {
		PrintWriter pw = res.getWriter();
		pw.print(mb.hello() + "<br/>");
		pw.close();
	}
}
