package com.mycomp.mybeans;

import javax.enterprise.context.SessionScoped;
import java.io.Serializable;

@SessionScoped			// default
public class MyBean implements Serializable {
        private String getAddress(String s) {
		return  s.substring(s.indexOf("@"));
	}
	public String hello() {
		return "Hello! I am injected MyBean. " + getAddress(this.toString());
	}
}

