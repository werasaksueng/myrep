import javax.management.*;
import com.sun.jdmk.comm.*;
public class HelloServer {
	private MBeanServer mbs = null;
	public HelloServer() {
		mbs = MBeanServerFactory.createMBeanServer("HelloAgent" );
		try {
			mbs.registerMBean(new Hello(),
				new ObjectName("HelloAgent:name=helloMBean"));


			HtmlAdaptorServer as = new HtmlAdaptorServer();
			as.setPort(1234);
			mbs.registerMBean(as, 
				new ObjectName("HelloAgent:name=htmladapter,port=1234" ));
			as.start();
		} catch( Exception e ) {
			e.printStackTrace();
		}
	}
	public static void main(String args[]) {
		System.out.println( "HelloServer is running" );
		new HelloServer();
	}
}
// http://localhost:1234