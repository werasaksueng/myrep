// HelloMBean.java
public interface HelloMBean {
	public void setName(String name);
	public String getName();
	public void greet();
}