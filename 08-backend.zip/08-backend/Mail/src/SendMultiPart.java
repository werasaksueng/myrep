import javax.mail.Message;
import javax.mail.Multipart;
import javax.mail.Session;
import javax.mail.Transport;
import javax.mail.internet.InternetAddress;
import javax.mail.internet.MimeBodyPart;
import javax.mail.internet.MimeMessage;
import javax.mail.internet.MimeMultipart;

class SendMultiPart {
	public static void main(String args[]) throws Exception {
		Session ses = MyUtil.getSession("send", "localhost");
		
		Message msg = new MimeMessage(ses);
		msg.setFrom(new InternetAddress("jack@mycomp.com"));
		msg.setRecipient(Message.RecipientType.TO, new InternetAddress("john@localhost"));
		msg.setSubject("Greeting");

		MimeBodyPart mbp1 = new MimeBodyPart();
		mbp1.setFileName("Part1");
		mbp1.setText("Hello!");

		MimeBodyPart mbp2 = new MimeBodyPart();
		mbp2.setFileName("Part2");
		mbp2.setText("Hi!");

		Multipart mp = new MimeMultipart();
		mp.addBodyPart(mbp1);
		mp.addBodyPart(mbp2);
		msg.setContent(mp); 

		Transport.send(msg);
    }
}
