import javax.mail.Folder;
import javax.mail.Message;
import javax.mail.Multipart;
import javax.mail.Part;
import javax.mail.Session;
import javax.mail.Store;
class RetrieveMultiPart {
	public static void main(String args[]) throws Exception {
		Session ses = MyUtil.getSession("read", "localhost");
		
		Store st = ses.getStore("pop3");
		st.connect("localhost", "john", "hello");
		Folder f = st.getFolder("INBOX");
		f.open(Folder.READ_ONLY);
		Message m = f.getMessage(1);
		Object o =  m.getContent();
		if (o instanceof Multipart) {
			Multipart mp = (Multipart) o;
			for (int i = 0; i < mp.getCount(); i++){
				Part p = mp.getBodyPart(i);
				System.out.println("\n" + p.getFileName());
				System.out.println(p.getContent());
			}
		}
		f.close(false);
		st.close();
	}
}
