import javax.mail.*;
class ListProviders {
	public static void main(String args[]) {
		Session s = Session.getInstance(System.getProperties(), null);
		Provider [] p = s.getProviders();
		for (int i = 0; i < p.length; i++)
			System.out.println(p[i].getClassName());
	}
}

