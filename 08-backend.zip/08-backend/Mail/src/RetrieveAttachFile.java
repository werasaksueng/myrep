import java.io.FileOutputStream;
import java.io.InputStream;
import javax.activation.DataHandler;
import javax.mail.Folder;
import javax.mail.Message;
import javax.mail.Multipart;
import javax.mail.Part;
import javax.mail.Session;
import javax.mail.Store;
import javax.swing.ImageIcon;
import javax.swing.JFrame;
import javax.swing.JLabel; 

class RetrieveAttachFile {
	public static void main(String args[]) throws Exception {
		Session ses = MyUtil.getSession("read", "localhost");
		
		Store st = ses.getStore("pop3");
		st.connect("localhost", "john", "hello");
		Folder f = st.getFolder("INBOX");
		f.open(Folder.READ_ONLY);
		Message m = f.getMessage(1);
		Multipart mp = (Multipart) m.getContent();
		for (int i = 0; i < mp.getCount(); i++){
			Part p = mp.getBodyPart(i);
			String dis = p.getDisposition();
			if (dis == null)
				System.out.println(p.getContent());
			else {
				String ct = p.getContentType();
				if (ct.startsWith("text/plain"))
					FileUtil.save(p, "tmp.txt");
				else if (ct.startsWith("image/gif"))
					new MyFrame(p);
			}
		}
		f.close(false);
		st.close();
	}
}
class FileUtil {
	public static void save(Part p, String f) throws Exception {
		FileOutputStream os = new FileOutputStream(f);
		InputStream is = p.getInputStream();
		byte b[] = new byte[is.available()];
		is.read(b);
		os.write(b);
		os.close();
	}
}
class MyFrame extends JFrame {
	private static final long serialVersionUID = 1L;
	MyFrame(Part p) {
		try {
			DataHandler dh = p.getDataHandler();
			InputStream is = dh.getInputStream();
			byte b[] = new byte[is.available()];
			is.read(b);
			String fn = dh.getDataSource().getName();
			FileOutputStream os = new FileOutputStream(fn);
			os.write(b);
			os.close();
			JLabel jl = new JLabel(new ImageIcon(fn));
			getContentPane().add(jl);
			setSize(130,130);
			setVisible(true);
		} catch ( Exception e ) { System.out.println(e); }
	}
}

