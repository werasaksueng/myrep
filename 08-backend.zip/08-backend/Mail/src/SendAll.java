import javax.mail.*;
import javax.mail.internet.*;
class SendAll {
	public static void main(String args[]) throws Exception {
		Address a[] = { 
				new InternetAddress("john@localhost"),
				new InternetAddress("jack@localhost") };
		
		Session ses = MyUtil.getSession("send", "localhost");
		Message msg = new MimeMessage(ses);
		msg.setFrom(new InternetAddress("jack@mycomp.com"));
		msg.setRecipients(Message.RecipientType.TO, a);
		msg.setSubject("Greeting");
		msg.setText("Hello! how do you do?");
		Transport.send(msg);
		System.out.println("SendAll Ok.");
    }
}

