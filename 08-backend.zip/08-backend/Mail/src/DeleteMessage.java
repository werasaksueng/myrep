import javax.mail.Flags;
import javax.mail.Folder;
import javax.mail.Message;
import javax.mail.Session;
import javax.mail.Store;
class DeleteMessage {
	public static void main(String args[]) throws Exception {
		Session ses = MyUtil.getSession("read", "localhost");
		Store st = ses.getStore("pop3");
		st.connect("localhost", "john", "hello");
		Folder f = st.getFolder("INBOX");
		
		f.open(Folder.READ_WRITE);
		Message msg[] = f.getMessages();
		for(int i = 0; i < msg.length; i++)
			msg[i].setFlag(Flags.Flag.DELETED, true);
		f.close(true);
		st.close();
		System.out.println("DeleteMessage Ok.");
	}
}
