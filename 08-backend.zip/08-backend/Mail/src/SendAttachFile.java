import javax.activation.DataHandler;
import javax.activation.DataSource;
import javax.activation.FileDataSource;
import javax.mail.BodyPart;
import javax.mail.Message;
import javax.mail.Multipart;
import javax.mail.Session;
import javax.mail.Transport;
import javax.mail.internet.InternetAddress;
import javax.mail.internet.MimeBodyPart;
import javax.mail.internet.MimeMessage;
import javax.mail.internet.MimeMultipart;

public class SendAttachFile {
	public static void main (String args[]) throws Exception {
		Session ses = MyUtil.getSession("send", "localhost");
		
		Message mes = new MimeMessage(ses);
		mes.setFrom(new InternetAddress("jack@mycomp.com"));
		mes.addRecipient(Message.RecipientType.TO, 
			new InternetAddress("john@localhost"));
		mes.setSubject("Attach File Test");

		Multipart mp = new MimeMultipart();

		BodyPart bp = new MimeBodyPart();
		bp.setText("Hello! this is a text.");
		mp.addBodyPart(bp);

		bp = new MimeBodyPart();
		DataSource ds = new FileDataSource("test.txt");
		bp.setDataHandler(new DataHandler(ds));
		bp.setFileName("test.txt");
		mp.addBodyPart(bp);

		bp = new MimeBodyPart();
		ds = new FileDataSource("Bird.gif");
		bp.setDataHandler(new DataHandler(ds));
		bp.setFileName("Bird.gif");
		mp.addBodyPart(bp);

		mes.setContent(mp);
		Transport.send(mes);
	}
}
