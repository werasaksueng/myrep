import javax.mail.*;
import javax.mail.internet.*;
class Send {
	public static void main(String args[]) throws Exception {
		Session ses = MyUtil.getSession("send", "localhost");
		Message msg = new MimeMessage(ses);
		msg.setFrom(new InternetAddress("me@mycomp.com")); 	// sender
		msg.setRecipient(Message.RecipientType.TO, 
		    new InternetAddress("john@localhost")); // receiver
		msg.setSubject("Greeting"); 				// subject
		msg.setText("Hello! how do you do?");		// content
	//	for(int i = 0; i < 10; i++) {
			Transport.send(msg);
	//		try { Thread.sleep(10); } catch(Exception ex) { }
	//	}
		// msg.writeTo(System.out);
		System.out.println("Send Ok.");
    }
}
// C:\jee\etc\james-2.3.2\apps\james\var\mail\inboxes\john
