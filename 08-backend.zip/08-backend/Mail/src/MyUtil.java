import java.util.*;
import javax.mail.*;
class MyUtil {
	public static Session getSession(String mode, String host) {
		Properties p = new Properties();
			// mode is either "send" or  "read"
		if (mode.equals("send"))
			p.put("mail.smtp.host", host);
		else if (mode.equals("read"))
			p.put("mail.store.host", host);
		else
			return null;
		return Session.getDefaultInstance(p);
	}
}


