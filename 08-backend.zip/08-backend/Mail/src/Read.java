import javax.mail.Folder;
import javax.mail.Message;
import javax.mail.Session;
import javax.mail.Store;
class Read {
	public static void main(String args[]) throws Exception {
		Session ses = MyUtil.getSession("read", "localhost");
		Store st = ses.getStore("pop3");
		st.connect("localhost", "john", "hello");
		Folder f = st.getFolder("INBOX");
		f.open(Folder.READ_ONLY);
		Message msg[] = f.getMessages();
		for(int i = 0; i < msg.length; i++) {
			System.out.println(msg[i].getFrom()[0]);
			System.out.println(msg[i].getSubject());
			System.out.println(msg[i].getContent());
		}
		f.close(false);
		st.close();
	}
}
