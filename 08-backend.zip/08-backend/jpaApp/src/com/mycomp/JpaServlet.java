package com.mycomp;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.List;
import javax.inject.Inject;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import com.mycomp.ejb.StudentGuard;
import com.mycomp.jpa.Student;

@WebServlet("/JpaServlet")
public class JpaServlet extends HttpServlet {
	@Inject
	private StudentGuard sg;
	
	public void doGet(HttpServletRequest req, HttpServletResponse res) throws ServletException, IOException {
		String cmd = req.getParameter("cmd");
		PrintWriter pw = res.getWriter();
		try {
			if (cmd.equals("persist")) {
				int id = Integer.parseInt(req.getParameter("id"));
				String name = req.getParameter("name");
				String dept = req.getParameter("dept");
				if (id != 0 && name != null && dept != null) {
					Student s = new Student(id, name, dept);
					sg.persist(s);
					pw.println("persist: " + s);
				} 
			} else if (cmd.equals("find")) {
				long id = Long.parseLong(req.getParameter("id"));
				Student s = sg.find(id);
				if (s == null)
					pw.print("Not Found <br/>");
				else
					pw.print(s + "<br/>");
			} else if (cmd.equals("findAll")) {
				List<Student> ls = sg.findAll();
				for(Student s : ls)
					pw.print(s + "<br/>");
			} else
				pw.println("Invalid request.");
		} catch(Throwable e) { 
			pw.println(e);
		} finally {
			pw.close();
		}
	}
}
