package com.mycomp.ejb;

import java.util.List;
import javax.ejb.Stateful;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.PersistenceContextType;
import javax.persistence.Query;
import com.mycomp.jpa.Student;

@Stateful
public class StudentGuard {
	@PersistenceContext(unitName="myUnit",  type = PersistenceContextType.EXTENDED)
    	private EntityManager em;

	public void persist(Student s) {
		em.persist(s);
	}
	
	public Student find(long id) {
		return em.find(Student.class, id);
	}
	
	public List<Student> findAll() {
		Query q = em.createQuery("SELECT s FROM Student s");
		return (List<Student>) q.getResultList();
	}
	
	public void delete(int id) {
		em.remove(em.find(Student.class, id));
	}
}
