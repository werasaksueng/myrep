package com.mycomp;
import java.io.*;
import javax.naming.*;
import javax.servlet.http.*;
import javax.servlet.annotation.WebServlet;

@WebServlet("/LookupServlet")
public class LookupServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
	protected void doGet(HttpServletRequest req, HttpServletResponse res) throws IOException {
		String v = null;
		try {
			InitialContext ctx = new InitialContext();
			v = (String) ctx.lookup("msg");
		} catch (NamingException e) {
			e.printStackTrace();
		}
		PrintWriter pw = res.getWriter();
		pw.println(v);
		pw.close();
	}
}
/*
1. http://localhost:9990
2. %TOMCAT%/bin/add-user.bat
3.   ... -> john, hello123
4. Login:
5. Runtime -> Standalone -> Subsystems ->  JNDI View
		java:
			msg
*/