package com.mycomp;
import java.io.*;
import javax.naming.*;
import javax.servlet.http.*;
import javax.servlet.annotation.WebServlet;

@WebServlet("/BindServlet")
public class BindServlet extends HttpServlet {
	protected void doGet(HttpServletRequest req, HttpServletResponse res) throws IOException {
		try {
			InitialContext ctx = new InitialContext();
			ctx.rebind("msg", "Hello!");
		} catch (NamingException e) {
			e.printStackTrace();
		}
		PrintWriter pw = res.getWriter();
		pw.println("Bind ok");
		pw.close();
	}
}
