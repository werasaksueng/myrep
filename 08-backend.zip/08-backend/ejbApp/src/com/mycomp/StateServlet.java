package com.mycomp;

import java.io.*;
import javax.naming.*;
import javax.ejb.EJB;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.*;

import com.mycomp.ejb3.CounterSF;
import com.mycomp.ejb3.CounterSFLocal;
import com.mycomp.ejb3.CounterSL;
import com.mycomp.ejb3.CounterSLLocal;

@WebServlet("/StateServlet")
public class StateServlet extends HttpServlet {
	private PrintWriter pw = null;
	
    	@EJB
    	private CounterSLLocal sl = null;
    	@EJB
    	private CounterSFLocal sf = null;
   
	protected void doGet(HttpServletRequest req, HttpServletResponse res) throws IOException {
		pw = res.getWriter();
		Context ctx;
		try {
			ctx = new InitialContext();
			String sl_jndi = "java:comp/env/myCounterSL";
			for (int i = 0; i < 2; i++) {
				CounterSLLocal sl = (CounterSLLocal) ctx.lookup(sl_jndi);
				for (int j = 0; j < 3; j++)
					pw.println(sl.inc());
				sl.remove();
			}
			pw.println("<p/>");
			System.out.println();

			String sf_jndi = "java:comp/env/myCounterSF";
			for (int i = 0; i < 2; i++) {
				CounterSFLocal sf = (CounterSFLocal) ctx.lookup(sf_jndi);
				for (int j = 0; j < 3; j++)
					pw.println(sf.inc());
				sf.remove();
			}
		} catch(Exception e) { pw.print(e); }
		pw.close();
	}

}
