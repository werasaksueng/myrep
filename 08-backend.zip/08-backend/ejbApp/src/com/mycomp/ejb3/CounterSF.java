package com.mycomp.ejb3;

import javax.ejb.Stateful;
import javax.ejb.EJB;

@Stateful
@EJB(beanInterface = CounterSFLocal.class, beanName = "CounterSF", name = "myCounterSF")
public class CounterSF implements CounterSFLocal {
	private int x = 0;
	
	public String inc() { 
		++x;
		return x + ": " + this;
	}

	@Override
	public void remove() { }
}

/*
    Stateless beans may have callback methods annotated with:
		 @PostConstruct
		 @PreDestroy
		 @Remove
		 
	Stateful beans may have callback methods annotated with:
		 @PostConstruct
		 @PreDestroy
		 @Remove
		 @PreActivate
		 @PrePassivate
		 
 */
