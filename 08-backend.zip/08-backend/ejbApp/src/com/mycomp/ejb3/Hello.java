package com.mycomp.ejb3;

import javax.ejb.Stateless;
import javax.ejb.EJB;

@Stateless
@EJB(beanInterface = HelloLocal.class, beanName = "Hello", name = "myHello")
public class Hello implements HelloLocal {
	@Override
	public String greet(String name) {
		return "Hello! " + name;
	}
}
/*   
			Requirements of EJB Class
 - Must be annotated with @Stateless, @Stateful, @Singleton or specified in XML.
 - Be a POJO class and may or may not implement interfaces. 
 - The class must be defined as public, and must not be final or abstract.
 - The class must have a public no-arg constructor that the container will use to create instances. 
 - The class must not define the finalize() method.
 - Business method names must not start with ejb, and cannot be final or static.
 - The argument and return value of a remote method must be legal RMI types. 
*/