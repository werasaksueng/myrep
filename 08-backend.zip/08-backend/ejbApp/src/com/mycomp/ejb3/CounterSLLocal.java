package com.mycomp.ejb3;
import javax.ejb.Local;

@Local
public interface CounterSLLocal {
	public String inc();
	public void remove();
}
