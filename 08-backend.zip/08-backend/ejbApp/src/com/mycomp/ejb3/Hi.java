package com.mycomp.ejb3;

import javax.ejb.Local;
import javax.ejb.Stateless;

@Stateless
@Local
public class Hi {
	public String greet(String name) {
		return "Hi! " + name;
	}

}
