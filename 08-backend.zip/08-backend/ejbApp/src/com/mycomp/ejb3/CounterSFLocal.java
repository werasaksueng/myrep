package com.mycomp.ejb3;
import javax.ejb.Local;

@Local
public interface CounterSFLocal {
	public String inc();
	public void remove();
}
