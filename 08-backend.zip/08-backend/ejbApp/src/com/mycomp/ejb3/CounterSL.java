package com.mycomp.ejb3;

import javax.annotation.PostConstruct;
import javax.annotation.PreDestroy;
import javax.ejb.Remote;
import javax.ejb.Remove;
import javax.ejb.Stateless;
import javax.ejb.EJB;

@Stateless
@EJB(beanInterface = CounterSLLocal.class, beanName = "CounterSL", name = "myCounterSL")
public class CounterSL implements CounterSLLocal {
	private int x = 0;
	public String inc() { 
		++x;
		return x + ": " + this + " <br/>";
	}
	@PostConstruct
	public void init() {
		System.out.println("Stateless: PostConstruct");
	}
	
	@PreDestroy
	public void destroy() {
		System.out.println("Stateless: PreDestroy");
	}
	
	@Remove
	public void remove() {
		System.out.println("Stateless: Remove");
	}
}
