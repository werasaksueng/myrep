package com.mycomp.ejb3;

import javax.ejb.Local;

@Local
public interface HelloLocal {
	public String greet(String name);
}
