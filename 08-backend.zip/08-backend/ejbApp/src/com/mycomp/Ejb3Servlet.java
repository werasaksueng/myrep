package com.mycomp;

import java.io.*;
import javax.naming.*;
import javax.ejb.EJB;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.*;
import com.mycomp.ejb3.HelloLocal;
import com.mycomp.ejb3.Hi;

@WebServlet("/Ejb3Servlet")
public class Ejb3Servlet extends HttpServlet {
	private PrintWriter pw = null;
	
    	@EJB
    	private HelloLocal hello = null;
    	private void doInject() {
    		pw.print(hello.greet("John") + " (doInject).");
    	}

	private void doLookup() {
		try {
			Context ctx = new InitialContext();
			String jndi = "java:comp/env/myHello";
            		HelloLocal h = (HelloLocal) ctx.lookup(jndi);
			pw.println(h.greet("Jack") + " (doLookup).");
		} catch(Exception e) {
			pw.println(e);
		}
	}
      
    	@EJB
    	private Hi hi = null;
    	private void doNoInterface() {
    		pw.print(hi.greet("Joe") + " (doNoInterface).");
    	}

	protected void doGet(HttpServletRequest req, HttpServletResponse res) throws IOException {
		String cmd = req.getParameter("cmd");
		pw = res.getWriter();
		if (cmd.equals("Inject"))
			doInject();
		if (cmd.equals("Lookup"))
			doLookup();
		else if (cmd.equals("NoInterface"))
			doNoInterface();
		pw.close();
	}

}


/*
 Ejb Container Services:
		- Remote client communication
		- Dependency injection
		- State management
		- Pooling
		- Component life cycle
		- Messaging
		- Transaction management
		- Security
		- Concurrency support
		- Intercepter
		- Asynchronous method invocation
*/