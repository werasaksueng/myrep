/* Enable Remote support:
%TOMEE%\conf\system.properties
		tomee.remote.support = true
		tomee.serialization.class.blacklist = -
		tomee.serialization.class.whitelist = *
		openejb.system.apps = true
		openejb.servicemanager.enabled = true
*/ 

import javax.naming.Context;
import javax.naming.InitialContext;
import java.util.Properties;
import com.mycomp.ejb3.GreetRemote;

public class Client {
	public static void main(String[] args) throws Exception {
		Properties props = new Properties();
		props.setProperty(Context.INITIAL_CONTEXT_FACTORY, "org.apache.openejb.client.RemoteInitialContextFactory");
		props.setProperty(Context.PROVIDER_URL, "http://127.0.0.1:8080/tomee/ejb");
            	Context ctx = new InitialContext(props);
		String jndi = "global/ejbRemoteApp/Greet!com.mycomp.ejb3.GreetRemote";
            	GreetRemote h = (GreetRemote) ctx.lookup(jndi);
		System.out.println(h.greet("John Rambo."));
	}
}
// Check: %Tomee%\logs\catalina.x-y-z.log