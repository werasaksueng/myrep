package com.mycomp.ejb3;

import javax.ejb.Remote;

@Remote
public interface GreetRemote {
	public String greet(String name);
}
