package com.mycomp.ejb3;

import javax.ejb.Stateless;
import javax.ejb.EJB;

@Stateless
@EJB(beanInterface = GreetRemote.class, beanName = "Greet", name = "myGreet")
public class Greet implements GreetRemote {
	@Override
	public String greet(String name) {
		return "Hello! " + name + " (remote).";
	}
}

/*

 - The @Remote or @Local may be annotated at Interface.
 - A bean may implement both Remote and Local interfaces.
 - If a bean implements an interface (local or remote) it will loses the no-interface view.
But we can use @LocalBean on the bean class to explicitly exposes a no-interface view.

@Local
public interface ItemLocal {
	// ....
}
@Remote
public interface ItemRemote {
	// ....
}
@Stateless
@LocalBean
public class ItemEJB implements ItemLocal, ItemRemote {
	// ...
}



  - Alternatively we can used interfaces with no annotation.
But we must specify @Remote or @Local with the interface name on the bean class.

public interface ItemLocal {
	// ....
}
public interface ItemRemote {
	// ....
}
@Stateless
@Local(ItemLocal.class)
@Remote(ItemRemote.class)
@LocalBean
public class ItemEJB implements ItemLocal, ItemRemote {
	// ...
}

*/