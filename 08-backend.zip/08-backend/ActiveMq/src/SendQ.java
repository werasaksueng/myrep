import javax.jms.Connection;
import javax.jms.Destination;
import javax.jms.MessageProducer;
import javax.jms.Session;
import javax.jms.TextMessage;
import org.apache.activemq.ActiveMQConnection;
import org.apache.activemq.ActiveMQConnectionFactory;
class SendQ {
	public static void main(String[] args) throws Exception {
		ActiveMQConnectionFactory cf = new ActiveMQConnectionFactory(
			ActiveMQConnection.DEFAULT_USER, ActiveMQConnection.DEFAULT_PASSWORD, ActiveMQConnection.DEFAULT_BROKER_URL);
		Connection c = cf.createConnection();
		Session ses = c.createSession(false, Session.AUTO_ACKNOWLEDGE);
		Destination des = ses.createQueue("MyQueue");
		MessageProducer mp = ses.createProducer(des);
		TextMessage m = ses.createTextMessage(args[0]);
		c.start();
		mp.send(m);
		mp.close(); ses.close(); c.close();
	}
}