import javax.jms.*;
import org.apache.activemq.*;
class SendP {
	public static void main(String[] args) throws Exception {
		ActiveMQConnectionFactory cf = new ActiveMQConnectionFactory(
			ActiveMQConnection.DEFAULT_USER, ActiveMQConnection.DEFAULT_PASSWORD, ActiveMQConnection.DEFAULT_BROKER_URL);
		Connection c = cf.createConnection();
		Session ses = c.createSession(false, Session.AUTO_ACKNOWLEDGE);
		Destination des = ses.createQueue("MyQueue");
		MessageProducer mp = ses.createProducer(des);
		if (args[0].equals("p"))
			mp.setDeliveryMode(DeliveryMode.PERSISTENT);
		else
			mp.setDeliveryMode(DeliveryMode.NON_PERSISTENT);

		TextMessage m = ses.createTextMessage(args[1]);
		c.start();
		mp.send(m);
		mp.close(); ses.close(); c.close();
	}
}
/* test1:
start activeMq
java SendP x hello1    
stop and restart activeMq
java ReceQ	// no message

   test2:
start activeMq
java SendP p hello2    
stop and restart activeMq
java ReceQ
*/