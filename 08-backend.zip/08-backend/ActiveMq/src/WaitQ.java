import javax.jms.*;
import org.apache.activemq.*;
class WaitQ  {
	public static void main(String[] args) throws Exception {
		ActiveMQConnectionFactory cf = new ActiveMQConnectionFactory(
			ActiveMQConnection.DEFAULT_USER, ActiveMQConnection.DEFAULT_PASSWORD, ActiveMQConnection.DEFAULT_BROKER_URL);
		Connection c = cf.createConnection();
		Session ses = c.createSession(false, Session.AUTO_ACKNOWLEDGE);
		Destination des = ses.createQueue("MyQueue") ;
		MessageConsumer mc = ses.createConsumer(des);
		c.start();

		while (true) {
			javax.jms.Message m = mc.receive(100);
			if (m != null && m instanceof TextMessage) {
				System.out.println("Receive: "+((TextMessage)m).getText());
				// break;	
			}
			if (Thread.interrupted())
				break;
			System.out.println("Waiting....");
			try { Thread.sleep(1000); } catch(Exception ex) { }
		}

		mc.close();
		ses.close(); 
		c.close();
	}
}