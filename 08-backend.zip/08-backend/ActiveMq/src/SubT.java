import javax.jms.*;
import org.apache.activemq.*;
class SubT {
	public static void main(String[] args) throws Exception {
		ActiveMQConnectionFactory cf = new ActiveMQConnectionFactory(
			ActiveMQConnection.DEFAULT_USER, ActiveMQConnection.DEFAULT_PASSWORD, ActiveMQConnection.DEFAULT_BROKER_URL);
		Connection c = cf.createConnection();
		Session ses = c.createSession(false, Session.AUTO_ACKNOWLEDGE);
		Destination des = ses.createTopic("MyTopic");
		MessageConsumer mc = ses.createConsumer(des);
		mc.setMessageListener(new MyMessageListener());
		c.start();
		while(true) {
			Thread.sleep(3000);
			System.out.println("Doing something.");
			if (Thread.interrupted())
				break;	
		}
		mc.close(); ses.close(); c.close();
	}
}