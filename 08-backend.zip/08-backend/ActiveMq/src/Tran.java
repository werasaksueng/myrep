import javax.jms.*;
import org.apache.activemq.*;
class Tran {
	public static void main(String[] args) throws Exception {
		ActiveMQConnectionFactory cf = new ActiveMQConnectionFactory(
			ActiveMQConnection.DEFAULT_USER, ActiveMQConnection.DEFAULT_PASSWORD, ActiveMQConnection.DEFAULT_BROKER_URL);
		Connection c = cf.createConnection();
		Session ses = c.createSession(true, Session.AUTO_ACKNOWLEDGE);
		Destination des = ses.createQueue("MyQueue");
		MessageProducer mp = ses.createProducer(des);
		c.start();
		for (int i = 1; i <= 3; i++)	
			mp.send(ses.createTextMessage("hello" + i));

		if (args[0].equals("rb"))
			ses.rollback();
		else
			ses.commit();

		mp.close(); ses.close(); c.close();
	}
}
// java Tran xx
// java Tran rb