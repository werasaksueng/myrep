import javax.jms.*;
class MyMessageListener implements MessageListener {
	public void onMessage(Message m) {
		try { 
			System.out.println("Receive: " + ((TextMessage) m).getText());
		} catch (JMSException e) { }
	}
}