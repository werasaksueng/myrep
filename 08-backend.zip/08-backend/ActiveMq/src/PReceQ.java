import javax.jms.*;
import org.apache.activemq.*;
class PReceQ  {
	public static void main(String[] args) throws Exception {
		ActiveMQConnectionFactory cf = new ActiveMQConnectionFactory(
			ActiveMQConnection.DEFAULT_USER, ActiveMQConnection.DEFAULT_PASSWORD, ActiveMQConnection.DEFAULT_BROKER_URL);
		Connection c = cf.createConnection();
		Session ses = c.createSession(false, Session.AUTO_ACKNOWLEDGE);
		Destination des = ses.createQueue("MyQueue") ;
		MessageConsumer mc = ses.createConsumer(des);
		c.start();

		while (true) {
			javax.jms.Message m = mc.receive(0);
			if (m != null && m instanceof TextMessage) {
				int id = m.getIntProperty("id");
				String name = m.getStringProperty("name");
				System.out.println(id + "," + name);
				if (name.equals("joe"))
					break;
			}
		}
		mc.close();
		ses.close(); 
		c.close();
	}
}