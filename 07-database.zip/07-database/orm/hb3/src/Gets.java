import org.hibernate.HibernateException;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.cfg.Configuration;
import com.mycomp.Student;

public class Gets {
	public static void main(String[] args) throws HibernateException {
		Configuration cf = new Configuration().addClass(Student.class);
		SessionFactory sf = cf.buildSessionFactory();
		Session ses = sf.openSession();
		Transaction tx = ses.beginTransaction();
		System.out.println(ses.get(Student.class, 1L));
		System.out.println(ses.get(Student.class, 2L));
		System.out.println(ses.get(Student.class, 3L));
		System.out.println(ses.get(Student.class, 4L));
		System.out.println(ses.get(Student.class, 5L));
		tx.commit();
		ses.close();
	}
}
