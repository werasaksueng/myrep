import org.hibernate.HibernateException;
import org.hibernate.SessionFactory;
import org.hibernate.Session;
import org.hibernate.Transaction;
import org.hibernate.cfg.Configuration;
import com.mycomp.Student;

public class Saves {
	public static void main(String[] args) throws HibernateException {
		Configuration cf = new Configuration().addClass(Student.class);
		SessionFactory sf = cf.buildSessionFactory();
		Session ses = sf.openSession();
		Transaction tx = ses.beginTransaction();
		ses.save(new Student(1L, "john", "cs"));
		ses.save(new Student(2L, "jack", "math"));
		ses.save(new Student(3L, "jame", "it"));
		ses.save(new Student(4L, "joe", "cs"));
		ses.save(new Student(5L, "jim", "cs"));
		tx.commit();
		ses.close();
		System.out.println("Save ok.");
	}
}
