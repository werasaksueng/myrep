import java.util.List;
import javax.persistence.*;
import com.mycomp.jpa.Student;

public class DeleteAll { 
	public static void main(String[] args) throws Exception {
		EntityManager em = Persistence.createEntityManagerFactory("myUnit").createEntityManager();
		EntityTransaction tx = em.getTransaction();
		tx.begin();
		
		em.createQuery("DELETE FROM Student s").executeUpdate();

		List<?> l = em.createQuery("FROM Student s").getResultList();
		if (l.isEmpty())
			System.out.println("Not Found");
		
		tx.commit();
		em.close();
	}
}