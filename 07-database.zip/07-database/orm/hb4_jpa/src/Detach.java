import java.util.List;
import javax.persistence.*;
import com.mycomp.jpa.Student;

public class Detach { 
	public static void main(String[] args) throws Exception {
		EntityManager em = Persistence.createEntityManagerFactory("myUnit").createEntityManager();
		EntityTransaction tx = em.getTransaction();
		tx.begin();
		
		Student s1 = (Student)em.find(Student.class, 1);
		Student s2 = (Student)em.find(Student.class, 2);

		em.detach(s1);
		
		s1.setDepartment("xx");
		s2.setDepartment("yy");
		
		// em.merge(s1);	// s1 is managed.

		List<?> l = em.createQuery("FROM Student s").getResultList();
		for(Object o : l)
			System.out.println(o);
		
		tx.commit();
		em.close();
	}
}