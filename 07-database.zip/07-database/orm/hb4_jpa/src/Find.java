import javax.persistence.*;
import com.mycomp.jpa.Student;

public class Find {
	public static void main(String[] args) throws Exception {
		EntityManager em = Persistence.createEntityManagerFactory("myUnit").createEntityManager();
		EntityTransaction tx = em.getTransaction();
		tx.begin();
		
		System.out.println(em.find(Student.class, 1));
		System.out.println(em.find(Student.class, 2));
		
		tx.commit();
		em.close();
	}
}
