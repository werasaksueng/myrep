package com.mycomp.jpa;
import java.io.*;
import javax.persistence.*;

@Entity
public class Student implements Serializable {
	private static final long serialVersionUID = 1L;
	
	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	private int id;
	private String name;
	private String department;
	private double gpa;

	public Student() { }
	public Student(String name, String department, double gpa) {
		this.name = name;
		this.department = department;
		this.gpa = gpa;
	}

	public int getId() { return id; }
	public void setId(int id) { this.id = id; }

	public String getName() { return name; }
	public void setName(String name) { this.name = name; }

	public String getDepartment() { return department; }
	public void setDepartment(String department) { this.department = department; }

	public double getGpa() { return gpa; }
	public void setGpa(double gpa) { this.gpa = gpa; }
	
	public String toString() {
		return id + "," + name + "," + department + "," + gpa;
	}
}