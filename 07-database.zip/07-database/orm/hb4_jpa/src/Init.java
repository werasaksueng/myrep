import javax.persistence.*;
import com.mycomp.jpa.Student;

public class Init { 
	public static void main(String[] args) throws Exception {
		EntityManager em = Persistence.createEntityManagerFactory("myUnit").createEntityManager();
		EntityTransaction tx = em.getTransaction();
		tx.begin();
		
		em.persist(new Student("john", "cs", 1.0));
		em.persist(new Student("jack", "ee", 3.8));
		em.persist(new Student("jame", "it", 1.9));
		em.persist(new Student("joe", "ce", 2.8));
		em.persist(new Student("jim", "cs", 1.8));
		em.persist(new Student("judy", "cs", 3.4));
		
		tx.commit();
		em.close();
		System.out.println("Persist ok.");
	}
}