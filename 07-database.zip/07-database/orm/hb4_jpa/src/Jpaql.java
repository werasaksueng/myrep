import java.util.List;
import javax.persistence.*;

public class Jpaql {
	static String qs = 
			"FROM Student s";
			// "SELECT s FROM Student s";
			// "SELECT s FROM Student AS s";
			
					// where
			// "SELECT s FROM Student s WHERE s.department = 'cs'";
			// "SELECT s FROM Student s WHERE s.gpa < 2.0";
			// "SELECT s FROM Student s WHERE s.gpa < 2.0 AND s.department = 'cs'";
			// "SELECT s FROM Student s WHERE s.gpa BETWEEN 2.0 AND 3.0";
			// "SELECT s FROM Student s WHERE s.department LIKE '_e'";
			// "SELECT s FROM Student s WHERE s.department IN ('math', 'cs')";
	
					// order
			// "SELECT s FROM Student s ORDER BY s.name";
			// "SELECT s FROM Student s ORDER BY s.gpa DESC";
	
					// projection
			//  "SELECT s.name FROM Student s";
			// "SELECT s.id, s.name FROM Student s";
			// "SELECT s.department FROM Student s WHERE s.name = 'john'";
			// "SELECT s.gpa FROM Student s WHERE s.name = 'jack' AND s.department = 'cs'";

					// subquery
			// "SELECT s FROM Student s WHERE s.gpa = (SELECT MAX(s.gpa) FROM Student s)";

					// aggregate functions
			// "SELECT COUNT(s) FROM Student s";
			// "SELECT AVG(s.gpa) FROM Student s";
			// "SELECT SUM(s.gpa)/COUNT(s) FROM Student s";
			// "SELECT MAX(s.gpa), MIN(s.gpa) FROM Student s";
	
	public static void main(String[] args) throws Exception {
		EntityManager em = Persistence.createEntityManagerFactory("myUnit").createEntityManager();
		EntityTransaction tx = em.getTransaction();
		tx.begin();

		List<?> ls = em.createQuery(qs).getResultList();
		if(ls.size() > 0) 
			for(Object o : ls)
				print(o);
		else
			System.out.println("0 result returned");
		
		tx.commit();
		em.close();
	}
	private static void print(Object o) {
		if(o == null)
			System.out.print("NULL");
		else if(o instanceof Object[]) {
			Object [] oa = (Object []) o;
			for(int i = 0; i < oa.length; i++)
				System.out.print(oa[i] + ", ");
		} else
			System.out.print(o);
		System.out.println();
	}
}