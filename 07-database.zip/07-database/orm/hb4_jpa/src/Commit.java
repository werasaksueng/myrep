import java.util.List;
import javax.persistence.*;
import com.mycomp.jpa.Student;

public class Commit { 
	public static void main(String[] args) throws Exception {
		EntityManager em = Persistence.createEntityManagerFactory("myUnit").createEntityManager();
		EntityTransaction tx = em.getTransaction();
		tx.begin();
		
		Student s = (Student)em.find(Student.class, 1);  // s is managed.
		tx.commit();	// s is detached, when the transaction is commit.
		
		s.setDepartment("it");		// s is dirty detached bean and will not be synchronized.

/*		tx.begin(); // when a transaction begins all dirty beans are synchronized.

		List<?> l = em.createQuery("FROM Student s").getResultList();
		for(Object o : l)
			System.out.println(o);
		tx.commit();
*/
		
		em.close();
	}
}