import java.util.List;
import javax.persistence.*;
import com.mycomp.jpa.Student;

public class FindAll { 
	public static void main(String[] args) throws Exception {
		EntityManager em = Persistence.createEntityManagerFactory("myUnit").createEntityManager();
		EntityTransaction tx = em.getTransaction();
		tx.begin();
		
		List<?> l = em.createQuery("FROM Student s").getResultList();
		for(Object o : l)
			System.out.println(o);
		
		tx.commit();
		em.close();
	}
}