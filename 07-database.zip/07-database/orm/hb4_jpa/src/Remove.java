import java.util.List;
import javax.persistence.*;
import com.mycomp.jpa.Student;

public class Remove { 
	public static void main(String[] args) throws Exception {
		EntityManager em = Persistence.createEntityManagerFactory("myUnit").createEntityManager();
		EntityTransaction tx = em.getTransaction();
		tx.begin();
		
		Student s = em.find(Student.class, 1);
		em.remove(s);
		if (em.find(Student.class, 1) == null)
			System.out.println("Not Found");

		// The removed bean must be managed.
		em.persist(new Student("jack", "ee", 3.8));

		List<?> l = em.createQuery("FROM Student s").getResultList();
		for(Object o : l)
			System.out.println(o);

		tx.commit();
		em.close();
	}
}