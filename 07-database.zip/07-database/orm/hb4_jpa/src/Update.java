import java.util.List;
import javax.persistence.*;
import com.mycomp.jpa.Student;

public class Update { 
	public static void main(String[] args) throws Exception {
		EntityManager em = Persistence.createEntityManagerFactory("myUnit").createEntityManager();
		EntityTransaction tx = em.getTransaction();
		tx.begin();
		
		Student s = em.find(Student.class, 2);
		s.setDepartment("ee");  // the bean is dirty
		
		em.persist(new Student("jude", "ec", 3.8));

		List<?> l = em.createQuery("FROM Student s").getResultList();
		for(Object o : l)
			System.out.println(o);
		// the beans are lookup in memory, if not found
		// continue in the database.
		
		tx.commit();  // By default, beans are updated to database
			     // when the transaction is committed.	
		em.close();
	}
}