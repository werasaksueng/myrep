import java.util.List;
import javax.persistence.*;
import com.mycomp.jpa.Student;

public class Clear { 
	public static void main(String[] args) throws Exception {
		EntityManager em = Persistence.createEntityManagerFactory("myUnit").createEntityManager();
		EntityTransaction tx = em.getTransaction();
		tx.begin();
		
		Student s = (Student)em.find(Student.class, 1);
		em.clear();		// the em is un-committed but all managed beans are detached

		s.setDepartment("cs");	// s is dirty detached

		// all beans are taken from database
		List<?> l = em.createQuery("FROM Student s").getResultList();
		for(Object o : l)
			System.out.println(o);
		
		tx.commit();
		em.close();
	}
}