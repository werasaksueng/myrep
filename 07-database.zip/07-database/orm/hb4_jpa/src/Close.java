import java.util.List;
import javax.persistence.*;
import com.mycomp.jpa.Student;

public class Close { 
	public static void main(String[] args) throws Exception {
		EntityManager em1 = Persistence.createEntityManagerFactory("myUnit").createEntityManager();
		EntityTransaction tx1 = em1.getTransaction();
		tx1.begin();
		Student s = (Student)em1.find(Student.class, 1);
		tx1.commit();
		em1.close();		// s is detached

		s.setDepartment("zz");	// s is dirty	

		EntityManager em2 = Persistence.createEntityManagerFactory("myUnit").createEntityManager();
		EntityTransaction tx2 = em2.getTransaction();
		tx2.begin();
		
		List<?> l = em2.createQuery("FROM Student s").getResultList();
		for(Object o : l)
			System.out.println(o);
		System.out.println();

		em2.merge(s);

		l = em2.createQuery("FROM Student s").getResultList();
		for(Object o : l)
			System.out.println(o);

		tx2.commit();
		em2.close();
	}
}