import java.sql.*;
public class H2EmbDs {
	public static Connection getConnection() {
		try {
			Class.forName("org.h2.Driver");
			return DriverManager.getConnection("jdbc:h2:mydb", "sa", "");
		} catch(Exception e) {
			System.out.println(e.getMessage());
		}
		return null;
	}
}

/*
jdbc:h2:~/mydb 			user home directory
jdbc:h2:/data/mydb		directory c:/data
jdbc:h2:mydb			current(!) working directory
*/