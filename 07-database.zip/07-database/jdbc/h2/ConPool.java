import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.Statement;
import org.h2.jdbcx.JdbcConnectionPool;
class ConPool {
	public static void main(String args[]) throws Exception {
		JdbcConnectionPool cp = JdbcConnectionPool.create("jdbc:h2:mydb", "sa", "");
		
			// Create
		Connection c1 = cp.getConnection();
		Statement s1 = c1.createStatement();
		s1.executeUpdate("CREATE TABLE student(id INTEGER, name VARCHAR(20))");
		s1.executeUpdate("INSERT INTO student VALUES (123, 'John Rambo')");
		s1.executeUpdate("INSERT INTO student VALUES (7, 'Jame Bond')");
		s1.executeUpdate("INSERT INTO student VALUES (666, 'Jack Ripper')");
		c1.close();

			// Select
		Connection c2 = cp.getConnection();
		Statement s2 = c2.createStatement();
		ResultSet r = s2.executeQuery("SELECT * FROM student");
		while (r.next())
			System.out.println(r.getInt(1) + "," + r.getString(2));
		s2.close();
		c2.close();
		
		cp.dispose();
	}
}