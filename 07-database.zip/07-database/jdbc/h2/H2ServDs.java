import java.sql.*;
public class H2ServDs {
	public static Connection getConnection() {
		try {
			Class.forName("org.h2.Driver");
			return DriverManager.getConnection("jdbc:h2:tcp://localhost/mydb", "sa", "");
		} catch(Exception e) {
			System.out.println(e.getMessage());
		}
		return null;
	}
}