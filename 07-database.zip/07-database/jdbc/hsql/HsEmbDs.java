import java.sql.*;
public class HsEmbDs {
	public static Connection getConnection() {
		try {
			Class.forName("org.hsqldb.jdbcDriver");
			return DriverManager.getConnection("jdbc:hsqldb:file:mydb", "sa", "");
		} catch(Exception e) {
			System.out.println(e.getMessage());
		}
		return null;
	}
}

/*
jdbc:h2:~/mydb 			user home directory
jdbc:h2:/data/mydb		directory c:/data
jdbc:h2:mydb			current(!) working directory
*/