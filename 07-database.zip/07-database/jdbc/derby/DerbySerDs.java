import java.sql.*;
public class DerbySerDs {
	public static Connection getConnection() {
		try {
			Class.forName("org.apache.derby.jdbc.ClientDriver");
			return DriverManager.getConnection("jdbc:derby://localhost/myDb;create=true", "user1", "user1");
		} catch(Exception e) {
			System.out.println(e.getMessage());
		}
		return null;
	}
}
//  The database directories may be specified in the  derby.system.home property.