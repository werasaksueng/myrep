import java.sql.*;
public class DerbyEmbDs {
	public static Connection getConnection() {
		try {
			Class.forName("org.apache.derby.jdbc.EmbeddedDriver");
			return DriverManager.getConnection("jdbc:derby:memory:myDB;create=true");
		} catch(Exception e) {
			System.out.println(e.getMessage());
		}
		return null;
	}
}