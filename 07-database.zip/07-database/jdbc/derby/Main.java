import java.sql.Connection;
import java.sql.Statement;
import java.sql.ResultSet;
class Main {
	public static void main(String args[]) throws Exception {
		try ( // Connection c = DerbyEmbDs.getConnection()
		      Connection c = DerbySerDs.getConnection()
		) {
			Statement s = c.createStatement();
			s.executeUpdate("CREATE TABLE student(id INTEGER, name VARCHAR(20))");
			s.executeUpdate("INSERT INTO student VALUES (123, 'John Rambo')");
			s.executeUpdate("INSERT INTO student VALUES (7, 'Jame Bond')");
			s.executeUpdate("INSERT INTO student VALUES (666, 'Jack Ripper')");	
			s.close();
			System.out.println("Create ok.");

			s = c.createStatement();
			ResultSet r = s.executeQuery("SELECT * FROM student");
			while (r.next())
				System.out.println(r.getInt(1) + "," + r.getString(2));
			s.close();	
		} catch(Exception e) {
			System.out.print(e);
		}
	}
}