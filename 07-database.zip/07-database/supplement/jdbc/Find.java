import java.sql.*;
class Find {
	static Statement s = MyUtil.getStatement();
	static void findByName(String name) throws SQLException {
		ResultSet r = s.executeQuery("SELECT * FROM student WHERE name= '" + name + "' ");
		while (r.next())
			System.out.println(r.getInt("ID") + ", " + r.getString(2) + ", " + r.getString(3) + ", " + r.getDouble(4));
	}
	public static void main(String argv[]) throws Exception {
		findByName("John");

		s.close();
		MyUtil.closeConnection();
	}
}