import java.io.FileInputStream;
import java.io.InputStream;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Statement;

class LargeObj {
	public static void main(String argv[]) throws Exception {
		Connection c = MyUtil.getConnection();
		Statement s = c.createStatement();
		s.execute("CREATE TABLE program(id INTEGER, code LONGVARCHAR)");

		PreparedStatement ps = c.prepareStatement("INSERT INTO program VALUES(?,?)");
        ps.setInt(1, 1);		
		InputStream is = new FileInputStream("LargeObj.java");
		ps.setAsciiStream(2, is, is.available());
		ps.execute();
		
		ResultSet r = s.executeQuery("SELECT * FROM program");
		r.beforeFirst();
		while (r.next()) {
			// System.out.println(r.getInt(1));
			System.out.println(read(r.getAsciiStream(2)));
		}
		s.executeUpdate("DROP TABLE program");
		c.close();
	}
	
	static String read(InputStream is) throws Exception {
		byte b[] = new byte[is.available()];
		is.read(b);
		return new String(b);
	}
}
/*  
  For Create Tables:
    LONGVARCHAR		for Clob
    LONGVARBINARY	for Blob
    
  For Setting/Getting Large Objects:
  	setAsciiStream()/getAsciiStream()			for InputStream
  	setCharacterStream()/getCharacterStream()	for Reader
  	
    
 */ 
