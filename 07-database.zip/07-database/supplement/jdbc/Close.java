import java.sql.*;
class Close {
	static void preJava7() {
		Connection c = null;
		Statement s = null;
		try { // Assume Init.java
			c = MyUtil.getConnection();
			s = c.createStatement();
			ResultSet r = s.executeQuery("SELECT * FROM student");
			while (r.next())
				System.out.println(r.getInt(1) + "," + r.getString(2) + "," + r.getString(3) + "," + r.getDouble(4));
		} catch(SQLException e) {
			System.out.println(e.getMessage());
		} finally {
			if (s != null) {
				try {
					c.close();
				} catch(Exception e) {
					System.out.println("Cannot close connection");
				}
			}
			if (c != null) {
				try {
					c.close();
				} catch(Exception e) {
					System.out.println("Cannot close connection");
				}
			}
		}
	}
	static void java7() {
		try (  // Resource block
			Connection c = MyUtil.getConnection();
			Statement s = c.createStatement();
		){
			ResultSet r = s.executeQuery("SELECT * FROM student");
			while (r.next())
				System.out.println(r.getInt(1) + "," + r.getString(2) + "," + r.getString(3) + "," + r.getDouble(4));
		} catch(SQLException e) {
			System.out.println(e.getMessage());
		}
	}
	public static void main(String args[]) {
		preJava7();
		java7();
	}
}
