import java.sql.*;
import java.io.*;
class Prepare {
	public static void main(String argv[]) throws Exception {
		// Assume Init.java
		Connection c = MyUtil.getConnection();
		PreparedStatement p = c.prepareStatement(
			"INSERT INTO student VALUES (?, ?, ?, ?)");
		BufferedReader br = new BufferedReader(
			new FileReader("./data.txt"));
		for (int i = 0; i < 2; i++) {
			p.setString(1, br.readLine());
			p.setString(2, br.readLine());
			p.setString(3, br.readLine());
			p.setString(4, br.readLine());
			p.executeUpdate();
		}
		br.close();
		p.close();
		c.close();
	}
}