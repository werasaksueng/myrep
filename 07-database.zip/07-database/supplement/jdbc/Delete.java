import java.sql.*;
class Delete {
	static Statement s = MyUtil.getStatement();
	public static void deleteByName(String name) throws SQLException {	
		s.executeUpdate("DELETE FROM student WHERE name =  '" + name + "' ");
	}
	public static void main(String argv[]) throws Exception {
		deleteByName("Jame");		

		s.close();
		MyUtil.closeConnection();
	}
}