import java.sql.*;
class List {
	static Statement s = MyUtil.getStatement();
	public static void main(String argv[]) throws Exception {
		ResultSet r = s.executeQuery("SELECT * FROM student");
		while (r.next())
			System.out.println(r.getInt("ID") + ", " + r.getString(2) + ", " + r.getString(3) + ", " + r.getDouble(4));

		s.close();
		MyUtil.closeConnection();
	}
}