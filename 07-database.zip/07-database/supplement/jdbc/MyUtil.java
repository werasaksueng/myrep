import java.sql.*;
class MyUtil {
	public static Connection getConnection() {
		try {
			Class.forName("org.h2.Driver");
			return DriverManager.getConnection("jdbc:h2:mydb", "sa", "");
		} catch(Exception e) {
			System.out.println(e.getMessage());
		}
		return null;
	}
	private static Connection c = getConnection();
	
	private static Statement s = null;
	static {
		try {
			s = c.createStatement();
		} catch (SQLException e) {
			e.printStackTrace();
		}
	}
	public static Statement getStatement() { return s; }

	public static void closeConnection() {
		if (c != null)
			try {
				c.close();
			} catch(SQLException ex) {
				ex.printStackTrace();
			}
	}
}