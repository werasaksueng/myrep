import java.sql.*;
class Init {
	static Statement s = MyUtil.getStatement();
	static void insert(int id, String name, String dept, double gpa) throws SQLException {
		s.executeUpdate("INSERT INTO student VALUES(" + id + ", '" + name +"', '" + dept + "', " + gpa +")"); 
	}
	public static void main(String argv[]) throws Exception {
		System.out.println("Create Table");
		s.executeUpdate("CREATE TABLE student(id INTEGER, name VARCHAR(30), department VARCHAR(15), gpa REAL)");

		System.out.println("Insert Student");
		insert(1, "John", "CompSci", 1.5);
		insert(2, "Jack", "Biology", 4.0);
		insert(3, "Jame", "It", 1.0);
		insert(4, "Jim", "Mathematics", 3.0);

		s.close();
		MyUtil.closeConnection();
	}
}