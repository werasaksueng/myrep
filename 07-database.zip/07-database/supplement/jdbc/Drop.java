import java.sql.*;
class Drop {
	static Statement s = MyUtil.getStatement();
	public static void main(String argv[]) throws Exception {
		s.executeUpdate("DROP TABLE student");	

		s.close();
		MyUtil.closeConnection();
	}
}