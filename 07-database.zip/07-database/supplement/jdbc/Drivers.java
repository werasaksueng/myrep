import java.sql.*;
import java.util.*;
class Drivers {
	public static void main(String argv[]) throws Exception {
		// A program may load many drivers.
		Class.forName("org.h2.Driver");
		Class.forName("org.apache.derby.jdbc.EmbeddedDriver");
		
		// List drivers
		Enumeration<Driver> e = DriverManager.getDrivers();
		while (e.hasMoreElements()) {
			System.out.println(e.nextElement().getClass().getName());
		}
	}
}
