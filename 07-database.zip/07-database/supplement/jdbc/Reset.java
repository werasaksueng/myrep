import java.io.*;
class Remove {
	public static void main(String argv[]) throws Exception {
		File f = new File("mydb.h2.db");
		if (f.exists()) {
			f.delete();
			System.out.println("Delete: mydb.h2.db");
		}
	}
}