import java.sql.*;
import java.io.*;
class Batch {
	public static void main(String argv[]) throws Exception {
		Statement s = MyUtil.getStatement();
		
		BufferedReader br = new BufferedReader(
			new FileReader("./query.txt"));
		String q = null;
		while ((q = br.readLine()) != null)
			s.addBatch(q);
		s.executeBatch();
		br.close();
		s.close();
		MyUtil.closeConnection();
	}
}
