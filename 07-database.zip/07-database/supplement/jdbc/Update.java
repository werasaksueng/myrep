import java.sql.*;
class Update {
	static Statement s = MyUtil.getStatement();
	public static void updateGpaByName(double gpa, String name) throws SQLException {
		s.executeUpdate("UPDATE student SET gpa = " + gpa + " WHERE name = '" + name + "' ");
	}
	public static void main(String argv[]) throws Exception {
		updateGpaByName(3.8, "Jame");

		s.close();
		MyUtil.closeConnection();
	}
}