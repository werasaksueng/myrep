import org.springframework.beans.factory.xml.XmlBeanFactory;
import org.springframework.core.io.ClassPathResource;
import com.mycomp.StudentDao;

class DaoTest {
	public static void main(String[] args) throws Exception {
		XmlBeanFactory bf = new XmlBeanFactory(
			new ClassPathResource("com/mycomp/beans.xml"));

		StudentDao sd = (StudentDao) bf.getBean("studentDao");
		sd.create();
		sd.insert(123, "john rambo");
		sd.insert(666, "jack ripper");
		sd.insert(700, "jame bond");
		sd.insert(741, "joe green");
		
		for(Object s : sd.select())
			System.out.println(s);
		sd.drop();
	}
}