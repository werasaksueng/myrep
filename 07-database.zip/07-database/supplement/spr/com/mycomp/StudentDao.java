package com.mycomp;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.springframework.jdbc.core.simple.SimpleJdbcDaoSupport;

public class StudentDao extends SimpleJdbcDaoSupport {
	private static final String CREATE = "CREATE TABLE student(id INTEGER, name VARCHAR(20))";
	private static final String INSERT = "INSERT INTO student VALUES (:id, :name)";
	private static final String SELECT = "SELECT * FROM student";
	private static final String DROP = "DROP TABLE student";

	public void create() {
		getSimpleJdbcTemplate().update(CREATE);
	}
	public void insert(int id, String name) {
		Map<String, Object> m = new HashMap<String, Object>();
		m.put("id", id);
		m.put("name", name);
		getSimpleJdbcTemplate().update(INSERT, m);
	}
	public List<?> select() {
		return getSimpleJdbcTemplate().query(SELECT, new StudentRowMapper());
	}
	public void drop() {
		getSimpleJdbcTemplate().update(DROP);
	}
}