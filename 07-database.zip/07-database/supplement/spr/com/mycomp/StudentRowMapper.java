package com.mycomp;
import java.sql.*;
import org.springframework.jdbc.core.simple.ParameterizedRowMapper;
public class StudentRowMapper implements ParameterizedRowMapper<Student> {
	public Student mapRow(ResultSet rs, int rowNum) throws SQLException {
		return new Student(rs.getInt(1), rs.getString(2));
	}
}