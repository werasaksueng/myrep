import javax.sql.DataSource;
import org.apache.commons.dbcp.BasicDataSource;
import org.springframework.beans.factory.xml.XmlBeanFactory;
import org.springframework.core.io.ClassPathResource;

class Ds {
	public static void main(String[] args) throws Exception {
		// BasicDataSource: commons-dbcp.jar and commons-pool.jar
		BasicDataSource bds = new BasicDataSource();
		bds.setDriverClassName("org.h2.Driver");
		bds.setUrl("jdbc:h2:mydb");
		bds.setUsername("sa");
		bds.setPassword("sa");
		bds.setInitialSize(5);
		bds.setMaxActive(10);
		DsUtil.test(bds);

		XmlBeanFactory bf = new XmlBeanFactory(
			new ClassPathResource("ds.xml"));
		
		DataSource ds = (DataSource) bf.getBean("dmds");
		DsUtil.test(ds);

		ds = (DataSource) bf.getBean("scds");
		DsUtil.test(ds);

		ds = (DataSource) bf.getBean("dbcpds");
		DsUtil.test(ds);		
	}
}