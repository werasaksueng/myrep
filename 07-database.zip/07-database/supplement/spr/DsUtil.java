import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.Statement;
import javax.sql.DataSource;

public class DsUtil {
	public static void test(DataSource ds) throws Exception {
		Connection c = ds.getConnection();
		Statement s = c.createStatement();
			// insert
		s.executeUpdate("CREATE TABLE student(id INTEGER, name VARCHAR(20))");
		s.executeUpdate("INSERT INTO student VALUES (123, 'John Rambo')");
		s.executeUpdate("INSERT INTO student VALUES (7, 'Jame Bond')");
		s.executeUpdate("INSERT INTO student VALUES (666, 'Jack Ripper')");
		
			// select
		ResultSet r = s.executeQuery("SELECT * FROM student");
		while (r.next())
			System.out.println(r.getInt(1) + "," + r.getString(2));
		System.out.println();

			// drop
		s.executeUpdate("DROP TABLE student");
		s.close();	
		c.close();
	}
}