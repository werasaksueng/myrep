import java.util.HashMap;
import java.util.List;
import java.util.Map;
import org.springframework.beans.factory.xml.XmlBeanFactory;
import org.springframework.core.io.ClassPathResource;
import org.springframework.jdbc.core.simple.SimpleJdbcTemplate;
import com.mycomp.Student;
import com.mycomp.StudentRowMapper;

public class JdbcTemp {
	static SimpleJdbcTemplate tp;
	static public void create() {
		tp.update("CREATE TABLE student(id INTEGER, name VARCHAR(20))");
	}
	static public void insert(int id, String name) {
		Map<String, Object> m = new HashMap<String, Object>();
		m.put("id", id);
		m.put("name", name);
		tp.update("INSERT INTO student VALUES (:id, :name)", m);
	}
	static public List<Student> select() {
		return tp.query("SELECT * FROM STUDENT", new StudentRowMapper());
	}	
	static public void drop() {
		tp.update("DROP TABLE student");
		System.out.println("Drop table");
	}
	public static void main(String[] args) throws Exception {
		XmlBeanFactory bf = new XmlBeanFactory(new ClassPathResource("jdbcTemp.xml"));
		tp = (SimpleJdbcTemplate) bf.getBean("mytp");
		create();
		insert(123, "john rambo");
		insert(666, "jack ripper");
		insert(700, "jame bond");
		for(Object s : select())
			System.out.println(s);
		drop();
	}
}
