
import org.json.JSONException;
import org.json.JSONObject;

class JsonTest {
	public final static void main(String[] args) {
		// A JSONObject stores key-value items as a HashMap.
		
		// SONObject -> Json
		JSONObject jo = new JSONObject();
		try {
			jo.put("id", "123").put("name", "John").put("gpa", "3.8");
		} catch(JSONException ex) {
			System.out.println(ex);
		}
		String js = jo.toString();
		System.out.println(js);
		
		// Json -> SONObject
		try {
			JSONObject j = new JSONObject(js);
			System.out.println(j.getInt("id") + ", " + 
				j.getString("name") + ", " + j.getDouble("gpa"));
		} catch (JSONException e) {
			e.printStackTrace();
		}
		
	}
}