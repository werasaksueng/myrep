
import org.jfree.chart.ChartFactory;
import org.jfree.chart.ChartFrame;
import org.jfree.chart.JFreeChart;
import org.jfree.data.general.DefaultPieDataset;
public class jfreeTest {
	public static void main(String[] args) {
		// create a data set
		DefaultPieDataset ds = new DefaultPieDataset();
		ds.setValue("A", 13.2);
		ds.setValue("B", 27.9);
		ds.setValue("C", 39.5);
		ds.setValue("D", 10.5);
		ds.setValue("F", 8.9);

		// create a chart...
		JFreeChart chart = ChartFactory.createPieChart(
				"Student Pie Chart",
				ds,
				true, // legend?
				true, // tool tips?
				false // URLs?
			);

		// create and display a frame...
		ChartFrame cf = new ChartFrame("My Pie", chart);
		cf.setSize(500,300);
		cf.setVisible(true);
	}
}