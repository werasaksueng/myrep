
import java.io.*;
import com.lowagie.text.*;
import com.lowagie.text.pdf.PdfWriter;
public class iTextTest {
	public static void main(String[] args) throws DocumentException, IOException {
		Document d = new Document(
			PageSize.A4,    // A0 -> A8, B0 -> B5, PageSize.LETTER
			36, 			// left margin
			72,				// right margin	   72pt = 1 inch
			108,			// top margin
			180);			// bottom margin

		PdfWriter.getInstance(d, new FileOutputStream("Hello.pdf"));
		d.open();
		d.setMargins(180, 108, 72, 36);  // left, right, top, bottom
		d.add(new Paragraph("Hello! how do you do?"));
		d.close();
	}
}