package com.main;
import com.google.gson.Gson;
import com.google.gson.GsonBuilder;

class GsonTest {
	public static void main(String[] args) {
		Gson gs = new GsonBuilder().create();
		
		// Java Bean -> Json
		Student john = new Student(2, "Jack", 4.0f);
		String js = gs.toJson(john);
		System.out.println(js);
		
		// Json -> Java Bean
		Student sj = gs.fromJson(js, Student.class);
		System.out.println(sj);
	}
}