package com.main;
import com.mycomp.Hello;
public class Main {
	public static void main(String args[]) {
		Hello h = new Hello();
		System.out.println(h.greet(args[0]));
	}
}