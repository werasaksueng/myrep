package com.mycomp;
public class Hello {
	public String greet(String name) {
		return "Hello! " + name;
	}
}