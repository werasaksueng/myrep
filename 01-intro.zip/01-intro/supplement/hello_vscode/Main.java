import com.mycomp.*;

public class Main {
	public static void main(String[] args) {
		new Hello().hello();
	}
}

