// JDK 20, TOMCAT 10, TomEE 10
// Since TOMCAT 10 and TomEE 9, javax.servlet was changed to jakarta.servlet.

package com.mycomp;
import java.io.*;
import jakarta.servlet.http.*;
import jakarta.servlet.annotation.WebServlet;

@WebServlet("/HelloServlet")
public class HelloServlet extends HttpServlet {
	public void doGet(HttpServletRequest req, HttpServletResponse res)
			throws IOException {
		String n = req.getParameter("name");
		PrintWriter pw = res.getWriter();
		pw.println("Hello! " + n + " I am hello10.");
		pw.close();
	}
}

