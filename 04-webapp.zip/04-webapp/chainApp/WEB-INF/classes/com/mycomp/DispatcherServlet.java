package com.mycomp;
import java.io.IOException;
import java.io.PrintWriter;

import jakarta.servlet.RequestDispatcher;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;

@WebServlet("/DispatcherServlet")
public class DispatcherServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;

	public void doGet(HttpServletRequest req, HttpServletResponse res)
			throws ServletException, IOException {
		String cmd = req.getQueryString();
		PrintWriter pw = res.getWriter();
		pw.println("Hello! I am DispatcherServlet.");
		if (cmd.equals("include")) {
			RequestDispatcher rd = req.getRequestDispatcher("IncludeServlet");
			rd.include(req, res);
		} else if (cmd.equals("forward")) {
			RequestDispatcher rd = req.getRequestDispatcher("ForwardServlet");
			rd.forward(req, res);
		} 
		pw.close();	
	}
}

