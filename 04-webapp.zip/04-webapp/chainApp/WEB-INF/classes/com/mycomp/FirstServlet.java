package com.mycomp;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.Calendar;
import jakarta.servlet.RequestDispatcher;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;

@WebServlet("/FirstServlet")
public class FirstServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;

	public void doGet(HttpServletRequest req, HttpServletResponse res) throws ServletException, IOException {
		String cmd = req.getQueryString();
		PrintWriter pw = res.getWriter();
		pw.println("Hello! I am FirstServlet.<p/>");
		req.setAttribute("time", getTime());	
		if (cmd.equals("oneway")) {
			RequestDispatcher rd = req.getRequestDispatcher("SecondServlet");
			rd.include(req, res);
			pw.println("Goodbye I am FirstServlet.<p/>");
		} else if (cmd.equals("around")) {
			RequestDispatcher rd = req.getRequestDispatcher("ThirdServlet");
			rd.include(req, res);
			pw.println("Goodbye I am FirstServlet.<p/>");
		}
		pw.close();	
	}
	private String getTime() {
		Calendar c  = Calendar.getInstance();
		return c.get(Calendar.HOUR_OF_DAY) + ":" + 
				   c.get(Calendar.MINUTE) + ":" + 
				   c.get(Calendar.SECOND);
	}
}

