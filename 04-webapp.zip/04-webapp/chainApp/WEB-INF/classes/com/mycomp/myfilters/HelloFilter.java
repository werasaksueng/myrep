package com.mycomp.myfilters;
import java.io.IOException;
import jakarta.servlet.Filter;
import jakarta.servlet.FilterChain;
import jakarta.servlet.FilterConfig;
import jakarta.servlet.ServletException;
import jakarta.servlet.ServletRequest;
import jakarta.servlet.ServletResponse;
import jakarta.servlet.annotation.WebFilter;

@WebFilter("/HelloServlet")
public class HelloFilter implements Filter {
	public void init(FilterConfig cf) throws ServletException { }
	public void destroy() { }
	public void doFilter(ServletRequest req, ServletResponse res,
			FilterChain chain) throws ServletException, IOException {
		if (req.getParameter("name").equals("John"))
			res.getWriter().println("You have no access to the servlet.");
		else
			chain.doFilter(req, res);
	}
}
