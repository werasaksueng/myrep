package com.mycomp.myfilters;
import java.io.IOException;
import jakarta.servlet.Filter;
import jakarta.servlet.FilterChain;
import jakarta.servlet.FilterConfig;
import jakarta.servlet.ServletException;
import jakarta.servlet.ServletRequest;
import jakarta.servlet.ServletResponse;
import jakarta.servlet.annotation.WebFilter;

@WebFilter("/TimerServlet")
public class TimerFilter implements Filter {
	public void init(FilterConfig cf) throws ServletException {  }
	public void destroy() { }
	public void doFilter(ServletRequest req, ServletResponse res,
			FilterChain chain) throws ServletException, IOException {
		long start = System.currentTimeMillis();
		chain.doFilter(req, res);
		long elapsed = System.currentTimeMillis() - start;
		System.out.println(elapsed + " ms.");
	}
}
