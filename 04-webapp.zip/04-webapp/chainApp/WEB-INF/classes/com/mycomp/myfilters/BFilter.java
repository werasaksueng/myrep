package com.mycomp.myfilters;
import java.io.IOException;
import jakarta.servlet.Filter;
import jakarta.servlet.FilterChain;
import jakarta.servlet.FilterConfig;
import jakarta.servlet.ServletException;
import jakarta.servlet.ServletRequest;
import jakarta.servlet.ServletResponse;

public class BFilter implements Filter {
	public void init(FilterConfig cf) throws ServletException { }
	public void destroy() { }
	public void doFilter(ServletRequest req, ServletResponse res,
			FilterChain chain) throws ServletException, IOException {
		System.out.println("Hello I am BFilter.");
		chain.doFilter(req, res);
		System.out.println("Bye I am BFilter.");
	}
}
