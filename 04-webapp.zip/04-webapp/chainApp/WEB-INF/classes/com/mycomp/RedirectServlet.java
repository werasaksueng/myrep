package com.mycomp;
import java.io.*;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.*;

@WebServlet("/RedirectServlet")
public class RedirectServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;

	public void doGet(HttpServletRequest req, HttpServletResponse res) throws IOException {
		PrintWriter pw = res.getWriter();
		String q = req.getQueryString();
		if (q == null)
			pw.println("Hello! I am RedirectServlet.");
		else if (q.equals("my"))
			res.sendRedirect("/chainApp/MyHttpServlet");
		else if (q.equals("apache"))
			res.sendRedirect("http://apache.org");
		pw.close();	
	}
}
