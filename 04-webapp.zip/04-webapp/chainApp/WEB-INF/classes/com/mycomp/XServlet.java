package com.mycomp;
import java.io.*;
import jakarta.servlet.http.*;

public class XServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;

	public void doGet(HttpServletRequest req, HttpServletResponse res) throws IOException {
		PrintWriter pw = res.getWriter();
		pw.println("Hello! I am XServlet.");     
		pw.close();
	}
}
