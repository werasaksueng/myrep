package com.mycomp;
import java.io.IOException;
import java.io.PrintWriter;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.HttpSession;

@WebServlet("/SesServlet")
public class SesServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;

	public void doGet(HttpServletRequest req, HttpServletResponse res) throws ServletException, IOException {
		String cmd = req.getQueryString();
		PrintWriter out = res.getWriter();
		HttpSession hs = req.getSession();
		if (cmd.equals("create")) {
			hs = req.getSession(true);
			out.println("Create Session: " + hs.getId());
		} else if (cmd.equals("destroy")) {
			hs.invalidate();
			out.println("Destroy Session: ");
		} else if (cmd.equals("setHello")) {
			hs.setAttribute("msg", "Hello");
			out.println("msg" + " = " + hs.getAttribute("msg"));
		} else if (cmd.equals("setHi")) {
			hs.setAttribute("msg", "Hi");
			out.println("msg" + " = " + hs.getAttribute("msg"));
		} else if (cmd.equals("get")) {
			out.println("msg" + " = " + hs.getAttribute("msg"));
		} else if (cmd.equals("remove")) {
			hs.removeAttribute("msg");
			out.println("msg" + " = " + hs.getAttribute("msg"));
		}
		out.close();
	}
}
