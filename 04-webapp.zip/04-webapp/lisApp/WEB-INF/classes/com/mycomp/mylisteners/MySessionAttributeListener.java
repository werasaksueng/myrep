package com.mycomp.mylisteners;
import jakarta.servlet.annotation.WebListener;
import jakarta.servlet.http.HttpSession;
import jakarta.servlet.http.HttpSessionAttributeListener;
import jakarta.servlet.http.HttpSessionBindingEvent;

@WebListener
public class MySessionAttributeListener implements HttpSessionAttributeListener {
	public void attributeAdded(HttpSessionBindingEvent e){
		System.out.println("Added: " + "(" + e.getName() + "," + e.getValue() + ") to " + e.getSession().getId());
	}
	public void attributeRemoved(HttpSessionBindingEvent e) {
		System.out.println("Removed: " + "(" + e.getName() + "," + e.getValue() + ") from " + e.getSession().getId());
	}
	public void attributeReplaced(HttpSessionBindingEvent e) {
		HttpSession hs = e.getSession();
		String n = e.getName();
		System.out.println("Replaced: " + "(" + e.getName() + "," + hs.getAttribute(n) + ") in " + hs.getId());
	}
}
