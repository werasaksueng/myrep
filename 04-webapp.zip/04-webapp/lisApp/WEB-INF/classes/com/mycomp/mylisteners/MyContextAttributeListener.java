package com.mycomp.mylisteners;
import jakarta.servlet.ServletContext;
import jakarta.servlet.ServletContextAttributeEvent;
import jakarta.servlet.ServletContextAttributeListener;
import jakarta.servlet.annotation.WebListener;

@WebListener
public class MyContextAttributeListener implements ServletContextAttributeListener {
	public void attributeAdded(ServletContextAttributeEvent e) {
		System.out.println("Added: " + e.getName() + " = " + e.getValue());
	}
	public void attributeRemoved(ServletContextAttributeEvent e) {
		System.out.println("Removed: " + e.getName());
	}
	public void attributeReplaced(ServletContextAttributeEvent e) {
		ServletContext sc = e.getServletContext();
		String name = e.getName();
		System.out.println("Replace: " + name + " form " + e.getValue() + " to " + sc.getAttribute(name));
	}
}
