package com.mycomp.mylisteners;
import jakarta.servlet.annotation.WebListener;
import jakarta.servlet.http.HttpSessionEvent;
import jakarta.servlet.http.HttpSessionListener;

@WebListener
public class MySessionListener implements HttpSessionListener {
	public void sessionCreated(HttpSessionEvent e) {
		System.out.println("Create Session: " + e.getSession().getId());
	}
	public void sessionDestroyed(HttpSessionEvent e) {
		System.out.println("Destroy Session: " + e.getSession().getId());
	}
}