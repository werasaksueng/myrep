package com.mycomp.mylisteners;
import jakarta.servlet.ServletContextEvent;
import jakarta.servlet.ServletContextListener;
import jakarta.servlet.annotation.WebListener;

@WebListener
public class MyContextListener implements ServletContextListener {
	public void contextInitialized(ServletContextEvent e) {
		System.out.println("context Initialized");
	}
	public void contextDestroyed(ServletContextEvent e) {
		System.out.println("context Destroyed");
	}
}
