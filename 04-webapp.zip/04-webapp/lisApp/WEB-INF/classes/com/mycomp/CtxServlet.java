package com.mycomp;
import java.io.IOException;
import java.io.PrintWriter;
import jakarta.servlet.ServletContext;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;

@WebServlet("/CtxServlet")
public class CtxServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;

	public void doGet(HttpServletRequest req, HttpServletResponse res) throws ServletException, IOException {
		String cmd = req.getQueryString();
		PrintWriter out = res.getWriter();
		ServletContext sc = getServletContext();
		if (cmd.equals("setHello")) {
			sc.setAttribute("msg", "Hello");
			out.println("msg = " + sc.getAttribute("msg"));
		} else if (cmd.equals("setHi")) {
			sc.setAttribute("msg", "Hi");
			out.println("msg = " + sc.getAttribute("msg"));
		} else if (cmd.equals("get")) {
			out.println("msg = " + sc.getAttribute("msg"));
		} else if (cmd.equals("remove")) {
			sc.removeAttribute("msg");
			out.println("msg = "  + sc.getAttribute("msg"));
		}
		out.close();
	}
}