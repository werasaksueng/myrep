package com.mycomp;

import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.PrintWriter;
import java.util.Map;
import javax.servlet.GenericServlet;
import javax.servlet.ServletException;
import javax.servlet.ServletRequest;
import javax.servlet.ServletResponse;
import javax.servlet.annotation.WebServlet;

@WebServlet("/SerialServlet")
public class SerialServlet extends GenericServlet {	
	private static final long serialVersionUID = 1L;

	public void service(ServletRequest req, ServletResponse res) throws ServletException, IOException {
		ObjectInputStream ois = new ObjectInputStream(req.getInputStream());
		Map<?, ?> m = null;
		try {
			m = (Map<?, ?>) ois.readObject();
		} catch(ClassNotFoundException ex) {
			return;
		}
		String product = (String) m.get("product");
		String amount = (String) m.get("amount");
		PrintWriter pw = res.getWriter();
		pw.print(product + "," + amount);
		System.out.println(product + "," + amount);
		ois.close();
		pw.close();
	} 
}
