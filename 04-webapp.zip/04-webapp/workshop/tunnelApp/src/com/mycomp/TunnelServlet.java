package com.mycomp;
import java.io.IOException;
import javax.servlet.ServletInputStream;
import java.io.PrintWriter;

import javax.servlet.GenericServlet;
import javax.servlet.ServletException;
import javax.servlet.ServletRequest;
import javax.servlet.ServletResponse;
import javax.servlet.annotation.WebServlet;
@WebServlet("/TunnelServlet")
public class TunnelServlet extends GenericServlet {
	private static final long serialVersionUID = 1L;

	public void service(ServletRequest req, ServletResponse res) throws ServletException, IOException {
		ServletInputStream sis = req.getInputStream();
		byte[] b = new byte[100];
		sis.read(b, 0, 100);
		String name = new String(b).trim();
		System.out.println(name);

		PrintWriter pw = res.getWriter();
		pw.print("Hello! " + name);
		pw.close();
	} 
}
