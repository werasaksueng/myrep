import java.io.*;
import java.net.*;
import java.util.*;
import javax.swing.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
class SwingClient {
	static URLConnection getConnection() throws RuntimeException {
		try {
			URL u = new URL("http://localhost:8080/tunApp/SerialServlet");
			URLConnection c = u.openConnection();
			c.setUseCaches(false);
			c.setRequestProperty("CONTENT_TYPE", "application/octet-stream");
			c.setDoOutput(true);
			c.setDoInput(true);
			return c;
		} catch(Exception ex) {
			throw new RuntimeException();
		}
	}
	public static void main(String[] args) throws Exception {
		JFrame fr = new JFrame("Order Application");
        	fr.setSize(400, 300);
        	fr.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        	fr.setLayout(null);  // For absolute positioning.

		JLabel lb1 = new JLabel("Product");
		lb1.setBounds(50, 50, 130, 30);
		fr.add(lb1);
		JTextField tf1 = new JTextField();
		tf1.setBounds(120, 50, 100, 30);
		fr.add(tf1);

		JLabel lb2 = new JLabel("Amount");
		lb2.setBounds(50, 100, 130, 30);
		fr.add(lb2);
		JTextField tf2 = new JTextField();
		tf2.setBounds(120, 100, 100, 30);
		fr.add(tf2);

		JLabel lb3 = new JLabel("Response");
		lb3.setBounds(30, 170, 200, 30);
		fr.add(lb3);

		JButton bt = new JButton("Sumbit");
		bt.setBounds(200, 150, 100, 40);
		fr.add(bt);
		bt.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent e) {
				HashMap<String, String> hm = new HashMap<String, String>();
				hm.put("product", tf1.getText());
				hm.put("amount", tf2.getText());
				URLConnection c = getConnection();
				try (ObjectOutputStream oos = new ObjectOutputStream(c.getOutputStream()); ) {
					oos.writeObject(hm);
					oos.flush();
				} catch (Exception ex) {
					System.out.println(ex);
				}
				try (InputStream is = c.getInputStream(); ) {
					byte [ ] b = new byte[is.available()];
					is.read(b);
					lb3.setText("Confirm: " + new String(b));
				} catch (Exception ex) {
					System.out.println(ex);
				}
			}
		});
		fr.setVisible(true);
	}	
}
