import java.io.*;
import java.net.*;
import java.util.*;
class SerialClient {
	public static void main(String args[]) throws Exception {
		URL u = new URL("http://localhost:8080/tunApp/SerialServlet");
		URLConnection c = u.openConnection();
		c.setUseCaches(false);
		c.setRequestProperty("CONTENT_TYPE", "application/octet-stream");
		c.setDoOutput(true);
		c.setDoInput(true);

		HashMap<String, String> m = new HashMap<String, String>();
		m.put("product", args[0]);
		m.put("amount", args[1]);

		ObjectOutputStream oos = new ObjectOutputStream(c.getOutputStream());
		oos.writeObject(m);
		oos.flush();
		oos.close();

		InputStream is = c.getInputStream();
		byte [ ] b = new byte[is.available()];
		is.read(b);
		System.out.println(new String(b));
		is.close();
	}
}
// java SerialClient abc 10