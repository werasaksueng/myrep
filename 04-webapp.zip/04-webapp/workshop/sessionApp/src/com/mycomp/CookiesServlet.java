package com.mycomp;
import java.io.*;
import javax.servlet.*;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.*;

@WebServlet("/CookiesServlet")
public class CookiesServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
	private Cookie[] ck;
	public void doGet(HttpServletRequest req, HttpServletResponse res)
			throws IOException, ServletException {
		String name = req.getParameter("name");
		String ses = null;
		ck = req.getCookies();
		if (ck == null) {
			ses = name.hashCode() + "";	// getSessionId(name);
			res.addCookie(new Cookie("sessionid", ses));
		} else
			ses = ck[0].getValue();
			
		String pname = req.getParameter("product");
		String amount = req.getParameter("amount");
		if (pname != null && amount != null) {
			System.out.println(ses + "," + pname + "," + amount);
			res.addCookie(new Cookie(pname, amount));
		}

		res.setContentType("text/html");
	        PrintWriter pw = res.getWriter();
		pw.print("<form method=GET action=" + req.getRequestURI() + ">");
		pw.print("Product <input type=text name=product><br>");
		pw.print("Amount <input type=text name=amount><br>");
		pw.print("<input type=submit value=Add></form>");

		pw.print("<form method=POST action=" + req.getRequestURI() + ">");
		pw.print("<input type=submit value=End></form>");
		pw.close();
	}
	public void doPost(HttpServletRequest req, HttpServletResponse res)
			throws IOException, ServletException {
		ck = req.getCookies();
		PrintWriter pw = res.getWriter();
		for (int i = 1; i < ck.length; i++) {
			pw.println(ck[i].getName() + ", " + ck[i].getValue());
		}
		pw.close();	
	}
}