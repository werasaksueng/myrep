package com.mycomp;
import java.io.*;
import java.util.*;
import javax.servlet.*;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.*;

@WebServlet("/SessionServlet")
public class SessionServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
	public void doGet(HttpServletRequest req, HttpServletResponse res)
			throws IOException, ServletException {
		HttpSession hs = req.getSession(true);
		String p = req.getParameter("product");
		String a = req.getParameter("amount");
		if (p != null && a != null) {
			System.out.println(p + "," + a + " : " + hs.getId());
			hs.setAttribute(p, a);
		}

		res.setContentType("text/html");
	        PrintWriter pw = res.getWriter();
		pw.print("<form method=GET action=" + req.getRequestURI() + ">");
		pw.print("Product <input type=text name=product><br>");
		pw.print("Amount <input type=text name=amount><br>");
		pw.print("<input type=submit value=Add></form>");

		pw.print("<form method=POST action=" + req.getRequestURI() + ">");
		pw.print("<input type=submit value=End></form>");
		pw.close();
	}
	public void doPost(HttpServletRequest req, HttpServletResponse res)
			throws IOException, ServletException {
		HttpSession hs = req.getSession(false);
		Enumeration<String> e = hs.getAttributeNames();
		PrintWriter pw = res.getWriter();
		pw.println("session: " + hs.getId());
		while (e.hasMoreElements()) {
			String s = (String) e.nextElement();
			pw.println(s + ", " + hs.getAttribute(s));
		}
		hs.invalidate();
		pw.close();	
	}
}