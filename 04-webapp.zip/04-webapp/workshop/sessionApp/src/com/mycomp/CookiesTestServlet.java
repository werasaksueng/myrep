package com.mycomp;
import java.io.*;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.*;

@WebServlet("/CookiesTestServlet")
public class CookiesTestServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;

	public void doGet(HttpServletRequest req, HttpServletResponse res) throws IOException {
		String cmd = req.getQueryString();
		PrintWriter pw = res.getWriter();	
		if (cmd.equals("set")) {
			res.setHeader("Set-Cookie: ", "name=John Rambo; Max-age=10");
			pw.println("Set Cookies Ok");
		} else if (cmd.equals("add")) {
			Cookie c = new Cookie("id", "12345");
			c.setMaxAge(3600);
			res.addCookie(c);
			pw.println("Add Cookies Ok");
		}
		pw.close();
	}
}
// curl http://localhost:8080/sesApp/CookiesTestServlet?set -i
// curl http://localhost:8080/sesApp/CookiesTestServlet?add -i