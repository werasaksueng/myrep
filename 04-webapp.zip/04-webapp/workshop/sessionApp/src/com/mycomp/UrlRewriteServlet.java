package com.mycomp;
import java.io.*;
import java.util.*;
import javax.servlet.*;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.*;

@WebServlet("/UrlRewriteServlet/*")
public class UrlRewriteServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;

	public void doGet(HttpServletRequest req, HttpServletResponse res)
			throws IOException, ServletException {
		String path = req.getPathInfo();
		String uri = req.getRequestURI();
		String name = req.getParameter("name");
		String sid = null;
		if (path == null) {
			sid = name + UUID.randomUUID().toString();
			uri += "/sid=" + sid;
		} else
			sid = path.substring(path.indexOf("=")+1, path.length());

		String p = req.getParameter("product");
		String a = req.getParameter("amount");
		if (p != null && a != null)
			System.out.println(p + "," + a + " : " + sid);

		res.setContentType("text/html");
		PrintWriter pw = res.getWriter();
		pw.print("<form method=GET action=" + res.encodeURL(uri) + ">");
		pw.print("Product <input type=text name=product><br>");
		pw.print("Amount <input type=text name=amount><br>");
		pw.print("<input type=submit value=Add></form>");
		pw.close();
	}
}