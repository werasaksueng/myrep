package com.mycomp;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.UUID;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

@WebServlet("/HiddenFieldServlet")
public class HiddenFieldServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;

	public void doGet(HttpServletRequest req, HttpServletResponse res)
			throws IOException, ServletException {
		String name = req.getParameter("name");
		String sid = req.getParameter("sid");
		if (sid == null)
			sid = name + UUID.randomUUID().toString();
			
		String p = req.getParameter("product");
		String a = req.getParameter("amount");
		if (p != null && a != null)
			System.out.println(p + "," + a + " : " + sid);

		res.setContentType("text/html");
		PrintWriter pw = res.getWriter();
		pw.print("<form method=GET action=" + req.getRequestURI() + ">");
		pw.print("<input type=hidden name=sid value="+sid+">");
		pw.print("Product <input type=text name=product><br>");
		pw.print("Amount <input type=text name=amount><br>");
		pw.print("<input type=submit value=Add></form>");
		pw.close();
	}
}