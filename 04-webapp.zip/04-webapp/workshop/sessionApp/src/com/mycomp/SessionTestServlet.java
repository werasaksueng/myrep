package com.mycomp;
import javax.servlet.*;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.*;
import java.io.*;

@WebServlet("/SessionTestServlet")
public class SessionTestServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
	
	private int i = 0;
	public void doGet(HttpServletRequest req, HttpServletResponse res)
        		throws ServletException, IOException {
		res.setContentType("text/html");
		PrintWriter out = res.getWriter();
		out.print("<html>");
	        HttpSession s = req.getSession(true);
		String a = req.getParameter("action");
		if (a != null && a.equals("invalidate"))
			s.invalidate();
		else {
			out.print("Session ID: " + s.getId() + "<br>");
			out.print("isNew(): " + s.isNew()+ "<br>");
			out.print("Create time: " + s.getCreationTime()+ "<br>");
			out.print("This page is accessed " + ++i + " times.<br>");
		}
		String url = req.getRequestURI();
		// String url = res.encodeURL(req.getRequestURI());
		out.print("<a href=" + url + " method=GET> Reload </a><br>");
		out.print("<a href=" + url + "?action=invalidate method=GET> Invalidate </a>");
		out.print("</html>");
	}
}