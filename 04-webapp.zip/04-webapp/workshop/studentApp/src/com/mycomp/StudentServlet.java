// JDK 8, TOMCAT 9
package com.mycomp;
import java.io.*;
import javax.servlet.http.*;
import javax.servlet.annotation.WebServlet;

@WebServlet("/StudentServlet")
public class StudentServlet extends HttpServlet {
	public void doGet(HttpServletRequest req, HttpServletResponse res)
			throws IOException {
		int id = Integer.parseInt(req.getParameter("id"));
		Student s = StudentDS.get(id);
		PrintWriter pw = res.getWriter();
		pw.println(s);
		pw.close();
	}
}

