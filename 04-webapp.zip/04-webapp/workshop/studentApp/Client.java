import java.io.*;
import java.net.*;
class Client {
	public static void main(String args[]) throws Exception {
		String id = args[0];
		URL u = new URL("http://localhost:8080/stuApp/StudentServlet?id="+id);
		URLConnection c = u.openConnection();
		c.setUseCaches(false);
		c.setDoInput(true);

		InputStream is = c.getInputStream();
		byte [ ] b = new byte[is.available()];
		is.read(b);
		System.out.println(new String(b).trim());
	}
}
// javac Client.java
// java Client 1
