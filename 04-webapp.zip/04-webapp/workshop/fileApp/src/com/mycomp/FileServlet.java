// JDK 8, TOMCAT 9
package com.mycomp;
import java.io.*;
import javax.servlet.*;
import javax.servlet.http.*;
import javax.servlet.annotation.WebServlet;

@WebServlet("/FileServlet")
public class FileServlet extends HttpServlet {
	private byte[] readFile(String fname) throws IOException {
		ServletContext sc = getServletContext();
		InputStream is =  sc.getResourceAsStream("/WEB-INF/files/" + fname);
		byte b[] = new byte[is.available()];
		is.read(b);
		is.close();
		return b;
	}
	private String fileType(String fn) {
		String ex = fn.substring(fn.indexOf("."));
		return (ex.equals("gif"))? "image/gif" : "text/plain";
	}
	@Override
	public void doGet(HttpServletRequest req, HttpServletResponse res) throws ServletException, IOException {
		String fn = req.getQueryString();
		byte b[] = readFile(fn);
		res.setHeader("Content-type", fileType(fn));
		res.setHeader("Content-Length", b.length + "");
		OutputStream os = res.getOutputStream();
		os.write(b);
		os.close();	
	}
}
/* ServletContext.getResourcePaths(String path) returns a   
 Set<String> containing the paths to the resources
  in the specified directory.

Try: Show all files in the 'files' directory and let user
  click on the file that want to download.
 */

