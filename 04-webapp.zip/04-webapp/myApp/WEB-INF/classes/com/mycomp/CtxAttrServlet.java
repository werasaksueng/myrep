package com.mycomp;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletContext;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

@WebServlet("/CtxAttrServlet")
public class CtxAttrServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
	@Override
	protected void doGet(HttpServletRequest req, HttpServletResponse res) throws ServletException, IOException {
		ServletContext ctx = getServletContext();
		PrintWriter pw = res.getWriter();
		String cmd = req.getQueryString();
		if (cmd.equals("set")) {
			ctx.setAttribute("my.msg", "Hello!");
			pw.println("Set my.msg.");   
		} if (cmd.equals("get")) {
			String m = (String) ctx.getAttribute("my.msg");
			pw.println(m);   
		} if (cmd.equals("remove")) {
			ctx.removeAttribute("my.msg");
			pw.println("Remove my.msg.");   
		} 
		pw.close();
	}
}

