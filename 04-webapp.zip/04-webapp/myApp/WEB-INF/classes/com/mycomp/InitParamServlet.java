package com.mycomp;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebInitParam;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

@WebServlet(urlPatterns="/InitParamServlet",
			initParams={
				@WebInitParam(name="version", value="1.1"),
				@WebInitParam(name="target", value="john.com")
			} )
public class InitParamServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
	@Override
	public void doGet(HttpServletRequest req, HttpServletResponse res) throws ServletException, IOException {
			String v = getInitParameter("version");
			String t = getInitParameter("target");
			PrintWriter pw = res.getWriter();
			pw.println(v + ", " + t);
			pw.close();
	}
}
/* getInitParameter() may be obtained from ServletConfig or ServletContext.
 * ServletConfig is passed as a parameter to service().
 * HttpServlet implements ServletContext.
 */


