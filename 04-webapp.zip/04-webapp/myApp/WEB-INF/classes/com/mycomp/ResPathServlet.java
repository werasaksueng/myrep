package com.mycomp;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.Iterator;
import java.util.Set;

import javax.servlet.ServletContext;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
@WebServlet("/ResPathServlet")
public class ResPathServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
	@Override
	public void doGet(HttpServletRequest req, HttpServletResponse res) throws ServletException, IOException {
		ServletContext ctx = getServletContext();
		Set<String> s = ctx.getResourcePaths("/WEB-INF/files");
		PrintWriter pw = res.getWriter();
		Iterator<String> i = s.iterator();
		while(i.hasNext())
			pw.print(i.next().substring("/WEB-INF/files".length()) + ", ");
		pw.close(); 
	}
}
