package com.mycomp;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletContext;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

@WebServlet("/CtxParamServlet")
public class CtxParamServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
	@Override
	public void doGet(HttpServletRequest req, HttpServletResponse res) throws ServletException, IOException {
		ServletContext ctx = getServletContext();
		String c = ctx.getInitParameter("company");
		String e = ctx.getInitParameter("email");
		PrintWriter pw = res.getWriter();
		pw.println(c + ", " + e);
		pw.close();
	}
}

