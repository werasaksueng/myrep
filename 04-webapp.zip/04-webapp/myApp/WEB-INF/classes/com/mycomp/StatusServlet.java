package com.mycomp;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

@WebServlet("/StatusServlet")
public class StatusServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
	@Override
	protected void doGet(HttpServletRequest req, HttpServletResponse res) throws ServletException, IOException {
		String q = req.getQueryString();
		if (q == null) {
			PrintWriter pw = res.getWriter();
			pw.println("Hello! I am StatusServlet.");
			pw.close();
		}
		else if (q.equals("john"))
			res.setStatus(HttpServletResponse.SC_FORBIDDEN);
		else
			res.setStatus(HttpServletResponse.SC_NOT_FOUND);
	}
}
/*
http://localhost:8080/myApp/StatusServlet
http://localhost:8080/myApp/StatusServlet?john
http://localhost:8080/myApp/StatusServlet?jack

HttpServletResponse.SC_CONTINUE
HttpServletResponse.SC_SWITCHING_PROTOCOLS
HttpServletResponse.SC_OK
HttpServletResponse.SC_CREATED
HttpServletResponse.SC_ACCEPTED
HttpServletResponse.SC_NON_AUTHORITATIVE_INFORMATION
HttpServletResponse.SC_NO_CONTENT
HttpServletResponse.SC_RESET_CONTENT
HttpServletResponse.SC_PARTIAL_CONTENT
HttpServletResponse.SC_MULTIPLE_CHOICES
HttpServletResponse.SC_MOVED_PERMANENTLY
HttpServletResponse.SC_MOVED_TEMPORARILY
HttpServletResponse.SC_FOUND
HttpServletResponse.SC_SEE_OTHER
HttpServletResponse.SC_NOT_MODIFIED
HttpServletResponse.SC_USE_PROXY
HttpServletResponse.SC_TEMPORARY_REDIRECT
HttpServletResponse.SC_BAD_REQUEST
HttpServletResponse.SC_UNAUTHORIZED
HttpServletResponse.SC_PAYMENT_REQUIRED
HttpServletResponse.SC_FORBIDDEN
HttpServletResponse.SC_NOT_FOUND
HttpServletResponse.SC_METHOD_NOT_ALLOWED
HttpServletResponse.SC_NOT_ACCEPTABLE
HttpServletResponse.SC_PROXY_AUTHENTICATION_REQUIRED
HttpServletResponse.SC_REQUEST_TIMEOUT
HttpServletResponse.SC_CONFLICT
HttpServletResponse.SC_GONE
HttpServletResponse.SC_LENGTH_REQUIRED
HttpServletResponse.SC_PRECONDITION_FAILED
HttpServletResponse.SC_REQUEST_ENTITY_TOO_LARGE
HttpServletResponse.SC_REQUEST_URI_TOO_LONG
HttpServletResponse.SC_UNSUPPORTED_MEDIA_TYPE
HttpServletResponse.SC_REQUESTED_RANGE_NOT_SATISFIABLE
HttpServletResponse.SC_EXPECTATION_FAILED
HttpServletResponse.SC_INTERNAL_SERVER_ERROR
HttpServletResponse.SC_NOT_IMPLEMENTED
HttpServletResponse.SC_BAD_GATEWAY
HttpServletResponse.SC_SERVICE_UNAVAILABLE
HttpServletResponse.SC_GATEWAY_TIMEOUT
HttpServletResponse.SC_HTTP_VERSION_NOT_SUPPORTED
*/