package com.mycomp;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.Date;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
@WebServlet("/LogServlet")
public class LogServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
	@Override
	protected void doGet(HttpServletRequest req, HttpServletResponse res) throws ServletException, IOException {
		String msg = "Hello! " + new Date().getTime();
		getServletContext().log(msg);
		PrintWriter pw = res.getWriter();
		pw.println(msg);
		pw.close();
	}
}
// C:\jee\etc\apache-tomcat-10.1.24\logs\localhost.yyyy-mm-dd.log
