package com.mycomp;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.GenericServlet;
import javax.servlet.ServletException;
import javax.servlet.ServletRequest;
import javax.servlet.ServletResponse;
import javax.servlet.annotation.WebServlet;

@WebServlet("/ReqServlet")
public class ReqServlet extends GenericServlet {
	private static final long serialVersionUID = 1L;
	@Override
	public void service(ServletRequest req, ServletResponse res) throws ServletException, IOException {
		PrintWriter pw = res.getWriter();
		pw.println("Protocol: " + req.getProtocol() + "<br/>");
		pw.println("Scheme: " + req.getScheme() + "<br/>");
		pw.println("ServerName: " + req.getServerName() + "<br/>");
		pw.println("ServerPort: " + req.getServerPort() + "<br/>");
		pw.println("RemoteHost: " + req.getRemoteHost() + "<br/>");
		pw.println("Locale: " + req.getLocale().getDisplayName() + "<br/>");
		
			// for POST request
	//	pw.println("ContentType: " + req.getContentType() + "<br/>");
	//	pw.println("ContentLength: " + req.getContentLength() + "<br/>");   
		pw.close();
	}
}
