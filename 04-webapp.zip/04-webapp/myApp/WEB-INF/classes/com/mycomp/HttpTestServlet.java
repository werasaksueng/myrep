package com.mycomp;
import java.io.*;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.*;
@WebServlet("/HttpTestServlet")
public class HttpTestServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
	@Override
	public void doGet(HttpServletRequest req, HttpServletResponse res) throws IOException {
		res.getWriter().println("That was a GET");   
	}
	@Override
	public void doPut(HttpServletRequest req, HttpServletResponse res) throws IOException {
		res.getWriter().println("That was a PUT");     
	}
	@Override
	public void doPost(HttpServletRequest req, HttpServletResponse res) throws IOException {
		res.getWriter().println("That was a POST");     
	}
	@Override
	public void doDelete(HttpServletRequest req, HttpServletResponse res) throws IOException {
		res.getWriter().println("That was a Delete");     
	}
}
