
package com.mycomp;

import javax.ws.rs.*;

@Path("greet")
public class Greet {
	@GET
	public String hello() {
		return "Hello";
	}

	@GET
	@Path("hi")
	public String hi() {
		return "Hi";
	}

	@GET
	@Path("{name}")
	public String pathParam(@PathParam("name") String n) {
		return "What's up? " + n + " (PathParam)";
	}

	@GET
	@Path("query")
	public String queryParam(@QueryParam("name") String n) {
		return "Hello! " + n + " (QueryParam)";
	}

	@POST
	@Path("form")
	public String formParam(@FormParam("name") String n) {
		return "Hello! " + n + " (FormParam)";
	}
}
// http://localhost:8080/rs2App/rest/greet
// http://localhost:8080/rs2App/rest/greet/hi
// http://localhost:8080/rs2App/rest/greet/john
// http://localhost:8080/rs2App/rest/greet/query?name=jack