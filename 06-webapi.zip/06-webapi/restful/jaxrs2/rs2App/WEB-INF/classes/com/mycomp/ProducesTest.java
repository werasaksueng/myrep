
package com.mycomp;

import javax.ws.rs.*;

@Path("produces")
public class ProducesTest {
	@GET
	@Path("txt")
	@Produces("text/plain")
	public String helloTxt() {	
		return "Hello";
	}

	@GET
	@Path("html")
	@Produces("text/html")
	public String helloHtml() {	
		return "<h1>Hello</h1>";
	}

	@GET
	@Path("xml")
	@Produces("text/xml")
	public String helloXml() {	
		return "<greet>Hello</greet>";
	}
}
// http://localhost:8080/rs2App/rest/produces/txt
// http://localhost:8080/rs2App/rest/produces/html
// http://localhost:8080/rs2App/rest/produces/xml