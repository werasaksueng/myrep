package com.mycomp;

import java.util.HashSet;
import java.util.Set;

import javax.ws.rs.ApplicationPath;
import javax.ws.rs.core.Application;

@ApplicationPath("/")
public class App extends Application {
    @Override
    public Set<Class<?>> getClasses() {
        HashSet<Class<?>> hs = new HashSet<Class<?>>();
        hs.add(Greet.class);
	hs.add(ProducesTest.class);
	hs.add(MyResource.class);
        return hs;
    }
}
