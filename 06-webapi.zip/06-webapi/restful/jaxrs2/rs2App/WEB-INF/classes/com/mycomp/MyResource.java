
package com.mycomp;

import javax.ws.rs.*;

@Path("myres")
public class MyResource {
	@GET
	@Path("{id}")
	public String read(@PathParam("id") String id) {	
		return "Read Id: " + id;
	}

	@POST
	public String insert() {	
		return "Insert";
	}

	@PUT
	public String update() {	
		return "Update";
	}

	@DELETE
	public String delete() {
		return "Delete";
	}
}