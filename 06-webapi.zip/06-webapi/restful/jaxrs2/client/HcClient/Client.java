import java.io.IOException;
import org.apache.http.client.HttpClient;
import org.apache.http.client.methods.HttpDelete;
import org.apache.http.client.methods.HttpGet;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.client.methods.HttpPut;
import org.apache.http.impl.client.DefaultHttpClient;
import org.apache.http.util.EntityUtils;
class Client {
	public final static void main(String[] args) throws IOException {
		HttpClient hc = new DefaultHttpClient();

		HttpGet hg = new HttpGet("http://localhost:8080/rs2App/rest/myres/1");
		System.out.println(EntityUtils.toString(hc.execute(hg).getEntity()));

		HttpPost hpo = new HttpPost("http://localhost:8080/rs2App/rest/myres");
		System.out.println(EntityUtils.toString(hc.execute(hpo).getEntity()));

		HttpPut hpu = new HttpPut("http://localhost:8080/rs2App/rest/myres");
		System.out.println(EntityUtils.toString(hc.execute(hpu).getEntity()));
		
		HttpDelete hd = new HttpDelete("http://localhost:8080/rs2App/rest/myres");
		System.out.println(EntityUtils.toString(hc.execute(hd).getEntity()));
	}
}