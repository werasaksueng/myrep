
import javax.ws.rs.client.Client;
import javax.ws.rs.client.ClientBuilder;
import javax.ws.rs.client.Entity;

public class MyClient {
	public static void main(String args[]) {
		Client c = ClientBuilder.newClient();
		String res = c.target("http://localhost:8080/rs2App/rest/myres")
				.path("1")
				.request("text/plain")
				.get(String.class);
		System.out.println(res);

		res = c.target("http://localhost:8080/rs2App/rest/myres")
				.request("text/plain")
				.post(null)
				.readEntity(String.class);
		System.out.println(res);

		res = c.target("http://localhost:8080/rs2App/rest/myres")
				.request("text/plain")
				.put(Entity.text("hello"))
				.readEntity(String.class);
		System.out.println(res);

		res = c.target("http://localhost:8080/rs2App/rest/myres")
				.request("text/plain")
				.delete()
				.readEntity(String.class);
		System.out.println(res);
	}
}
