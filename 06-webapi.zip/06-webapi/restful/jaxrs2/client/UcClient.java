import java.io.*;
import java.net.*;
class UcClient {
	static void send(URLConnection uc) throws IOException {
		uc.setDoInput(true);
		uc.setDoOutput(true);
		uc.connect();
		BufferedReader br = new BufferedReader(
			new InputStreamReader(uc.getInputStream()));
		String line;
		while ((line = br.readLine()) != null)
			System.out.println(line);
		br.close();
	}

	static void doSend(String method, String path) throws IOException {
		HttpURLConnection uc = (HttpURLConnection) new URL(path).openConnection();
                uc.setRequestMethod(method);
		send(uc);
	}
	
	public static void main(String[] args) throws Exception {
		doSend("GET", "http://localhost:8080/rs2App/rest/myres/1");
		doSend("POST", "http://localhost:8080/rs2App/rest/myres");
		doSend("PUT", "http://localhost:8080/rs2App/rest/myres");
		doSend("DELETE", "http://localhost:8080/rs2App/rest/myres");
	}
}
