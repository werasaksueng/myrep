import javax.ws.rs.*;
import com.sun.jersey.api.container.grizzly.GrizzlyServerFactory;
public class MyServer {
	@Path("myres")
	public static class MyResource {
		@GET
		public String hello() {
			return "Hello";
		}
		@GET
		@Path("hi")
		public String hi() {
			return "Hi";
		}

		@GET
		@Path("{name}")
		public String greet(@PathParam("name") String n) {
			return "What's up? " + n;
		}

		@POST
		public String post() {
			return "Post";
		}

		@PUT
		public String put() {
			return "Put";
		}

		@DELETE
		public String delete() {
			return "Delete";
		}
	}
	public static void main(String[] args) throws Exception {
		GrizzlyServerFactory.create("http://localhost:8081");
		System.out.println("Server ready.");
	}
}
// http://localhost:8081/application.wadl
// http://localhost:8081/myres
// http://localhost:8081/myres/hi
// http://localhost:8081/myres/john
