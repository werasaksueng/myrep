import com.sun.jersey.api.client.*;
public class MyClient {
	public static void main(String[] args) throws Exception {
		Client c = Client.create();
		WebResource wr = c.resource("http://localhost:8081/myres");
		System.out.println(wr.get(String.class));

		wr = c.resource("http://localhost:8081/myres/hi");
		System.out.println(wr.get(String.class));

		wr = c.resource("http://localhost:8081/myres/John");
		System.out.println(wr.get(String.class));

		wr = c.resource("http://localhost:8081/myres");
		System.out.println(wr.post(String.class));
		System.out.println(wr.put(String.class));
		System.out.println(wr.delete(String.class));
	}
}