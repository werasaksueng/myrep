import com.mycomp.*;
class Client {
	public static void main(String args[]) {
		HelloService hs = new HelloService();
		Hello h = hs.getHelloPort();
		System.out.println(h.greet(args[0]));
	}
}