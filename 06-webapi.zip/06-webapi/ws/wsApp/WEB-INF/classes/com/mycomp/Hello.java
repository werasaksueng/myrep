// Hello.java
package com.mycomp;
import javax.jws.WebService;
import javax.jws.soap.SOAPBinding;
@WebService
@SOAPBinding(style=SOAPBinding.Style.RPC)
public class Hello {
	public String greet(String name) {
		System.out.println(name);
		return "Hello! " + name + " I am Hello(jaxws).";
	}
}


