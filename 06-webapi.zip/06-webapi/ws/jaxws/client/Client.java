import com.mycomp.*;
class Client {
	public static void main(String args[]) {
		HelloImplService hs = new HelloImplService();
		Hello h = hs.getHelloImplPort();
		System.out.println(h.greet(args[0]));
	}
}