import com.mycomp.*;
import javax.xml.ws.Endpoint;
public class Server {
	public static void main(String[] args) {
		Endpoint ep = Endpoint.publish(
		  "http://localhost:8081/hello", new HelloImpl());
		System.out.println("Services start.");
	}
}
// http://localhost:8081/hello?wsdl
