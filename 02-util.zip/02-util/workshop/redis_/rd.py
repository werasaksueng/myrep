## pip install redis

import redis
r = redis.Redis() # host='localhost', port=6379, db=0, 
                  # password=None, socket_timeout=None,...
# print(r.ping())

# Data are dumped into 'dump.rdb' in working directory when the server
#  is closed or as defined by:
#       save <seconds> <changes>
# If the server is closed and 'dump.rdb' is deleted all data will be lost.

# Redis implements a connection pool, 'r' needs no closing.

def test():
    r.set('john', 'john@rambo.com')
    r.set('jack', 'jack@ripper.com')

    print(r.get('john').decode()) 
test()

