import redis.clients.jedis.Jedis;

public class Get {
    public static void main(String[] args) {
        try (Jedis jd = new Jedis("localhost", 6379)) {
            System.out.println(jd.get(args[0]));
        } catch (Exception e) {
            System.err.println("Error: " + e.getMessage());
        }
    }
}