import redis.clients.jedis.Jedis;

public class Set {
    public static void main(String[] args) {
        // Connecting to Redis server on localhost:6379 (default)
        try () {
            System.out.println("Connection to Redis server successfully");
            System.out.println("Server is running: " + jd.ping());

            // Set key : value.
            jd.set("john", "rambo");
            jd.set("jack", "ripper");		
        } catch (Exception e) {
            System.err.println("Error: " + e.getMessage());
        }
    }
}