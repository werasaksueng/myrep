import java.security.*;
import redis.clients.jedis.Jedis;
class Login {
    public static String md5(String input) {
        try {
            MessageDigest md = MessageDigest.getInstance("MD5");
            byte[] ba = md.digest(input.getBytes("UTF-8"));
            
            // Convert the byte array to a hex string
            StringBuilder hexString = new StringBuilder();
            for (byte b : ba) {
                String hex = Integer.toHexString(0xff & b); // Convert to unsigned hex
                if (hex.length() == 1) {
                    hexString.append('0'); // Add leading zero if needed
                }
                hexString.append(hex);
            }
            return hexString.toString();
        } catch (Exception e) {
            throw new RuntimeException("Error while hashing with MD5", e);
        }
    }

    private static Jedis jd = new Jedis("localhost", 6379);

    public static String register(String name, String pwd) throws Exception{
        // No error checking for simplicity.
        jd.set(name, md5(pwd));
        return "Register: " + name;    
    }

    public static String login(String name, String pwd) throws Exception{
        if (md5(pwd).equals(jd.get(name)))
            return "Valid";
        else
            return "Invalid";
    }

    public static void main(String args[]) throws Exception{
        // System.out.println("Redis is running: " + jd.ping());    
        System.out.println(register("john", "hello123"));
        System.out.println(register("jame", "hello007"));
        System.out.println(login("jame", "hello124"));
        System.out.println(login("john", "hello123"));
    }
}