package junit.tester;

import org.junit.Test;
import com.mycomp.Hello;

public class HelloJack {
	@Test
	public void test1() {
		Hello h = new Hello();
		System.out.println(h.greet("Jack Ripper"));
	}
}
