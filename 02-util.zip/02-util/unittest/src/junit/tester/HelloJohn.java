package junit.tester;

import org.junit.Test;
import com.mycomp.Hello;

public class HelloJohn {
	@Test
	public void test1() {
		Hello h = new Hello();
		System.out.println(h.greet("John rambo"));
	}
}
