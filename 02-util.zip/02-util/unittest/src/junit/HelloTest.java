package junit;
import org.junit.Ignore;
import org.junit.Test;
import com.mycomp.Hello;

public class HelloTest {
	Hello h = new Hello();

	@Test
	public void test1() {
		System.out.println(h.greet("Jack Ripper"));
	}

	@Test(expected=RuntimeException.class)
	public void test2() {
		System.out.println(h.greet("John Rambo"));
	}

	@Ignore @Test
	public void test3() {
		System.out.println(h.greet("Ignore"));
	}
}