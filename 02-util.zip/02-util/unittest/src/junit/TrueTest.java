package junit;

import static org.junit.Assert.assertTrue;
import org.junit.Test;

import com.mycomp.Hello;

public class TrueTest {
	private Hello h = new Hello();
			
	@Test
	public void test1() {		// error
		assertTrue(h.greet("John Rambo").equals("Hello! John Rambo"));
	}
	
	@Test
	public void test2() {		// fail
		assertTrue(h.greet("Jack Ripper").equals("Hello! Jack Ripper."));
	}
	
	@Test
	public void test3() {		// success
		assertTrue(h.greet("Jame Bond").equals("Hello! Jame Bond"));
	}
}
/*
org.junit.Assert.assertEquals(expected, actual)
org.junit.Assert.assertFalse(condition)
org.junit.Assert.assertNull(object)
org.junit.Assert.assertNotNull(object)
org.junit.Assert.assertSame(expected, actual)
org.junit.Assert.assertNotSame(unexpected, actual)
org.junit.Assert.assertArrayEquals(expected, actuals)
*/