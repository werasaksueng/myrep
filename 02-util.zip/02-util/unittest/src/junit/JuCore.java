package junit;
import org.junit.runner.JUnitCore;
	
public class JuCore {
	public static void main(String args[]) {
			// Test one class
		// JUnitCore.main("junit.HelloTest");
			
			// Test more than one class
		String cn[] = { "junit.tester.HelloJohn", 
						"junit.tester.HelloJack" };
		JUnitCore.main(cn);
	}
}