package junit;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;

import com.mycomp.Hello;

public class InsTest {
	private Hello h;
	
	@Before
	public void init() {
		h = new Hello();
		System.out.println("init");
	}
	
	@After
	public void destroy() {
		h = null;
		System.out.println("destroy\n");
	}
	
	@Test
	public void test1() {
		System.out.println(h.greet("John Bimbo"));
	}
	
	@Test
	public void test2() {
		System.out.println(h.greet("Jack Ripper"));
	}
}