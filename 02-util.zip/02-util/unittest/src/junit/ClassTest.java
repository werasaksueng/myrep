package junit;

import org.junit.After;
import org.junit.AfterClass;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;

import com.mycomp.Hello;

public class ClassTest {
	static private Hello h;
	
	@BeforeClass
	static public void start() {
		h = new Hello();
		System.out.println("start");
	}
	
	@AfterClass
	static public void stop() {
		h = null;
		System.out.println("stop");
	}
	
	@Before
	public void init() {
		h = new Hello();
		System.out.println("init");
	}
	
	@After
	public void destroy() {
		h = null;
		System.out.println("destroy\n");
	}
	@Test
	public void test1() {
		System.out.println(h.greet("John Bimbo"));
	}
	
	@Test
	public void test2() {
		System.out.println(h.greet("Jack Ripper"));
	}
}