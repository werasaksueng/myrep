package testng;

import org.testng.annotations.Test;

import com.mycomp.Hello;

public class HelloTest {
	private Hello h = new Hello();
	
	@Test
	public void f() {
	  System.out.println(h.greet("John rambo"));
	}
	
	@Test
	public void g() {
	  System.out.println(h.greet("Jack Ripper"));
	}

}
