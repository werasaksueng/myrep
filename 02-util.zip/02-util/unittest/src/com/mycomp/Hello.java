package com.mycomp;

public class Hello {
	public String greet(String name) {
		if (name.equals("John Rambo"))
		 	throw new RuntimeException();
		return "Hello! " + name;
	}
}
