package jdklog;
import java.util.logging.*;

class HandlerTest {
	public static void main(String argv[]) throws Exception {
		Logger l = Logger.getAnonymousLogger();
		
		Handler h1 = new FileHandler("mylog.txt");
		h1.setFormatter(new SimpleFormatter( ));
		l.addHandler(h1);
		
		Handler h2 = new FileHandler("mylog.xml");
		h2.setFormatter(new XMLFormatter( ));
		l.addHandler(h2);
		
		l.info("hello");
	}
}
