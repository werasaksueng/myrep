package jdklog;

import java.util.logging.*;

class Main {
	public static void main(String argv[]){
		
		Logger l = Logger.getLogger(Main.class.getName());
		// Logger l = Logger.getLogger("global");
		// Logger l = Logger.getLogger(Logger.GLOBAL_LOGGER_NAME);
		// Logger l = Logger.getAnonymousLogger();
		
		l.log(Level.INFO, "info");
		l.info("info again");
	}
}
