package jdklog;
import java.util.logging.*;

class LevelTest {
	public static void main(String argv[]) throws Exception {
		Logger l = Logger.getAnonymousLogger();
		
		l.setLevel(Level.INFO);
		// l.setLevel(Level.OFF);
		
		l.severe("severe");
		l.warning("warning");
		l.info("info");
		l.config("config");
		l.fine("fine");
		l.finer("finer");
		l.finest("finest");
	}
}

/*
SEVERE (highest value) 
WARNING 
INFO 
CONFIG 
FINE 
FINER 
FINEST (lowest value) */
