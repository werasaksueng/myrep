package log4j;
import org.apache.log4j.Logger;

class LoggerTest {
	public static void main(String args[]) {
		Logger l1 = Logger.getLogger(LoggerTest.class);
		Logger l2 = Logger.getLogger(LoggerTest.class);
		Logger l3 = Logger.getLogger("LoggerTest");
		
		l1.info("Hello!");
		l2.info("Hi!");
		System.out.println(l1 == l2);
		System.out.println(l2 == l3);
	}
}
