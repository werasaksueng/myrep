package log4j;

import java.io.IOException;

import org.apache.log4j.DailyRollingFileAppender;
import org.apache.log4j.Logger;
import org.apache.log4j.PatternLayout;

class DailyRollingTest {
	public static void main(String args[]) throws IOException {
		Logger l = Logger.getLogger("A");
		
		PatternLayout pl = new PatternLayout();
		pl.setConversionPattern("%d %-5p [%t] - %m%n");
		
		DailyRollingFileAppender f = new DailyRollingFileAppender(pl, "d.log", "yyyy-MM-dd");
		l.addAppender(f);
		
		l.info("Hello");
	}
}