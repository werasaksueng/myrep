package log4j;
import org.apache.log4j.Logger;
import org.apache.log4j.PropertyConfigurator;

public class MyConfig {
	public static void main(String args[]) throws Exception {
		PropertyConfigurator.configure("src/myconfig.properties");
		Logger a = Logger.getLogger("A");
		a.info("Hi!");
	}
}