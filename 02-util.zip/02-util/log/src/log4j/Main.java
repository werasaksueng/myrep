package log4j;
import org.apache.log4j.Logger;
public class Main {
	public static void main(String args[]) throws Exception {
		Logger l = Logger.getLogger("A");
		l.info("Hello!");
		l.info("Hello! again");
	}
}
