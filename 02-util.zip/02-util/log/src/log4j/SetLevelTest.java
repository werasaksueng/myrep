package log4j;

import org.apache.log4j.*;

class SetLevelTest {
	public static void main(String args[]) {
		Logger a = Logger.getLogger("A");
		
		// DEBUG < INFO < WARN < ERROR < FATAL
		a.setLevel(Level.WARN);
		// a.setLevel(Level.DEBUG);

		a.fatal("fetal");
		a.error("error");
		a.warn("warn");
		a.info("info");
		a.debug("debug");
	}
}
