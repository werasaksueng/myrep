package log4j;
import java.io.IOException;
import org.apache.log4j.Logger;
import org.apache.log4j.RollingFileAppender;
import org.apache.log4j.SimpleLayout;

class RollingTest {
	public static void main(String args[]) throws IOException {
		Logger a = Logger.getLogger("A");
		
		RollingFileAppender f = new RollingFileAppender(
					new SimpleLayout(), "c.log");
		a.addAppender(f);
		
		a.info("Hello1");
		a.info("Hello2");
		f.rollOver();
		a.info("Hello3");
	}
}  // The rolled over file is c.log.1.