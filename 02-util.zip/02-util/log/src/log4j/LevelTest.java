package log4j;
import org.apache.log4j.*;
public class LevelTest {
	public static void main(String args[]) {
		Logger a = Logger.getLogger("A");
		a.fatal("fatal");
		a.error("error");
		a.warn("warn");
		a.info("info");
		a.debug("debug");

		a.log(Level.OFF, "OFF");
		a.log(Level.FATAL, "FATAL");
		a.log(Level.ERROR, "ERROR");
		a.log(Level.WARN, "WARN");
		a.log(Level.INFO, "INFO");
		a.log(Level.DEBUG, "DEBUG");
		a.log(Level.ALL, "ALL");
	}
}