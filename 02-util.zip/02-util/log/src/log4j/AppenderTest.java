package log4j;
import org.apache.log4j.*;
import java.io.*;

class AppenderTest {
	public static void main(String args[]) throws IOException {
		Logger l = Logger.getLogger("A");
		
		FileAppender f = new FileAppender(new SimpleLayout(), "a.log");
		// FileAppender f = new FileAppender(new SimpleLayout(), "a.log", true);
										//    layout,            file,    append
		
		l.addAppender(f);
		l.addAppender(new FileAppender(new SimpleLayout(), "b.log"));

		l.info("Hello!");
	}
}
// Check:  C:\myjee\src\02-lib\log\a.log.
