package log4j;
import org.apache.log4j.BasicConfigurator;
import org.apache.log4j.FileAppender;
import org.apache.log4j.Logger;
import org.apache.log4j.SimpleLayout;

public class BasicConfig {
	public static void main(String args[]) throws Exception {
		// BasicConfigurator.configure();		
		BasicConfigurator.configure(
				new FileAppender(new SimpleLayout(), "a.log"));
									// layout,			file
		Logger a = Logger.getLogger("A");
		a.info("Hello!");
	}
}
// Check: C:\myjee\src\02-lib\log\a.log
