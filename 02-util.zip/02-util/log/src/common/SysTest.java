package common;

import org.apache.commons.logging.*;

public class SysTest {
	public static void main(String args[]) {
		System.setProperty( "org.apache.commons.logging.Log",
				"org.apache.commons.logging.impl.Jdk14Logger" );
		//		"org.apache.commons.logging.impl.Log4JLogger" );
                   		
		Log l = LogFactory.getLog("A");
		System.out.println(l.getClass().getName());
	}
}
/*
1. LogFactoryImpl looks for the system property "org.apache.commons.logging.Log"
2. If there is no such system property
	the factory tries to load Log4J�s Logger
3. If Log4J can�t be loaded
	the factory tries to load the JDK 1.4�s logging
4. If JDK 1.4�s logging can�t be loaded
	the factory tries to JDK 1.3�s logging class (Jdk13LumberjackLogger)
5. Finally, if all fails
	the factory uses the SimpleLog class
*/