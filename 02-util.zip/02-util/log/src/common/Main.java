package common;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

class Main {
	public static void main(String args[]) {
		Log l = LogFactory.getLog("A");
		System.out.println(l.getClass().getName());
		l.info("Hello!");
	}
}
