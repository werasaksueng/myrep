package com.mycomp;
public class HelloBean {
	public String greet(String name) {
		return "Hello! " + name;
	}
}