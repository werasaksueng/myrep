package com.mycomp;
import java.security.*;
import java.security.spec.*;
import javax.crypto.*;
import javax.crypto.spec.*;
import java.io.*;
import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
public class Crypto extends JFrame {
	private static final long serialVersionUID = 1L;
	private JTextField inf = new JTextField(20);
	private JTextField outf = new JTextField(20);
	private JTextField psw = new JTextField(10);
	private JTextField itt = new JTextField(3);
	private JButton en = new JButton("Encrypt");
	private JButton de = new JButton("Decrypt");
	private String infName, outfName, passWord;
	private int iteration;
	private String errMsg;
	private Crypto() {
		super("Crypto");
		Container cp = getContentPane();
		cp.setLayout(new FlowLayout());
		Box b1 = Box.createHorizontalBox();
		b1.add(new JLabel("Input File "));
		b1.add(inf);

		Box b2 = Box.createHorizontalBox();
		b2.add(new JLabel("Output File "));
		b2.add(outf);

		Box b3 = Box.createHorizontalBox();
		b3.add(new JLabel("Password "));
		b3.add(psw); 
		b3.add(Box.createHorizontalStrut(30));
		b3.add(new JLabel("Iteration "));
		b3.add(itt);

		Box b4 = Box.createHorizontalBox();
		b4.add(en);
		b4.add(Box.createHorizontalStrut(50));
		b4.add(de);

		Box vb = Box.createVerticalBox();
		vb.add(b1); vb.add(Box.createVerticalStrut(6));
		vb.add(b2); vb.add(Box.createVerticalStrut(6));
		vb.add(b3); vb.add(Box.createVerticalStrut(11));
		vb.add(b4);
		cp.add(vb);

		setSize(350, 150);
		setVisible(true);
		setDefaultCloseOperation(EXIT_ON_CLOSE);

		en.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				if(!getInfo()) {
					JOptionPane.showMessageDialog(new JFrame(),errMsg, "Error Dialog", JOptionPane.ERROR_MESSAGE);
					return;
				}
				try {
					FileInputStream in = new FileInputStream(infName);
					byte[] input = new byte[in.available()];
					in.read(input);
					in.close();
					char[] pwc = passWord.toCharArray();
					KeySpec ks = new PBEKeySpec(pwc);
					String alg = "PBEWithMD5AndDES";
					SecretKeyFactory skf = SecretKeyFactory.getInstance(alg);
					SecretKey key = skf.generateSecret(ks);
					MessageDigest md = MessageDigest.getInstance("MD5");
					md.update(passWord.getBytes());
					md.update(input);
					byte[] digest = md.digest();
					byte[] salt = new byte[8];
					System.arraycopy(digest, 0, salt, 0, 8);
					AlgorithmParameterSpec aps = new PBEParameterSpec(salt, iteration);
					Cipher cipher = Cipher.getInstance(alg);
					cipher.init(Cipher.ENCRYPT_MODE, key, aps);
					byte[] output = cipher.doFinal(input);
					OutputStream out = new FileOutputStream(outfName);
					out.write(salt);
					out.write(output);
					out.close();
				} catch(Exception ex) {
					JOptionPane.showMessageDialog(new JFrame(), ex.getMessage(), "Error Dialog", JOptionPane.ERROR_MESSAGE);
				}
			}
		});
		de.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				if (!getInfo()) {
					JOptionPane.showMessageDialog(new JFrame(),errMsg, "Error Dialog", JOptionPane.ERROR_MESSAGE);
					return;
				}
				try {
					char[] pwd = passWord.toCharArray();
					KeySpec ks = new PBEKeySpec(pwd);
					String alg = "PBEWithMD5AndDES";
					SecretKeyFactory skf = SecretKeyFactory.getInstance(alg);
					SecretKey key = skf.generateSecret(ks);
					FileInputStream in = new FileInputStream(infName);
					byte[] salt = new byte[8];
					in.read(salt);
					byte[] input = new byte[in.available()];
					in.read(input);
					in.close();
					AlgorithmParameterSpec aps = new PBEParameterSpec(salt, iteration);
					Cipher cipher = Cipher.getInstance(alg);
					cipher.init(Cipher.DECRYPT_MODE, key, aps);
					byte[] output = cipher.doFinal(input);
					OutputStream out = new FileOutputStream(outfName);
					out.write(output);
					out.close();
				} catch(Exception ex) {
					JOptionPane.showMessageDialog(new JFrame(), ex.getMessage(), "Error Dialog", JOptionPane.ERROR_MESSAGE);
				}
			}
		});
	}
	private boolean getInfo() {
		infName = inf.getText();
		if (infName.equals("")) {
			errMsg = "No input file.";
			return false;
		}
		outfName = outf.getText();
		if (outfName.equals("")) {
			errMsg = "No output file.";
			return false;
		}
		passWord = psw.getText();
		if (passWord.equals("")) {
			errMsg = "No password.";
			return false;
		}
		try {
			iteration = Integer.parseInt(itt.getText());
		} catch (NumberFormatException e) {
			errMsg = "Invalid iteration.";
			return false;
		}
		return true;
	}
	public static void main(String[] args) {
		try {
			new Crypto();
		} catch(Exception e) {
			System.out.println(e);
		}
	}
}
