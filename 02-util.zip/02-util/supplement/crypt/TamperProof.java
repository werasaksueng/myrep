import java.security.PrivateKey;
import java.security.PublicKey;
import java.security.Signature;
class Sign {
	public static void main(String args[]) throws Exception {
		Signature sig = Signature.getInstance("DSA");
		sig.initSign((PrivateKey)MyUtil.readObjFile("privatekey"));		// private key to be used
		sig.update(MyUtil.readFile("hello.txt"));							// file to be signed
		MyUtil.writeFile("hello.txt.sig", sig.sign());					// signature file
		System.out.println("Ok");
	}
}
class Verify {
	public static void main(String args[]) throws Exception {
		Signature sig = Signature.getInstance("DSA");
		sig.initVerify((PublicKey)MyUtil.readObjFile("publickey"));		// public key to be used
		sig.update(MyUtil.readFile("hello.txt"));							// file to be verified
		if (sig.verify(MyUtil.readFile("hello.txt.sig")))					// signature file
			System.out.println("Valid");
		else
			System.out.println("InValid");		
	}
}
