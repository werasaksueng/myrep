import java.io.*;
import java.security.Key;
import javax.crypto.SecretKeyFactory;
import javax.crypto.spec.DESKeySpec;
public class MyUtil {
	public static byte[] readFile(String name) throws IOException {
		FileInputStream fis = new FileInputStream(name);
		int n = fis.available();
		byte[] b = new byte[n];
		fis.read(b, 0, n);
		fis.close();
		return b;
	}

	public static void writeFile(String name, byte[] b) throws IOException {
		FileOutputStream fos = new FileOutputStream(name);
		fos.write(b);
		fos.close();
	}

	public static Object readObjFile(String name) throws Exception {
		FileInputStream fis = new FileInputStream(name);
		ObjectInputStream ois = new ObjectInputStream(fis);
		Object o = ois.readObject();
		ois.close();
		return o;
	}

	public static void writeObjFile(String name, Object o) throws Exception {
		FileOutputStream fos = new FileOutputStream(name);
		ObjectOutputStream oos = new ObjectOutputStream(fos);
		oos.writeObject(o);
		oos.close();
	}

	public static String KEY = "hello123";
	public static Key getKey(String pwd) throws Exception {
		byte [] pw = pwd.getBytes(); // length >= 8
		DESKeySpec ks = new DESKeySpec(pw);
		SecretKeyFactory kf = SecretKeyFactory.getInstance("DES");
		return kf.generateSecret(ks);
	}
}
