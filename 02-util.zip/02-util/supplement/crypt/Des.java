import java.security.Key;
import javax.crypto.Cipher;
class Des {
	public static void main(String args[]) throws Exception {
		Key k = (Key) MyUtil.readObjFile("key");
		Cipher c = Cipher.getInstance("DES");		// "DES/ECB/PKCS5Padding"
		
			// encode
		c.init(Cipher.ENCRYPT_MODE, k);
		byte [] b = c.doFinal(MyUtil.readFile("hello.txt"));
		MyUtil.writeFile("tmp.1", b);
		
			// decode
		c.init(Cipher.DECRYPT_MODE, k);
		b = c.doFinal(MyUtil.readFile("tmp.1"));
		MyUtil.writeFile("tmp.2", b);
		
		System.out.println("Ok");
	}
}
