import java.security.KeyPair;
import java.security.KeyPairGenerator;
import java.security.NoSuchAlgorithmException;
import java.security.PrivateKey;
import java.security.PublicKey;
import java.security.SecureRandom;
class KeysGen {
	public static void main(String args[]) {
		KeyPairGenerator kpg = null;
		try {
			kpg = KeyPairGenerator.getInstance("DSA");
		} catch(NoSuchAlgorithmException e) {
			System.out.println(e);
			return;
		}
		SecureRandom sr = new SecureRandom();
		kpg.initialize(1024, sr);
		KeyPair kp = kpg.generateKeyPair();
		try { 
			PublicKey pubk = kp.getPublic();
			MyUtil.writeObjFile("publickey", pubk);
			PrivateKey prik = kp.getPrivate();
			MyUtil.writeObjFile("privatekey", prik);
		} catch(Exception e) {
			System.out.println(e);
		}
		System.out.println("Ok");
	}
}
