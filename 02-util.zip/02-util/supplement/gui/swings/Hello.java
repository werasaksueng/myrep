   import javax.swing.*;
   import java.awt.*;
   public class Hello {
      public static void main(String[] args) {
         JFrame fr = new JFrame("JFrame Title");  // Default: BorderLayout
         JLabel lb = new JLabel("Hello!");
         fr.add(lb, BorderLayout.CENTER);
         fr.setSize(300, 200);
         fr.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
         fr.setVisible(true);
      }
   }