   import javax.swing.*;
   import java.awt.event.ActionEvent;
   import java.awt.event.ActionListener;
   public class Buttons {
      public static void main(String[] args) {
         JFrame fr = new JFrame("Button Example");
         JButton bt = new JButton("Click Me!");
         bt.setBounds(130, 100, 150, 40);
         bt.addActionListener(new ActionListener() {
               @Override
               public void actionPerformed(ActionEvent e) {
                  System.out.println("Hello");
                  JOptionPane.showMessageDialog(fr, "Hello");
               }
         });
         fr.add(bt);
         fr.setSize(400, 300);
         fr.setLayout(null); // Using absolute positioning
         fr.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
         fr.setVisible(true);
      }
   }
