import javax.swing.*;
import java.awt.*;

public class Panels {
   public static void main(String[] args) {
      JFrame fr = new JFrame();

      // The default layout manager of panel is FlowLayout.
      JPanel pl = new JPanel();
      pl.setBackground(Color.LIGHT_GRAY);
      pl.add(new JButton("Hello"));
      pl.add(new JButton("Hi"));
      pl.add(new JButton("Whatup"));

      fr.add(new JButton("North Button"), BorderLayout.NORTH); 
      fr.add(pl, BorderLayout.CENTER); 
      fr.setSize(400, 300);
      fr.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
      fr.setVisible(true);
   }  // Components in the center are shifted upward.
}
