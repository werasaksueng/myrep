import javax.swing.*;
import java.awt.*;

public class Border {
   public static void main(String[] args) {
      JFrame fr = new JFrame();

      // The frame default layout manager is BorderLayout.
      // fr.setLayout(new BorderLayout());

      // Add components to each region
      fr.add(new JButton("Center"), BorderLayout.CENTER);
      fr.add(new JButton("North"), BorderLayout.NORTH);
      fr.add(new JButton("South"), BorderLayout.SOUTH);
      fr.add(new JButton("East"), BorderLayout.EAST);
      fr.add(new JButton("West"), BorderLayout.WEST);

      fr.setSize(400, 300);
      fr.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
      fr.setVisible(true);
   }
}
