import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class Flow {
    public static void main(String[] args) {
        JFrame fr = new JFrame();
        fr.setLayout(new FlowLayout());

        fr.add(new JLabel("Enter your name:"));
        fr.add(new JTextField(20));
        fr.add(new JButton("Submit"));

        fr.setSize(300, 150);
        fr.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        fr.setVisible(true);
        // Try: Resize the frame.
    }
}
