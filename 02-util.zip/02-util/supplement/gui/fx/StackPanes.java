import javafx.application.Application;
import javafx.scene.Scene;
import javafx.scene.control.Label;
import javafx.scene.control.Button;
import javafx.scene.layout.StackPane;
import javafx.stage.Stage;
import javafx.geometry.Pos;
import javafx.geometry.Insets;

public class StackPaneEx extends Application {
	@Override
	public void start(Stage stage) {
        Label label = new Label("Hello, StackPane!");
        Button button = new Button("Click Me");

        StackPane stackPane = new StackPane();
        stackPane.getChildren().addAll(label, button);

        // Try: Align the button to the bottom-right corner
        StackPane.setAlignment(button, Pos.BOTTOM_RIGHT);

        // Try: Padding and Margin
        stackPane.setPadding(new Insets(10));
        StackPane.setMargin(button, new Insets(10));

        Scene scene = new Scene(stackPane, 300, 200);
        stage.setScene(scene);
        stage.show();
    }
    public static void main(String[] args) {
        launch(args);
    }
}
