import javafx.application.Application;
import javafx.scene.Scene;
import javafx.scene.layout.StackPane;
import javafx.scene.control.Button;
import javafx.scene.layout.HBox;
import javafx.scene.layout.VBox;
import javafx.stage.Stage;
import javafx.geometry.Pos;

public class Buttons extends Application {
    private boolean isClicked = false;
    @Override
    public void start(Stage stage) {
        Button b1 = new Button("Hello");
        Button b2 = new Button("Hi");
        Button b3 = new Button("What's up?");

        // Set event handler lambda.
        b1.setOnAction(event -> System.out.println("Hello!"));
        b2.setOnAction(event -> { System.out.println("Hi!");
                                  b2.setDisable(true); } );
        b3.setOnAction(event -> { 
                if (isClicked) {
                    b3.setText("Click to Toggle");
                } else {
                    b3.setText("Toggled!");
                }
                isClicked = !isClicked; // Toggle state
            });

        /* Try: Set event handler method. */
        // b1.setOnAction(event -> buttonClick("John"));

        // Arrange buttons in HBox or VBox.
        HBox box = new HBox(10, b1, b2, b3);
        // VBox box = new VBox(10, b1, b2, b3);
        box.setAlignment(Pos.CENTER);

        Scene scene = new Scene(box, 300, 200);
        stage.setTitle("Multiple Buttons");
        stage.setScene(scene);
        stage.show();
    }

    // Event handling method that takes a parameter
    private void buttonClick(String name) {
        System.out.println("Hello " + name);
    }

    public static void main(String[] args) {
        launch(args);
    }
}