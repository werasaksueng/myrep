import javafx.application.Application;
import javafx.scene.Scene;
import javafx.scene.control.Label;
import javafx.scene.layout.StackPane;
import javafx.stage.Stage;

public class Hello extends Application {
	@Override
	public void start(Stage stage) {
       	Label label = new Label("Hello, World!");

        // StackPane is a layout pane that positions its child nodes in a stack.
        StackPane root = new StackPane();
        root.getChildren().add(label);

        // Create a scene with the layout
        Scene scene = new Scene(root, 300, 200);
        stage.setScene(scene);
       	stage.show();
    }
    public static void main(String[] args) {
        // Launch the JavaFX application
        launch(args); 
    }
}
