import javafx.application.Application;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.layout.StackPane;
import javafx.scene.paint.Color;
import javafx.scene.shape.Rectangle;
import javafx.stage.Stage;

public class MulLayers extends Application {
    @Override
    public void start(Stage primaryStage) {
        // Create a rectangle as the background layer
        Rectangle background = new Rectangle(300, 200);
        background.setFill(Color.LIGHTBLUE);

        // Create a semi-transparent overlay rectangle
        Rectangle overlay = new Rectangle(200, 100);
        overlay.setFill(Color.rgb(0, 0, 0, 0.5));

        // Create a button on top
        Button button = new Button("Click Me");

        // Create a StackPane and add all layers
        StackPane stackPane = new StackPane();
        stackPane.getChildren().addAll(background, overlay, button);

        Scene scene = new Scene(stackPane, 300, 200);

        primaryStage.setTitle("StackPane Multiple Layers");
        primaryStage.setScene(scene);
        primaryStage.show();
    }

    public static void main(String[] args) {
        launch(args);
    }
}
