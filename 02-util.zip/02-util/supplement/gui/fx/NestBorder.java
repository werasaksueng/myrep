import javafx.application.Application;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.layout.BorderPane;
import javafx.scene.layout.HBox;
import javafx.stage.Stage;

public class NestBorder extends Application {
    @Override
    public void start(Stage primaryStage) {
        // Create the main BorderPane
        BorderPane mainPane = new BorderPane();

        // Create a nested BorderPane for the top region
        BorderPane topPane = new BorderPane();
        topPane.setLeft(new Button("Left"));
        topPane.setRight(new Button("Right"));

        // Set the nested pane in the top region of the main pane
        mainPane.setTop(topPane);

        // Create an HBox for the bottom region of the main pane
        HBox bottomHBox = new HBox(10, new Button("Button 1"), new Button("Button 2"));
        mainPane.setBottom(bottomHBox);

        // Set a button in the center
        mainPane.setCenter(new Button("Center"));

        // Create a scene and display the stage
        Scene scene = new Scene(mainPane, 400, 300);
        primaryStage.setTitle("Nested BorderPane Example");
        primaryStage.setScene(scene);
        primaryStage.show();
    }

    public static void main(String[] args) {
        launch(args);
    }
}
