import javafx.application.Application;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.layout.BorderPane;
import javafx.stage.Stage;

public class Border extends Application {
    @Override
    public void start(Stage stage) {
        BorderPane root = new BorderPane();

        // Top region: Menu bar
        Label topLabel = new Label("Menu Bar");
        root.setTop(topLabel);

        // Bottom region: Status bar
        Label bottomLabel = new Label("Status Bar");
        root.setBottom(bottomLabel);

        // Left region: Navigation pane
        Button leftButton = new Button("Left Button");
        root.setLeft(leftButton);

        // Right region: Inspector pane
        Button rightButton = new Button("Right Button");
        root.setRight(rightButton);

        // Center region: Main content area
        Label centerLabel = new Label("Main Content Area");
        root.setCenter(centerLabel);

        Scene scene = new Scene(root, 400, 300);
        stage.setScene(scene);
        stage.show();
    }

    public static void main(String[] args) {
        launch(args);
    }
}