import javafx.application.Application;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.layout.GridPane;
import javafx.stage.Stage;
import javafx.geometry.Pos;
import javafx.geometry.Insets;

public class Grid extends Application {
   @Override
   public void start(Stage stage) {
      GridPane gp = new GridPane();

      /* Add buttons to the GridPane at specific positions */
      gp.add(new Button("Button 1"), 0, 0); // Col 0, Row 0
      gp.add(new Button("Button 2"), 1, 0); // Col 1, Row 0
      gp.add(new Button("Button 3"), 0, 1); // Col 0, Row 1
      gp.add(new Button("Button 4"), 1, 1); // Col 1, Row 1

      // Set padding and gaps
      gp.setPadding(new Insets(10)); // Padding around the grid
      gp.setHgap(10); // Horizontal gap between columns
      gp.setVgap(10); // Vertical gap between rows

      // Center Alignment
      gp.setAlignment(Pos.CENTER);

      Scene scene = new Scene(gp, 300, 200);
      stage.setTitle("Basic GridPane Example");
      stage.setScene(scene);
      stage.show();
   }

   public static void main(String[] args) {
      launch(args);
   }
}
