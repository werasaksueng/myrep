import javafx.application.Application;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;
import javafx.scene.layout.VBox;
import javafx.stage.Stage;

public class TextFields extends Application {
    @Override
    public void start(Stage stage) {
        TextField tf = new TextField();
        tf.setPromptText("Enter your name"); // A placeholder text

        // Create a button
        Button bt = new Button("Submit");

        // Create a label to display the input
        Label lb = new Label();

        // Set button action to print the input text in the label.
        bt.setOnAction(event -> {
            String name = tf.getText();
            lb.setText("Hello " + name);
            // tf.clear(); // Clear the input field
        });

        VBox vbox = new VBox(10, tf, bt, lb);
        vbox.setStyle("-fx-padding: 20; -fx-alignment: center;");

        // Create a scene and display the stage
        Scene scene = new Scene(vbox, 300, 200);
        stage.setTitle("TextField Example");
        stage.setScene(scene);
        stage.show();
    }

    public static void main(String[] args) {
        launch(args);
    }
}
