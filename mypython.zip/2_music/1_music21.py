''' 'music21' is a Python lib for handling musical note.
          https://www.music21.org/music21docs/
pip install music21

'music21' may play sound with 'pygame'.
But Python 3.14 has dependency problem with 'pygame'.
We will use Python 3.11.9 for now.

On Windows 'music21' does not directly produce sound. 
It writes output to a 'midi' file and launches a 
'midi' player program.
Midi Players:
 - Windows Media Player is the default 'midi' player.
 - Musescore can play sound and handle musical sheet.
 - Pygame has library to play 'midi'. (StreamPlayer).
'''

## Check the current setting:
from music21 import environment
env = environment.UserSettings()
# [print(f"{k} = {env[k]}") for k in env.keys()]
## Check the 'midiPath'.

''' 'musescore' is an application for playing and handling music scores.
                  https://www.musescore.org
'museScore' 3,4 often break 'midi' playback.
We will use MuseScore 2 for now. Suppose it was install at:
    C:\\Program Files (x86)\\MuseScore 2\\bin\\MuseScore.exe
'''

## Suppose Media Player is set as default in Windows.
## For Windows Media Player.
# env['midiPath'] = None

## For Musescore
# env['midiPath'] = 'C:\\Program Files (x86)\\MuseScore 2\\bin\\MuseScore.exe'
#---------------------------------------------------------------------

''' 'note' is a single musical sound.
Normally a note is defined by its name as a string.
'''
from music21 import  note
n = note.Note('C4')
# n.show('midi')    ## sends output to the current 'midiPath'.

## 'stream' is a sequence of notes.
from music21 import stream

## PLay with Pygame stream player.
## Music21 has a pygame stream player.
from music21 import midi
def play(s):  ## Play a stream, not a note.
    midi.realtime.StreamPlayer(s).play()
# play(stream.Stream(n))

''' An 'octave' is a set of equal temperament 12 notes
separated by equal half-step (semitone) intervals.
Distance between adjacent notes = 1 semitone (half steps).
  	Ex. C -> C# (½ step), E → F (½ step)
After an octave ends, notes are repeated in the next octave.

In some context the octave doesn’t matter, a note may be just
note name with no octave.
Some notes may have more than one names (enharmonic).
They sound the same but used in different contexts.
    	# is sharp(up) and - is flat(down).
'''
def octave():
    note_names = ['C', 'C#', 'D', 'D#', 'E', 'F', 'F#', 'G', 'G#', 'A', 'A#', 'B']
    s = stream.Stream([ note.Note(n) for n in note_names])
    print(len(s))
    [ print(n.pitch.fullName, end=', ') for n in s]
    s.show('midi')
    # play(s)
# octave()

## A note name may be defined with the octave number.
def octave_number():
    ## Notes in octave 0, octave 1 and default octave (4).
    note_names = \
        ['C0', 'C#0', 'D0', 'D#0', 'E0', 'F0', 'F#0', 'G0', 'G#1', 'A0', 'A#0', 'B0'] \
     +  ['C1', 'C#1', 'D1', 'D#1', 'E1', 'F1', 'F#1', 'G1', 'G#1', 'A1', 'A#1', 'B1'] \
     +  ['C', 'C#', 'D', 'D#', 'E', 'F', 'F#', 'G', 'G#', 'A', 'A#', 'B']
    s = stream.Stream([ note.Note(n) for n in note_names])
    [ print(n.pitch.fullName) for n in s]
    s.show('midi')
# octave_number()

''' One octave is a range of 12 pitch (frequency).
For convenient programming, a note may be defined by its pitch numbers
which is an 'int', sometime called 'midi' number.
      ex. C#4 is 61     and 	D4 is 62.
'''
def pitch_number():
    notes = [ note.Note(p) for p in range(0, 12)]   ## in default octave (4).
    # notes = [ note.Note(p) for p in range(13, 24)]  ## in octave 0 
    # notes = [ note.Note(p) for p in range(25, 36)]  ## in octave 1
    ## The 4th octave starts at pitch number 60, the default, most familiar and used.
    # notes = [note.Note(p) for p in range(59, 73)]

    s = stream.Stream(notes)
    [ print(n.pitch.midi, n.pitch.fullName) for n in s]
    s.show('midi')
# pitch_number()

''' For programming, we can create a note from other note.
transpose(<step>) create a note at the next <step> of the note.
'''
def transpose():
    n = note.Note('C4')
    notes = [n]  
    for i in range(13):
        n = n.transpose(1)	## transpose 1 semitone.
        notes.append(n)
    s = stream.Stream(notes)
    [ print(n.pitch.midi, n.pitch.name) for n in s]
    s.show('midi')
# transpose()

'''  
In western countries an octave has 12 notes, pitch number is the matter.
        C4  C#4  D4  E-4  E4   F4   F#4  G4   G#4  A4   B-4  B4
        60  61   62  63   64   65   66   67   68   69   70   71

But in some countries e.g. Thai, they count the pitch scale and
got only 8-notes including the first of next octave.
The semitones are removed.
        Do  Re  Mi  Fa  Sol  La  Ti  Do
        C4  D4  E4  F4  G4   A4  B4  C5
        60  62  64  65  67   69  71  72
'''
def note8():
    note_names = ['C4', 'D4', 'E4', 'F4', 'G4', 'A4', 'B4', 'C5']
    notes = [ note.Note(p) for p in note_names]
    s = stream.Stream(notes)
    [ print(n.pitch.midi, n.pitch.fullName) for n in s]
    s.show('midi')
# note8()

''' A 'chord' is a sound that composed of multiple notes.
'chord' can be defined as a list of notes (or strings of note).
Notes can be short handed with lower-case letters.
'''
from music21 import chord
def chords():
    notes = [note.Note(n) for n in ['C4', 'E-4', 'B4', 'A4']]
    c = [chord.Chord(notes)]
    # c = [chord.Chord('C4 E-4 B4 A4')]
    # c = [chord.Chord('c e- b a')]
    stream.Stream(c).show('midi')
# chords()

''' There are commonly popular chords defined with their names.
 https://en.wikipedia.org/wiki/Chord_names_and_symbols_(popular_music)
'''
def pop_chord():
    cs = [chord.Chord('c e- g'), chord.Chord('c e g'), chord.Chord('c e g#'), 
         chord.Chord('c e g b-'), chord.Chord('c e g b'), chord.Chord('c e- g b'),
         chord.Chord('c e- g b-'), chord.Chord('c e g# b'), chord.Chord('c e g# b-'),
         chord.Chord('c e- g- b-'), chord.Chord('c e- g- b--'), chord.Chord('c e- g-'),
         chord.Chord('c e g- b-')]
    [ print(c.commonName) for c in cs]
    stream.Stream(cs).show('midi')
# pop_chord()

## Excercise: Name the song.
def exc1():
    notes = ['E4','E4','E4','E4','E4','E4','E4','G4','C4','D4','E4',
      'F4','F4','F4','F4','F4','E4','E4','E4','E4','D4','D4','E4','D4','G4']
    stream.Stream([note.Note(n) for n in notes]).show('midi')
# exc1()
## Notes are not enough to make a song.

''' A 'rest' is a note without sound, representing space between notes.
Every note, chord and rest has a duration, with length 1 by default.
Durations are expressed in units of quarterLength.
      Name                  type(str)        quarterLength
    Longa                       longa            16.0
    Double whole                breve             8.0
    Whole                       whole             4.0
    Half                        half              2.0
    Quarter                     quarter           1.0
    Eighth                      eighth            0.5                       note
    Sixteenth                   16th              0.25
    Thirty-second                32nd             0.125
    Sixty-fourth                 64th             0.0625
    One-hundred-twenty-eighth    128th            0.03125
    Two-hundred-fifty-sixth      256th            0.015625
    Five-hundred-twelfth         512th            0.0078125
    One-thousand-twenty-fourth   1024th           0.00390625 
'''
## Feel a rest.
def rest_ex():
    stream.Stream([
       note.Note('C4'),
       note.Rest(type='breve'), ## Try: whole, quarter, eighth
       note.Note('C#4')
    ]).show('midi')
# rest_ex()
## There are also makeRests() and SpaceRest.

## Exercise: Random composition, just notes + rests.
def exc2():
    s = stream.Stream()
  
    n1 = note.Note('G#')
    s.repeatAppend(n1, 4)
    s.append(note.Rest(type='half'))

    n2 = note.Note('A4')
    n2.quarterLength = 2
    s.repeatAppend(n2, 3)
    s.append(note.Rest(type='quarter'))

    n2 = note.Note('f#5')
    n2.quarterLength = 1
    s.append(note.Rest(type='eighth'))

    n3 = note.Note('G5')
    n3.quarterLength = 1
    s.repeatAppend(n3, 5)
    s.show('midi')

    ## Saved as music score (.mxl file) and played with Musescore.
    # s.write('musicxml', fp='./tmp/t.mxl')

    ## Save as a .midi file and played with Windows Media Player.
    # s.write('midi', fp='./tmp/t.mid')
# exc2()
#########################################################################

''' Extra:
Cent:
For the 12-notes, an octave is divided into 12 equal pitch semitones.
A 'microtone' is a pitch interval smaller than a semitone, counted as 'cent'.
A semitone is divided into 100 cents.
      Quarter tone = 50 cents (half a semitone).
      Third tone ≈ 33.3 cents.
      Eighth tone = 25 cents.

Ex. A note at C#4 quarter is C#4 + 50 cents.
A pitch can be created with step (base pitch number), accidental (#),
octave and microtone.
'''
from music21 import pitch  # accidental = "#",
def create_pitch(): 
    pitches = [pitch.Pitch(step='C'),
	pitch.Pitch(step='C', microtone=pitch.Microtone(50)),
	pitch.Pitch(step='C', microtone=pitch.Microtone(100)), ## C#4 
        pitch.Pitch(step='C', microtone=pitch.Microtone(200)), ## D4
        pitch.Pitch(step='C', microtone=pitch.Microtone(300))] ## E-4
    s = stream.Stream([note.Note(p) for p in pitches])
    [ print(n.pitch.midi, n.pitch.fullName) for n in s]
    s.show('midi')
# create_pitch()

''' articulations: instruct how to play a note (to add a accent). '''
from music21 import articulations
def art_ex():
    n = note.Note("C4")
    n.articulations.append(articulations.Staccato())
    print(n.nameWithOctave, n.articulations)
    n.show('midi')
# art_ex()

''' A note contains 'velocity' value (0 to 127) covers the range from
  an inaudible note to the maximum note level.
It is the force that the note is played.
Hitting a note harder will affect its loudness and also
  the quality of the sound which is called 'timber'. 

A MIDI message specifies the instrument to play the sound.
It contains:
	- channel (0 to 15)
	- instrument number

A channel value defines one instrument be played.
So we can control up to 16 different instruments playing independently.

The instrument number from 0 to 127 are called "General Midi (GM)" standard 
  which defines a list of 128 standard instruments.
    ex. trumpet instrument is 57
'''   

