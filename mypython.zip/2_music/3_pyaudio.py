''' 'pyaudio' is a wrap for 'PortAudio' designed for low-level audio handling.
  - Playing normal audio file and raw PCM audio samples.
  - Recording from a microphone and real-time audio streaming.
  - Performing audio processing (filters, effects, spectrum).
  - Useful for tone generating, voice recognition and audio synthesis.
'''
import pyaudio, sys, wave  ## pip install pyaudio

def check_devices():
    p = pyaudio.PyAudio()
    for i in range(p.get_device_count()):
        info = p.get_device_info_by_index(i)
        print(f"{i}: {info['name']}")
    p.terminate()
# check_devices()

## Play a .wav file.
def play(file):
    with wave.open(file, 'rb') as wf:
        p = pyaudio.PyAudio()
        stream = p.open(format = p.get_format_from_width(wf.getsampwidth()),
                        channels = wf.getnchannels(),
                        rate=wf.getframerate(),
                        output = True)
        ## Play the stream.
        chunk = 1024
        while len(data := wf.readframes(chunk)):  ## Requires Python 3.8+ for :=
            stream.write(data)
        stream.close()  ## Close stream
    p.terminate()       ## Release PortAudio system resources
# play('audio/puppy_love.wav')

## Recording from default mic to a file.
def record(ofile):
    ## Audio settings
    format = pyaudio.paInt16
    channels = 2
    rate = 44100
    chunk = 1024
    record_seconds = 5       ## Record for 5 seconds.
    p = pyaudio.PyAudio()
    stream = p.open(format = format,
                    channels = channels,
                    rate = rate,
                    input=True,
                    frames_per_buffer=chunk)
    
    print("Recording...")
    frames = []
    for _ in range(0, int(rate / chunk*record_seconds)):
        data = stream.read(chunk)
        frames.append(data)

    print("Finished recording.")
    stream.stop_stream()
    stream.close()
    p.terminate()
    
    ## Save data as a WAV file.
    wf = wave.open(ofile, 'wb')
    wf.setnchannels(channels)
    wf.setsampwidth(p.get_sample_size(format))
    wf.setframerate(rate)
    wf.writeframes(b''.join(frames))
    wf.close()
    print('Save to: ', ofile)
# record('tmp.wav')

## Generate sound stream (PCM audio).
RATE = 44100
import numpy as np
def gen_sine(frequency=440, duration=2.0, volume=0.5):
    t = np.linspace(0, duration, int(RATE * duration), False)
    samples = volume * np.sin(2 * np.pi * frequency * t)
    audio = (samples * 32767).astype(np.int16)
    return audio.tobytes()

def play_stream(data):
    p = pyaudio.PyAudio()
    stream = p.open(format=pyaudio.paInt16,
        channels=1, rate=RATE, output=True )
    stream.write(data)
    stream.stop_stream()
    stream.close()
    p.terminate()

def stream_test():
    data = gen_sine(frequency=523.25, duration=3, volume=0.8)
                      ## C5
    play_stream(data)
# stream_test()

