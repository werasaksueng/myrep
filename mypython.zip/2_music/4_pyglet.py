''' 'pyglet' supports sound handling.
It can play MP3, WAV and OGG files.
Play multiple tracks simultaneously and queue multiple songs.
Supports control volume, pause/resume, loop and seek.
'''
import pyglet
apache = 'audio/Apache.mp3'
puppy_love = 'audio/Puppy_love.wav'
def play(song):
    sound = pyglet.media.load(song, streaming=False)
    # streaming=True -> Load entirely into memory
    sound.play()                    
    pyglet.app.run()
# play(apache)

## Player Pause/Resume
## 'pyglet' allows scheduling events.
def schedule():
    sound = pyglet.media.load(apache, streaming=False)
    player = pyglet.media.Player()
    player.queue(sound)
    player.play()

    def pause(dt):
        print("Pause")
        player.pause()

    def resume(dt):
        print("Resume")
        player.play()

    pyglet.clock.schedule_once(pause, 7)
    pyglet.clock.schedule_once(resume, 10)
    pyglet.app.run()
# schedule()

## Player volume control
from pyglet.window import key
def control():
    window = pyglet.window.Window(600, 400)
    player = pyglet.media.Player()
    player.queue( pyglet.media.load(apache) )
    # player.volume = 0.2     ## 20%
    # player.loop = True      ## loop forever
    # player.seek(30)         ## Seek to 30 Seconds

    ## Report player play time.   
    def update(dt):
        print(player.time)

    ## Key controls
    @window.event
    def on_key_press(k, modifiers):
        if k == key.P:
            player.play()
        elif k == key.S:
            player.pause()
        elif k == key.UP:
            player.volume = min(player.volume + 0.1, 1.0)
            print('Volume: ', round(player.volume, 1))
        elif k == key.DOWN:
            player.volume = max(player.volume - 0.1, 0.0)
            print('Volume: ', round(player.volume, 1))

    ## Detect when music ends
    @player.event
    def on_eos():
        print("Finished!")
   
    player.play()
    # pyglet.clock.schedule_interval(update,1)
    pyglet.app.run()
# control()

''' Background Music + Sound Effect
Using a layer for background music and use Source.play()
for each sound effects.
'''
bird = pyglet.media.load("audio/bird.wav", streaming=True)
duck = pyglet.media.load("audio/duck.ogg", streaming=True)
def bg_effect():
    window = pyglet.window.Window(600, 400)
    ## A player may queue multiple songs, but play one at a time.
    player = pyglet.media.Player()
    player.queue(pyglet.media.load(apache))
    player.queue(pyglet.media.load(puppy_love))
    player.play()
    
    @window.event
    def on_key_press(symbol, modifiers):
        if symbol == key.A:
            bird.play()    ## A track must play to end before playing again.
        if symbol == key.Z:
            duck.play()
    pyglet.app.run()
# bg_effect()
