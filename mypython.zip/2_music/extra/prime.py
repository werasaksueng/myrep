''' Prime is an integer that greater than one and no other
integers divide evenly except one and itself.
Note:
  - negative, 0 and 1 are not primes.
  - 2 is the smallest and the only even prime.
 ex. There are 25 primes under 100.
'''

''' Prime Testing: is a procedure to check that 
if an integer is a prime.

A brute force approach:
Starting from 2, find an integer that divide the 
number evenly.
'''
def is_prime(n):
    if n < 2:
        return False
    for i in range(2, n // 2+1):
        if n % i == 0:
            return False
    return True
# print([n for n in range(2,100) if is_prime(n)])

## The range can be reduced to square root of n.
import math
def is_prime_sq(n):
    if n < 2:
        return False
    m = math.floor(math.sqrt(n)) + 1
    for i in range(2, m):
        if n % i == 0:
            return False
    return True
# print([n for n in range(2,100) if is_prime_sq(n)])

## Exercise: Does the following function is a valid prime tester.
def puzzle(n):
    if n < 2:
        return False
    for i in range(2, n//2 + 1):
        if i*i > n:
            break
        if n % i == 0:
            return False
    return True

## The search space can be pruned.
def is_primeP(n):
    ## negative numbers and 1 are not prime.
    if  n <= 1:
        return False
    
    ## 2 and 3 are prime.
    if n <= 3:
        return True

    ## even numbers have 0 in the right most bit.
    ## mutiples of 3 are not primes.
    if n & 1 == 0 or n % 3 == 0:     ## & is bit-wise 'and'
        return False

    ## jump by 6 to check only numbers of the from 6k ± 1.
    ## loops by square root of n iterations.
    i = 5           
    while i*i <= n:     
        if n % i == 0  or n % (i+2) == 0:
            return False
        i += 6
    return True
# print([n for n in range(2,100) if is_primeP(n)])
''' Why n % (i+2) == 0
Start at i = 5 and jumps by 6.
[5 6 7 8 9 10]        6, 8, 10 are even, 9 is multiple of 3.
[11 12 13 14 15 16]   12, 14, 16 are even, 15 is multiple of 3.
...  Then the only unchecked position is at i+2.

Exercise:
  Write a program to show that for all numbers less than 10000,
if p is a prime and greater than 6 then p % 6 is 1 or 5.
'''
#---------------------------------------------------------------

## Probabilistic algorithms sacrifice correctness for efficiency.
## Miller–Rabin Prime Testing: Works accurately up to 2**64.
def is_primeMR(n):
    if n < 2:
        return False
    
    ## Small primes
    small_primes = [2, 3, 5, 7, 11, 13, 17, 19, 23]
    if n in small_primes:
        return True
    if any(n % p == 0 for p in small_primes):
        return False
    
    ## Write n-1 as d * 2**s
    d = n - 1
    s = 0
    while d % 2 == 0:
        d //= 2
        s += 1

    ## Deterministic bases for testing 64-bit integers
    bases = [2, 325, 9375, 28178, 450775, 9780504, 1795265022]

    def check(a):
        x = pow(a, d, n)
        if x == 1 or x == n - 1:
            return True
        for _ in range(s - 1):
            x = pow(x, 2, n)
            if x == n - 1:
                return True
        return False
    return all(check(a % n) for a in bases)
# print(is_primeMR(2**61 - 1))
''' Exercise:
   Write a program to check accuracy and perform benchmark
on these prime testing functions.
'''
#------------------------------------------------------------------

## Sieve of Eratosthenes (เอราโตสเทแนส)
def sieve(n):    ## n is the max prime, not the number of primes.
    ## create a list of boolean
    s = [False, False]  ## 0 and 1 are not prime 
    for i in range(2, n+1):
        s.append(True)
    
    ## Jumping start from 2 to half n.    
    for i in range(2, (n // 2) + 1):
        if s[i]:
            for j in range(i*2, n+1, i):   ## jump by i
                s[j] = False
    return [i for i in range(n+1) if s[i]]
# [print(i, sieve(i)) for i in range(10)]

## Sieve pruneed and optimized.
def sievePO(n):
    s = [False, False]
    for i in range(2, n+1):
        s.append(True)

    h = (n+1) >> 1	## half n
    i = 2;		## start from 2, the first prime
    while i < h:
        c = i << 1	    ## double i
        while c <= n:
            s[c] = False    ## mark as not prime
            c += i	    ## jump by i
        i += 1
        while (i < h) and (not s[i]): ## find next i that is not prime
            i += 1
    return [i for i in range(n+1) if s[i]]
# print(len(sievePO(100)))
#------------------------------------------------------------------

''' Prime Generators:
A function that should output a prime for any input.

Fermat wrongfully stated that 2**(2**n) + 1 is a prime
for all n. The claim fails at n = 5.
'''
def fermat():
    def fermat_prime(n):
        return 2**(2**n) + 1

    for n in range(6):
        p = fermat_prime(n)
        print(n, p, is_primeP(p))
# fermat() 

## Euler proposed two prime generators: 
def euler():
    def euler_prime(n):
        return n**2 + n + 17    ## fails at n = 16
        # return n**2 + n + 41  ## fails at n = 40.

    for n in range(100):
        p = euler_prime(n)
        if not is_primeP(p):
            print('Fails at:', n, p)
            break
        else:
            print(n, p)
# euler()

''' There are many well known prime generator e.g.
      Legendre:   n**2 + n + 11
      Wheel:      6n ± 1
Exercise:
  Write programs to check the smallest n that the formulas fail.

                    Fool Prime Generators
Factorial prime:   n! + 1
The value cannot be divisible by any integer from 2 through n,
but not above and it fails very quickly.
'''
import math
def fac():
    def fac_prime(n):
        return math.factorial(n) + 1

    for n in range(100):
        p = fac_prime(n)
        if not is_primeP(p):
            print('Fails at:', n, p)
            break
        else:
            print(n, p)
# fac()

''' PFN prime generator is:    pfn(n) + 1
Let pfn(n) be the product of the first n primes.
It only undivisible by the first n primes, but not above.
'''
## Create 95 primes. There are 95 primes below 500.
si95 = sieve(500)
# print(len(si95))     ## 95
def pfn_ex(n):
    ## Products of the first i primes.
    for i in range(2, n):
        sii = si95[:i]
        print(i, sii, math.prod(sii))
# pfn_ex(7)

def pfn_test():
    def pfn(n):
        a = si95[:n]
        return a, math.prod(a)
    for i in range(2, 10):
        a, p = pfn(i)
        p += 1
        if not is_primeP(p):
            print('Fails at:', i, a, p)
            break  ## 6 [2, 3, 5, 7, 11, 13] 30031
        else:
            print(i, a, p)
# pfn_test()

''' Fibonacci and Primes:
  fib(0) = 0, fib(1) = 1, fib(2) = 1, fib(3) = 2, fib(4) = 3,
            fib(n) = fib(n-2) + fib(n-1)
Fibonaccis grows very large quickly and appear to be primes.
But it fails at: fib(6) = 3+5 = 8  and many others.
'''
#-----------------------------------------------------------------

''' Marin Mersenne, a French monk in early 17th century,
propsed the Mersenne number that computed by:
                mp(n) = 2**n - 1
The n-th Mersenne number is denoted by mp(n).
'''
def mp(n):
    return 2**n - 1

''' mp(n) are seem to be primes but not alway, that means some n
does not give a prime.
He Mersenne also stated that if p is a prime then mp(p) has a bigger
chance to be prime. That reduces the search space for prime.

The first break down: p is a prime but mp(p) is not a prime.
'''
def breakdown():
    for p in sieve(100):
        if not is_primeMR(mp(p)):
            print(p)
        break
# breakdown()             ## 11

'''                    Mersenne List
In 1644, Mersenne claimed that for all numbers below 258, only n in
the list below that mp(n) is a prime:
          2, 3, 5, 7, 13, 17, 19, 31, 67, 127, and 257

The old Greeks knew that mp(2), mp(3), mp(5) and mp(7) are primes.
Then in the middle age, mp(13), mp(17) and mp(19) were knew to be primes.
'''
def mersenne_ex():  ## For n below 20.
    for n in range(20):
        mn = mp(n)
        if is_primeMR(mpn):
            print(n, end=', ') ## 2, 3, 5, 7, 13, 17, 19, 
# mersenne_ex()

''' That was impressive for a monk with no computers.
The world waits until Euler, the Great, to took an action.
He verified that mp(31) was actually a prime.
But how did Mersenne know in the 17th century that 2147483647 was a prime.
'''
# m31 = mp(31); print(m31, is_primeMR(m31))     ## 2147483647 True

''' The Missing N:
In 1883, Pervusin proved that mp(61) is a prime, but not in the Mersenne list.
'''
# m61 = mp(61); print(m61, is_primeMR(m61))  ## 2305843009213693951 True

''' In 1903, at The American Mathematical Meeting in New York, Frank Nelson
Cole was scheduled to present "On the Factorization of Large Numbers."
what 's a boring and outdate topic.
He walked to the blackboard.  No announcement. No introduction. No explanation.
But ferociously multiplying these two numbers by hand:
                193,707,721 x 761,838,257,287
Just the scratching sound of chalk, the tension multiplied quicker than his
writing, it took the whole space of the board and seemingly eternity and the
the answer came out:
                    147,573,952,589,676,412,927
Then he moved to the other part of the board and started calculating:
                        2 to the n 
And increased n like it would never end. Then several audience stood up, even
they did not sure how it would end but it must be a big one. Then the
calculation stopped with:
                2**67 - 1 = 193,707,721 x 761,838,257,287
Cole humbly respected and walk to his seat without a word, but the whole
building trumbled with a long standing ovation.
The number was mp(67) and Édouard Lucas had already shown in 1876 that
it was not prime, but this is the first time that we found its factors.
The presses asked Cole who how did he get the number, he replied 'three
years of Sundays'.
So it is not a prime, Mersenne was wrong again.
'''
# m67 = mp(67); print(m67, is_primeMR(mp(67)))  ## 147573952589676412927 False

''' Edouard Lucas developed a method to show that M127 is indeed a prime.
That regained Mersenne honor. '''
# m127 = mp(127); print(m127, is_primeMR(mp(127))) ## 170141183460469231731687303715884105727 True

''' Powers found mp(89) and mp(107) are primes but missed the list.

We have to wait till the computer age to know that mp(257) was not a prime.
A deadly uppercut to Mersenne.
Let god forgiven, that number is not humanly computable.
'''
# m257 = mp(257); print(m257, is_primeMR(mp(257)))

'''
In 2001, mp(13,466,917) was showed to be a prime.
In 2024, mp(136,279,841) is a 41,024,320 digits number and the record-holder.
GIMPS reports that all n below 141,177,683 have been tested at least
once, but that does not mean the end of putting your name in history.
'''



