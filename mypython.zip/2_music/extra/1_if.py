'''  Ex. 'Leap Year' is the year that February has 29 days.
Since an earth year is 365 + ¼ days and a little bits.
To determine if a year is a leap year:
   If the year(in AD) is divided by 400 it is a leap year.
   Else if it is divided by 100 it is not a leap year.
   Else if it is divided by 4 it is a leap year.
   Else it is not a leap year.
'''
def is_leap_year(n):
    if n % 400 == 0:
        return True
    elif n % 100 == 0:
        return False
    elif n % 4 == 0:
        return True
    return False
# print(is_leap_year(1000), is_leap_year(2000), is_leap_year(2100))
        ## False True False

## All years from 2020 to 2112 that divisible by 4 but not a leap year.
# print([y for y in range(2020, 2300) if y % 4 == 0 and not is_leap_year(y)])

## All years from 2020 to 3000 that divisible by 100 and are leap years.
# print([y for y in range(2020, 3000) if y % 100 == 0 and is_leap_year(y)])

## To check that a date (day, month, year) is valid, for years 1754 to 2200.
def is_valid_date(d, m, y):
    if d < 1 or d > 31 or m < 1 or m > 12 or y < 1753 or y > 2199:
        return False
    if m == 2:      ## February
        if is_leap_year(y) and d <= 29:
            return True
        if d > 28:
            return False
    if (m == 4 or m == 6 or m == 9 or m == 11) and d == 31:
        return False
    return True
# print(is_valid_date(29, 2, 2020))     ## True
# print(is_valid_date(29, 2, 2026))     ## False
#-------------------------------------------------------------

''' 'classification' is the process of mapping from input
to the 'class', 'type', 'kind', 'category', ... .
Normally there are knowledge that associates 'class' with
'interpretation' or 'meaning'.
The task is easily determined with 'if-else'.

Ex. Body Mass Index: a simple health indicator.
              bmi = weight / (height**2)
   weight is in kilograms and height is in meters.
The classification:
                  bmi             status
              < 18.5              Underweight
          18.5 - 24.9             Normal
          25.0 - 29.9             Overweight
          30.0 - 34.9             Obesity class I
          35.0 - 39.9             Obesity class II
               < 40               Obesity class III
'''
def bmi(w, h):
    b = w / (h**2)
    if b < 18.5:
        return 'Underweight'
    if 18.5 < b < 24.9:
        return 'Normal'    
    if 25.0 < b < 29.9:
        return 'Overweight'    
    if 30.0 < b < 34.9:
        return 'Obesity class I'    
    if 35.0 < b < 39.9:
        return 'Obesity class II'
    return 'Obesity class III'
# print(bmi(75, 1.65))
#----------------------------------------------------

''' Exercise: Write a program that classifies from Moment Magnitude (Mw)
to the class and effect. 
 Magnitude (Mw) |  class   | Typical effects                                                                  |
 -------------: | ---------| -------------------------------------------------------------------------------- |
      < 2.0     | Micro    | Usually not felt; detected by instruments                                        |
     2.0–>2.9   | Minor    | Usually not felt                                                                 |
     3.0–>3.9   | Minor    | Often felt near the epicenter; little or no damage                               |
     4.0–>4.9   | Light    | Noticeable shaking; minor damage possible                                        |
     5.0–>5.9   | Moderate | Can cause damage, especially to vulnerable buildings                             |
     6.0–>6.9   | Strong   | Potentially serious damage over a wide area                                      |
     7.0–>7.9   | Major    | Major damage possible over large areas                                           |
     8.0–>8.9   | Great    | Severe damage over very large areas                                              |
     9.0–>9.9   | Great    | Devastating effects over enormous areas                                          |
       10.0+    | Extreme  | Extremely rare; no known earthquake of this magnitude has been reliably recorded |
'''
#-----------------------------------------------------------
'''  Ex. Chinese Zodiac:
The Chinese assign animals to years in a 12 year cycle.
The pattern repeats before and from there:
      2000 Dragon         % 12  == 8
      2001 Snake                   9
      2002 Horse                  10
      2003 Sheep                  11
      2004 Monkey                  0
      2005 Rooster                 1
      2006 Dog                     2
      2007 Pig                     3
      2008 Rat                     4
      2009 Ox                      5
      2010 Tiger                   6
      2011 Hare                    7
'''
def zodiac(year):
    r = year % 12
    if r == 8:
        return 'Dragon'
    elif r == 9:
        return 'Snake'
    elif r == 10:
        return 'Horse'
    elif r == 11:
        return 'Sheep'
    elif r == 0:
        return 'Monkey'
    elif r == 1:
        return 'Rooster'
    elif r == 2:
        return 'Dog'
    elif r == 3:
        return 'Pig'
    elif r == 4:
        return 'Rat'
    elif r == 5:
        return 'Ox'
    elif r == 6:
        return 'Tiger'
    else:
        return 'Hare'

## Using list/tuple for mapping.
z = ('Monkey', 'Rooster', 'Dog', 'Pig', 'Rat', 'Ox', 'Hare',
     'Tiger', 'Dragon', 'Snake', 'Horse', 'Sheep', )
def zod(year):
    return z[year % 12]

def zodiac_test():
    for i in range(13):
        print(i, zodiac(i), zod(i))
##zodiac_test()

predict = { 'Rat': 'Charm, smart, adroit, agile',
            'Ox': 'Mild, prudent, honest, endure',
            'Tiger': 'Bold, allure, quick-tempered',
            'Hare' : 'Bland, courtesy, politeness, good taste',
            'Dragon': 'Leader, astute, dexterous, attractive, ambitious',
            'Snake': 'Mysterious, elegant, individual, indolent',
            'Horse': 'Honesty, shy, intensive, athlete',
            'Sheep': 'Artist, romantic, imaginative, unreliable',
            'Monkey': 'Clever, playful, persuasive, talkative',
            'Rooster': 'Confident, generous, lively, entertainment',
            'Dog': 'Trustworthy, instinct, intuitive unrest',
            'Pig': 'Simple mind, forgiveness, kindness, careless'}
# print(predict[zodiac(2000)])
#-------------------------------------------------------

''' Howlers Math: is an 'incorrect' but 'look like valid' math.
The method is wrong but gives correct results by chance.

Ex. Howlor Fractions.
Show your friends that you can simplify a fraction by
canceling the tenth digit with the unit digit.
                  ex. 16/64 = 1/4
Find all such the howlers of numbers less than 100.
'''
def howlers():
    for a in range(1, 10):
        for b in range(1, 10):
            if a != b:
                for x in range(0, 10):
                    if (10.0*a + x)/(10.0*x + b) == a/b:
                        print('%d/%d' % (10*a+x, 10*x+b))
# howlers()

''' Exercises:
Tell your friends that you found an extraordinary method
for multiplication of two 3-digits numbers with the following approach:
           abc * xyz  = ax * by * cz
   e.g.    126 * 110  = 11 * 21 * 60  =  13860
The method is obviously wrong but genrates a lot of right results.
Find all the howlers.
'''
#-------------------------------------------------------

''' Solving equations:
In school, if there are n varibles we need n equations
to solve the equations. But not with programming.

Ex. Find solutions for 0 < x, y < 100.
          x(x+1) = y(y+1)(y+2)
Hint: there are 2 solutions.
'''
def solv_eq():
    for x in range(1, 100):
        for y in range(1, 100):
            if x*(x+1) == y*(y+1)*(y+2):
                print(x, y)
# solv_eq()

''' Exercises: Find the soluations for the following equations,
for 0 < x < y < z < 10.
      -       x+y+z = x*y*z
      -       x**3 + y**3 + z**3 = 6*x*y*z
      -       xyz... = x**x + y**y + z**z + ...
'''
#------------------------------------------------------------

''' 'Generate and Test' is a method of problem solving that
generate possible solutions and test if it is a valid answer
then it is a solution.
The approach is good if the solution space is not so big and
checking the answers is easy.

Ex. A farmer say 'My farm has 36 heads and 100 feet.'
He has just chickens and pigs.
How many chickens and pigs does he have?
'''
def farmer():
    for chick in range(36):
        for pig in range(36-chick, 36):
            if (chick+pig == 36) and (chick*2 + pig*4 == 100):
                print(f'chickens: {chick}, pigs: {pig}')
# farmer()

''' Ex. A monkey ate 100 coconuts in 5 days.
Each day it eats 6 more coconuts than the previous day. 
How many did he eat on each days?
'''
def monkey():
    for a in range(100):      ## Try: ranges may be optimized.
        for b in range(100):    
            if (6+a == b):
                for c in range(100):
                    if (6+b == c):
                        for d in range(100):
                            if (6+c == d):
                                for e in range(100):
                                    if (6+d == e) and (a+b+c+d+e == 100):
                                        print(a, b, c, d, e)
# monkey()
## Exercise: Using comprehension.
#-------------------------------------------------------

''' Ex. Numbers and Digits Substitution Puzzle.
A one digit number is correspond to a character.
No characters mapped to the same numbers.
The result is mathematically correct.
                  S E N D
                + M O R E
                ---------
                M O N E Y
'''
def send_money():
    [(s, e, n, d, m, o, r, y)] = [(s, e, n, d, m, o, r, y)
        for s in range(1, 10)
        for e in range(0, 10) if (s != e)
        for n in range(0, 10) if (n not in [s, e])
        for d in range(0, 10) if (d not in [s, e, n])
        for m in range(1, 10) if (m not in [s, e, n, d])
        for o in range(0, 10) if (o not in [s, e, n, d, m])
        for r in range(0, 10) if (r not in [s, e, n, d, m, o])
        for y in range(0, 10) if (y not in [s, e, n, d, m, o, r]) and
                (s*1000 + e*100 + n*10 + d) +
                (m*1000 + o*100 + r*10 + e) ==
                (m*10000 + o*1000 + n*100 + e*10 + y)
    ]
    a = str(s) + str(e) + str(n) + str(d)
    b = str(m) + str(o) + str(r) + str(e)
    c = str(m) + str(o) + str(n) + str(e) + str(y)
    print(a, '/' , b, '=',  c)
# send_money()

''' Exercises:
                SANTA
              - CLAUS
              ---------
                 XMAS
'''
