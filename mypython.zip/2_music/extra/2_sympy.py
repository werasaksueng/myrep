''' 'sympy' is a Python lib for algebraic manipulation.
pip install sympy
  e.g. simplify formulas, solve equations, diff, integate. ....
'''
from sympy import Symbol, symbols
x = Symbol('x')    	   ## Creates a symbols.
# print(x+x + 1)              ## 2*x + 1
## It performs algebric symbols, not mathematic computing.

y, z, w = symbols('y z w') ## Creates more symbols.

''' Forcing symbolic manipulations. '''
from sympy import simplify, expand, factor, together, apart

## expand() to sum of individual terms.
e = (x-y)*(x+y)
# print(e.expand())          ## x**2 - y**2
# print(expand((x+y)**2))    ## x**2 + 2*x*y + y**2

## apart() splits to partial fractions..
# print(((x+1)**3).apart())           ## x**3 + 3*x**2 + 3*x + 1# 
# print(apart((3*x + 5)/(x*(x - 1)))) ## 8/(x - 1) - 5/x

## factor() to multiplication of its factors.
# print((x**2 - y**2).factor())    ## (x - y)*(x + y)
# print(factor(x**2 + 5*x + 6))    ## (x + 2)*(x + 3)

## simplify() to lowest number of terms.
# print(((x**2 + 2*x + 1)/(x+1)).simplify())    ## x + 1
# print(simplify((x**2 - 1)/(x - 1)))           ## x + 1
# print(simplify(3*x**2 + 2*y*x**2 + 5*x**2 ))  ## 2*x**2*(y + 4)

## together() combines fractions into a ratio.
# print((1 + 1/x).together())       ## (x + 1)/x
# print(together(w/x + y/z ))       ## (w*z + x*y)/(x*z)

''' Exerices:
 1. expend() the following:
      x*(x+1)
      (x+1)*(x+2)
      (x+y)*(x-y)
      (x+y)**2, '\t\t')
      (x+y)**(x+y)
      (x**2 + x*2 + x + 1)*(x**3 + x*3 + x + 2)
'''
# print(expand(  ))

''' 2. factor() the following:
      x**2 + x
      x**2 + 2*x + 1
      x**2 + 2*x*y + y**2
      x**2 - y**2
      x**3 - x
'''
# print(factor(  ))
#-----------------------------------------------------

## Trigonometry:
from sympy import sin, cos, pi
def trigo():
    print(sin(x+pi), sin(x+2*pi))           ## -sin(x) sin(x)
    print(cos(x+pi), cos(x+2*pi))           ## -cos(x) cos(x)
    
    print(simplify(sin(x)/cos(x)))          ## tan(x)
    print(simplify(sin(x)**2 + cos(x)**2))  ## 1
    print(simplify(2*sin(x)*cos(x)))        ## sin(2*x)

    ## Substitution:
    ex = sin(x) + cos(x)
    print(ex.subs({x:1}))           ## cos(1) + sin(1)
    print(ex.evalf(subs={x: 1}))    ## 1.38177329067604
# trigo()
#-----------------------------------------------------

## Derivative (diff):
from sympy import diff
ex = x**3 + 2*x**2 + 3*x + 4
# print(diff(ex, x))          ## 3*x**2 + 4*x + 3

ex = x**2 * y + y**3
# print(diff(ex, x))          ## 2*x*y
# print(diff(ex, y))          ## x**2 + 3*y**2

from sympy import sin, sqrt, log
# print(diff(sin(x), x))      ## cos(x)
# print(diff(sqrt(x), x))     ## 1/(2*sqrt(x))
# print(diff(log(x), x))      ## 1/x

## Integrate:
from sympy import integrate
ex = x**2
# print(integrate(ex, x))       ## x**3/3

''' Definite integral '''
# print(integrate(x**2, (x, 0, 3)))  ## 9

''' Integral math functions. '''
# print(integrate(sin(x), x))     ## -cos(x)
# print(integrate(sqrt(x), x))    ## 2*x**(3/2)/3
# print(integrate(1/x, x))        ## log(x)
#-----------------------------------------------------

## Sympy Pretty Print:
from sympy import pprint, sqrt
# pprint(x**2 + 2*x*sqrt(y+1) + y**2)
#cpprint((1 + 1/x).together())
# pprint((x ** 3 + x ** 2 - x - 1)/(x ** 2 + 2 * x + 1))
#------------------------------------------------------

''' Solving Linear Equations:
Equation transformation:
        <left> = <right>
        <left> - <right> = 0
Then solve(<left> - <right>).
'''
from sympy import solve
def lin_eq():
    ''' Suppose two equations and two variables:
            2*x + 3*y = 1
            3*x + 2*y + 1 = 0
    '''
    ex1 = 2*x + 3*y - 1
    ex2 = 3*x + 2*y + 1
    print(solve((ex1, ex2)))        ## {x: -1, y: 1}
# lin_eq()

''' Parabola Equation:
            a*x**2 + b*x + c
'''
a, b, c = symbols('a b c')
# pprint(solve( a*x**2 + b*x + c, x ))
#-------------------------------------------------

## Sympy Plot:
from sympy.plotting import plot
def parabola_plot():  ## a*x**2 + b*x + c
    plot_range = (x, -4, 4)
    ## b**2 < 4*a*c   there are no solutions.
    b, a, c = 1, 1, 1
    plot( a*x**2 + b*x + c, plot_range)

    ## b**2 = 4*a*c   there is one solution.
    b, a, c = 2, 1, 1
    plot( a*x**2 + b*x + c, plot_range)

    ## b**2 > 4*a*c   there are two solutions.
    b, a, c = 3, 1, 1
    plot( a*x**2 + b*x + c, plot_range)
# parabola_plot()

