''' Music Scores:
Music21 has built-in 'corpus' module containing sample music scores of
well known composers.
It is meant for learning with real music without creating from scratch.
Files are in MusicXML and MIDI formats.
The MusicXML file (extension .mxl) can be opened with any score readers:
    http://musescore.org/
    http://finalemusic.com/Reader
Check:
        %PYTHON_HOME%/Lib/site-packages/music21/corpus
  Try:  bach, beethoven, mozart
'''
from music21 import corpus, midi
from music21.corpus import corpora

''' There are too many files we must specify the composer and the 
number of files we need.
'''
def get_corpus(composer, number):
    core = corpora.CoreCorpus()
    paths = [str(p)[53:] for p in core.getPaths()]
    found = 0
    for p in paths:
        if composer in p:
            print(p)
            found += 1
        if found == number:
            break
# get_corpus('bach', 10)
# get_corpus('beethoven', 10)
# get_corpus('mozart', 10)

''' Paths for sample songs.
Assume that using Python 3.11 installed at C:\\python\\Python311.
Use '\\' as path separator in python codes for Windows.  '''
CORPUS_HOME = 'C:\\python\\Python311\\Lib\\site-packages\\music21\\corpus\\'

bach = CORPUS_HOME + 'bach\\bwv1.6.mxl'
beethoven = CORPUS_HOME + 'beethoven\\opus59no3\\movement1.mxl'
mozart = CORPUS_HOME + 'mozart\\k156\\movement4.mxl'

''' To set midi player to musescore:, run only once.  '''
from music21 import environment
def set_musescore():
    us = environment.UserSettings()
    us['midiPath'] = r'C:\\Program Files (x86)\\MuseScore 2\\bin\\MuseScore.exe'
# set_musescore() 

## To load and play 'mxl' file.
from music21 import converter
def play_(path):
    s = converter.parse(path)  	## Return a Score
    s.show('midi')
# play_(bach)        ## Try: bach, beethoven, mozart

## A score can be saved as 'mxl' or 'midi' file.
def save_score(path):
    ## Load a score.
    s = converter.parse(path)

    ## Write to 'mxl' file.
    print(s.write('musicxml', fp='tmp.mxl'))

    ## Write to 'midi' file.
    print(s.write('midi', fp='tmp.mid'))
# save_score(bach)

## Test the 'midi' file with musescore.
# converter.parse('tmp.mid').show('midi')

## A score may contain many instruments:
def list_instruments(path):
    s = converter.parse(path)
    for p in s.parts:
        print(p.getInstrument())
# list_instruments(bach)

## Extracting by instrument:
def extract(path, ins):
    s = converter.parse(path)
    s = s.getElementById(ins)
    s.show('mid')
# extract(bach, 'Alto')
# extract(bach, 'Horn 2')
# extract(bach, 'Soprano')
# extract(bach, 'Tenor')
# extract(bach, 'Bass')

## Shiftng Notes by 'n' steps.
def shift(path, ins, steps):
    s = converter.parse(path)
    s = s.getElementById(ins)
    st = stream.Stream()
    for n in s.flatten().notes:
        st.append(n.transpose(3))
    st.show('midi')
# shift(bach, 'Soprano', 5)

## Inserting a note in every sequence of notes.
def insert(path, ins, beats):
    s = converter.parse(path)
    s = s.getElementById(ins)
    st = stream.Stream()
    i = 0
    for n in s.flatten().notes:
        st.append(n)
        if i % beats == 0:
            st.append(note.Note('C#4'))
        i += 1
    st.show('midi')
# insert(bach, 'Soprano', 4)

''' Inserting Rest, Slur or Slur into a stream.
A Slur is a Spanner that connects multiple notes across time.
A Variant represents alternative musical content.
'''
from music21 import spanner, variant
def modify(path, ins, block):
    s = converter.parse(path)
    s = s.getElementById(ins)
    for i in range(0, int(s.highestOffset), block):
        s.insert(i, note.Rest(type='whole'))
        # s.insert(i, spanner.Slur())
        # s.insert(i, variant.Variant([note.Note('C#4'), note.Note('F#4')]))
    s.show('midi')
# modify(bach, 'Soprano', 5)

## Detuning by adding microtone.
from music21 import pitch
import random
def detune(path, ins):
    s = converter.parse(path)
    s = s.getElementById(ins)
    keyDetune = [pitch.Microtone(random.randint(-50, 50)) for i in range(0, 127)]
    for n in s.flatten().notes:
        n.pitch.microtone = keyDetune[n.pitch.midi]
    s.show('midi')
# detune(bach, 'Soprano')

## Exercise: Removing some notes from a score.
#----------------------------------------------

''' TitnyNotation: A short hand notation that is more compact than conventional notes.
 http://web.mit.edu/music21/doc/moduleReference/moduleTinyNotation.html
  - Note names are: a,b,c,d,e,f,g and r for rest.
  - Flats, sharps, and naturals are notated as #,-, and n.
  - After the note name, a number may be placed indicating the note length:
     1 = whole, 2 = half, 4 = quarter, 8 = eighth, 16 = sixteenth
    If omitted, it is assumed to be the same as the previous note.
  - Can be played by most media players and mobile phones.
'''
## Play tinynotation.
def tiny():
    s = converter.parse('tinynotation: g# a2 e- g r a4 f f#2 f')
    midi.realtime.StreamPlayer(s).play() 
# tiny()


