''' Ping-pong: User VS Computer
User (left): Control with a,z.
Computer (right) Automatic: just follows the ball.
'''
WIDTH = 600; HEIGHT = 400
## Paddle settings
PADDLE_WIDTH = 10; PADDLE_HEIGHT = 80
PADDLE_SPEED = 5

## Ball settings
BALL_SIZE = 10
ball_speed_x = 4; ball_speed_y = 4
## Try: Adjust speed by setting ball_speed or slow_update()

## User paddle (left)
user = Rect((20, HEIGHT//2 - PADDLE_HEIGHT//2),
              (PADDLE_WIDTH, PADDLE_HEIGHT))

## Computer paddle (right)
comp = Rect((WIDTH - 30, HEIGHT//2 - PADDLE_HEIGHT//2),
          (PADDLE_WIDTH, PADDLE_HEIGHT))

## Create a ball
ball = Rect((WIDTH//2, HEIGHT//2), (BALL_SIZE, BALL_SIZE))

user_score = 0
comp_score = 0
def draw():
    screen.clear()

    ## Draw paddles
    screen.draw.filled_rect(user, "white")
    screen.draw.filled_rect(comp, "white")

    ## Draw ball
    screen.draw.filled_rect(ball, "yellow")

    ## Draw center line
    screen.draw.line((WIDTH//2, 0), (WIDTH//2, HEIGHT), "white")

    ## Draw score
    screen.draw.text(str(user_score),
            center=(WIDTH//2 - 50, 30), fontsize=40)
    screen.draw.text(str(comp_score),
            center=(WIDTH//2 + 50, 30), fontsize=40)

def slow_update():
    global ball_speed_x, ball_speed_y, user_score, comp_score

    ## User movement
    if keyboard.a:
        user.y -= PADDLE_SPEED
    if keyboard.z:
        user.y += PADDLE_SPEED

    ## Keep user on screen
    user.y = max(0, min(HEIGHT - PADDLE_HEIGHT, user.y))

    ## Computer movement
    if comp.centery < ball.centery:
        comp.y += 3
    elif comp.centery > ball.centery:
        comp.y -= 3

    ## Keep computer on screen
    comp.y = max(0, min(HEIGHT - PADDLE_HEIGHT, comp.y))

    ## Ball movement
    ball.x += ball_speed_x
    ball.y += ball_speed_y

    ## Top/bottom wall bounce
    if ball.top <= 0 or ball.bottom >= HEIGHT:
        ball_speed_y *= -1

    ## Paddle collision
    if ball.colliderect(user) or ball.colliderect(comp):
        ball_speed_x *= -1

    ## -------- Scoring --------
    if ball.left <= 0:
        comp_score += 1
        reset_ball()

    if ball.right >= WIDTH:
        user_score += 1
        reset_ball()

import random
def reset_ball():
    global ball_speed_x, ball_speed_y
    ball.center = (WIDTH//2+random.randint(-5,5), 
		   HEIGHT//2+random.randint(-5,5))

    ## Send ball toward scoring player
    if ball_speed_x > 0:
        ball_speed_x = -4
    else:
        ball_speed_x = 4 

    ball_speed_y = 4
    
clock.schedule_interval(slow_update, 0.02)

''' Exercise:
 - Adjust speed by setting update duration.
 - Game over when a score reaches 10
   and reports the winner.
'''
