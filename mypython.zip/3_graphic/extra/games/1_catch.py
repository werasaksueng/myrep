''' Catch the falling apple.
Move the basket with the arrow keys.
'''
from random import randint
WIDTH = 600; HEIGHT = 400

basket = Actor("basket")
basket.pos = (300, 370)

apple = Actor("apple")
apple.pos = (300, 50)

score = 0
def update_():      ## Position and score
    global score
    if keyboard.left:
        basket.x -= 5
    if keyboard.right:
        basket.x += 5

    apple.y += 3
    if apple.y > HEIGHT:
        apple.pos = (randint(30,570), 30)

    if basket.colliderect(apple):
        score += 1
        apple.pos = (randint(30,570), 30)

clock.schedule_interval(update_, 0.01)

def draw():
    screen.fill('WHITE')
    basket.draw()
    apple.draw()
    screen.draw.text(f"Score: {score}", (10,10),
         fontsize=40, color="black")

## set SDL_VIDEO_CENTERED=1
## pgzrun 1_catch.py

''' Exercise:
If an apple hits the basket, game overs.
Surviving every five sec get a score.
'''