''' Shoot Birds
If a bird collides the gun, gameover.
'''
import random
from pygame.surface import Surface
WIDTH = 700; HEIGHT = 500

class Gun:
    def __init__(self, x, y, w, h, color):
        self.rect = Rect((x, y), (w, h))
        self.color = color
    def draw(self):
        screen.draw.filled_rect(self.rect, self.color)
    def move_x(self, dx):
        self.rect.x += dx
    def pos(self):
        return (self.rect.x, self.rect.y)
    def colliderect(self, other):
        return self.rect.colliderect(other.rect)

class Bullet:
    def __init__(self, x, y, w, h):
        self.surf = Surface((w, h))
        self.surf.fill('GREEN')
        self.rect = Rect((x, y), (w, h))
    def draw(self):
       screen.blit(self.surf, (self.rect.x, self.rect.y))
    def move_y(self, dy):
        self.rect.y -= dy

gun =  Gun(WIDTH//2, HEIGHT-50, 50, 50, "green")
bullets = []
birds = []
score = 0
game_over = False

def draw():
    screen.fill('WHITE')
    if game_over:
        screen.draw.text("GAME OVER", center=(WIDTH//2, HEIGHT//2), 
		fontsize=60, color="red")
        return
    gun.draw() 
    for bullet in bullets:
        bullet.draw()    
    for bird in birds:
        bird.draw()
    screen.draw.text(f"Score: {score}", (10, 10), 
	fontsize=40, color='black')

def update():
    global game_over, score
    if game_over:
        return

    ## Move bullets
    for bullet in bullets:
        bullet.move_y(5)
    
    ## Move birds
    for bird in birds:
        bird.y += 1
    
    ## Remove off-screen bullets
    bullets[:] = [b for b in bullets if b.rect.y > 0]
    
    ## Randomly spawn a bird for 1 in 70.
    if random.randint(1, 70) == 1:
        bird = Actor("bird3")
        bird.pos = (random.randint(50, WIDTH-50), 0)
        birds.append(bird)
    
    ## Collision
    for bird in birds:
        if bird.colliderect(gun):
            game_over = True
        
        for bullet in bullets:
            if bird.colliderect(bullet):
                birds.remove(bird)
                bullets.remove(bullet)
                score += 1
                break

def on_key_down(key):
    if key == keys.LEFT:
        gun.move_x(-10)
    elif key == keys.RIGHT:
        gun.move_x(10)
    elif key == keys.SPACE:
        x, y = gun.pos()
        bullet = Bullet(x+25, y, 15, 30)
        bullets.append(bullet)

## set SDL_VIDEO_CENTERED=1
## pgzrun 2_shoot.py

''' Exercise: 
  - Make the bird flies while falling.
'''
