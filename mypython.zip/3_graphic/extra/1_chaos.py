import matplotlib.pyplot as pl
from PIL import Image 
import numpy as np
import random

''' 'chaos' is a system that follows simple mathematic rules 
but some initial values produce the result that seem to be 
random and unpredictable.
But if look from far enough we may find some patterns or shapes.
We don't know how these shapes are hiden in such a simple math.

1. Shapes of randomness: Ex. Fern:
'''
def fern(n):
    w, h = 900, 700
    im = Image.new("L", (w, h), 255)
    x, y = 0.0, 0.0
    for i in range(n):
        r = random.random()  	## 0 -> 1.0
        if r < 0.01:		## 1%
            x, y = 0, 0.13*y
        elif r < 0.08:		## 7%
            x, y = (0.2*x - 0.26*y), (0.23*x + 0.22*y + 1.6)
        elif r < 0.16:		## 7%
            x, y = (-0.15*x + 0.28*y), (0.26*x + 0.24*y + 0.44)
        else:			## 85%
            x, y = (0.87*x + 0.04*y), (-0.04*x + 0.85*y + 1.6)    
        cx, cy = abs(int(x*w/5)), abs(int(y*h/10))
        im.putpixel((cx, cy), 0)
    im.show()
# fern(100000)

''' 'Fractals' are shapes that can be zoomed in indefinitely and
see similar shape.
Some chaotic random may produce fractals.
Ex. Triangles:
'''
def triangle(n):
    w, h = 800, 800
    im = Image.new("L", (w, h), 255)
    one3 = 1.0/3.0
    two3 = 2.0/3.0
    x, y = 0.0, 0.0
    for i in range(n):
        r = random.random()
        if r < one3:
            x *= 0.5
            y *= 0.5
        elif r < two3:
            x = x/2 + 0.25
            y = y/2 + 0.5
        else:
            x = x/2 + 0.5
            y *= 0.5           
        cx, cy = int(x*w), int(y*h) ## scale x and y to fit the frame
        im.putpixel((cx, cy), 0) 
    im.show()
# triangle(100000)

''' 2. Shapes of iteration(orbiting):
'orbit' is a process that applies a function to an initial
values then apply the function repeatedly to the result. 
    Ex. Orbiting a simple function:
                    y = c*x*(1-x)
     where 'x' and 'y' are variable, c is a constant.
The value of 'y' will be used as input 'x' in the next round.
Some initial values(of c and x) may result stable, oscillate 
or chaotic.
Ex. To show the unpredictable results of c=4, and x=0.1,0.101,0.1001.
'''
def chaos_ex():
    def orbit(c, x, rounds=30):
        v = []
        for i in range(rounds):
            x = c * x * (1 - x)
            v.append(x)
        return v
    pl.plot(orbit(4.0, 0.1), color='red')
    pl.plot(orbit(4.0, 0.101), color='green')
    pl.plot(orbit(4.0, 0.1001), color='blue')
    pl.show()
# chaos_ex()

''' Orbiting plot x, y with parameter (a, b, c, d):
     Starting x = 1, y =1
             x = sin(y*b) + c*sin(x*b)
             y = sin(x*a) + d*sin(y*a)
'''
def kings():
    w, h = 400, 300
    def king(a, b, c, d):  
        x, y = 1.0, 1.0
        im = Image.new("L", (w, h), 255)
        for i in range(w*h):
            nx = np.sin(y*b) + c*np.sin(x*b)  ## Try: sin() -> cos()
            ny = np.sin(x*a) + d*np.sin(y*a)
            ## Scale for ploting within w and h.
            cx = int(abs(nx*w) % w)
            cy = int(abs(ny*h) % h)
            im.putpixel((cx, cy), 0)
            x, y = nx, ny
        return im

    ims = Image.new('L', (w*3, h), 255)
    ims.paste(king(-1.0, 2.8, 0.75, 0.7), (0, 0))
    ims.paste(king(-2.5, 2.4, 0.53, 0.37), (w, 0))
    ims.paste(king(0.37, 3.33, 1.3, 1.5), (w*2, 0))
    ims.show()
# kings()

def lorenzs():
    w, h = 300, 200
    def lorenz(a, b, c, d):
        x, y, z = 1.0, 1.0, 1.0
        im = Image.new("L", (w, h), 255)
        for i in range(w*h):
            nx = x + d*a*(y - x)
            ny = y + d*(x*(c - z) - y)
            nz = z + d*(x*y - b*z)
            cx = int(abs(nx*w) % w)
            cy = int(abs(ny*h) % h)
            im.putpixel((cx, cy), 0)
            x, y, z = nx, ny, nz
        return im

    ims = Image.new('L', (w*3, h*2), 255)
    ims.paste(lorenz(1.0, 1.6, 2.8, 0.01), (0, 0))
    ims.paste(lorenz(10.1, 1.5, 3.1, 0.001), (w, 0))
    ims.paste(lorenz(3.3, 2.1, 10.1, 0.03), (w*2, 0))
    ims.paste(lorenz(3.3, 3.1, 8.1, 0.009), (0, h))
    ims.paste(lorenz(2.4, 0.15, 4.805, 0.03), (w, h))
    ims.paste(lorenz(2.3, 1.1, 6.2, 0.05), (w*2, h))
    ims.show()
# lorenzs()

## 2. Shapes of recursion: Mostly produce fractals.
import turtle
def init_turtle():
    turtle.setup(width=800, height=500)
    turtle.tracer(0, 0) 
    return turtle.Pen()

def tree_ex():
    def tree(length):
        if length < 5:
            return
        t.forward(length)
        t.left(30)
        tree(length * 0.7)
        t.right(60)
        tree(length * 0.7)
        t.left(30)
        t.backward(length)

    t = init_turtle()
    t.left(90)
    t.backward(100)
    tree(100)
# tree_ex()

def koch_ex():
    def koch(width, level):
        if level == 0:
            t.forward(width);
            return
        koch(width/3, level-1); t.left(60)
        koch(width/3, level-1); t.right(120)
        koch(width/3, level-1); t.left(60)
        koch(width/3, level-1)

    def move_to(x, y):
        t.up(); t.goto(x, y); t.down()
        
    t = init_turtle()
    move_to(-100, 150); koch(200, 1)
    move_to(-100, 70); koch(200, 2)
    move_to(-100, 0); koch(200, 3)
    move_to(-100, -100); koch(200, 4)
    move_to(-100, -200); koch(200, 5)
# koch_ex()
#############################################################

''' For a 'square' function:
            f(x) = x ** 2
'Julia' set is a set of initial values (x) that their orbits
do not go to infinity.

Float Orbiting: x is of 'float' type.
For simplicity, if x is orbited for 10 rounds and a result go over 2
then it would go to infinity (not in the 'Julia' set).
'''
def orbit_float():
    def orbit(x):
        for _ in range(10):
            x = x **2
            if x > 2.0:
                return 'no'
        return 'yes'
    
    x = 2.0
    for _ in range(40):
        print(round(x,2), orbit(x))
        x -= 0.1
# orbit_float()       
'''  All x < -1 and x > 1 are not in 'Julia' set.
     All x in [-1, 1] are in 'Julia' set.

But if x is a complex number. There is no rule like that.
'''
def orbit_img(x):
    for i in range(10):    ## Try orbit for 10 rounds.
        x = x**2
        if abs(x) > 2.0:
                return 'no'
        return 'yes'
# print(orbit_img(1 + 2j))        ## no
# print(orbit_img(0.20 - 0.57j))  ## yes

''' Ploting Julia set of Complex numbers:
We will orbite a square function:
            z = z**2 - c
    where z and c are complex numbers (c is a constant).
We will test only z in range -2.0 to 2.0 of real and image parts.
If the initial z is in Julia set its real and image will be mapped to x and y
and plot (x,y) (in a frame of width and heigh).
To test whether a complex numbers z is in Julia set, we can orbit for some rounds
e.g 100 rounds) if the value does not goes beyond 2 then it is in Julia set.
'''
## Create a mapping from frame range (0, 600) to (-2, 2).
def map_range(x):  
    return (x - 300) * 2/300
# print(map_range(0), map_range(300), map_range(600)) ## -2.0 0.0 2.0

def julia():
    w, h = 600, 600    ## The frame is 600 x 600.
    iters = 100        ## The testing rounds.
    
    ## Create a black/white image with size w x h and white background.
    img = Image.new("L", (w, h), 255)

    ## Try:
    # c = 0
    # c = 1
    # c = 0.5 + 0.3j
    c = 0.1 + 0.73j
    # c = 0.51 + 0.53j
    # c = 0.73 + 0.21j
    # c = 0.81 + 0.16j
    # c = -0.64j

    for x in range(w):
        for y in range(h):
            z = map_range(x) + map_range(y)*1j
            for k in range(iters):
                z = z*z - c
            if abs(z) < 2:  ## if z is in Julia set.
                img.putpixel((x, y), 0) ## put a black pixel at x, y
    img.show()
# julia()     ## The points in Julia set are black.
## The points outside Julia set are more interested with color mapping.

## Create a color mapping.
rgb_range =  [0, 125, 255]
colors = [(i, j, k) for i in rgb_range for j in rgb_range for k in rgb_range ]
def map_color(k):
    return colors[k % len(colors)]

def non_julia():
    w, h = 600, 600
    iters, scale = 200, 30
    img = Image.new("RGB", (w, h), 255)
    
    c = 0.51 + 0.51j
    for x in range(w):
        for y in range(h):
            z = map_range(x) + map_range(y)*1j
            for k in range(iters):
                z = z*z - c
                if abs(z) > 2:  ## if z is not in Julia set.
                    img.putpixel((x, y), map_color(k))
                    break
    img.show()
# non_julia()

''' Julia shapes may be connected and disconnected depended on the value of c.
But some regions that appear to be a connected are actually disconnected
upon closer examination.

A quick method for testing the connectivity of a Julia set is starting
from z = 0 and a value of c then orbiting for some iterations if the value
does not go beyond 2 then the Julia set is connected.

Mandelbrot Set: set is the set of 'c' which makes the Julia shapes connected.
Mr.Mandelbrot ploted the set of c (called Mandelbrot set) using the real part
as x and the imagine part as y.
'''
def mandelbrot():
    w, h = 600, 600
    iters = 100
    img = Image.new("RGB", (w, h), 255)

    for x in range(w):
        for y in range(h):
            z = 0
            c = map_range(x) + map_range(y)*1j  ## try using different map_range()
            for k in range(iters):
                z = z*z + c
                if abs(z) > 2:
                    img.putpixel((x, y), map_color(k))
                    break
    img.show()
# mandelbrot()
''' It is the most famous shape in mathematics and computer science.
It shows that simple math can create incredible complexity pictures.

Julia shape are symmetry but Mandelbrot shape are not.
When we zoom in on Julia sets we see exactly the same shapes on different scales.
But Mandelbrot shape we can zoom in indefinitely and see similar shapes
that are not the same.
'''


