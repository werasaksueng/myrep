''' 'pgzero' is a wrapper built on top of 'pygame'.
It simplifies game programming in 'pygame' style.
	- No pygame.init().
	- No game loop needed.
	- No event handling boilerplate or annotation.

Install PygameZero:
pip install pgzero

PygameZero may be executed with python.exe (needs imported 'pygame').
with starting by pgzrun.go().
*** 
import pgzrun
WIDTH = 400; HEIGHT = 200
def draw():
    screen.draw.text("Hi", center=(200, 100), fontsize=60 )
pgzrun.go()
## python 3_pgzrun.py
'''
#-------------------------------------------------------

''' Alternatively: PygameZero provides 'pgzrun.exe' to start 'pgzrun'
and executes a .py file.
*** 
print('Hello!')    ## An empty screen is created and showed.
## pgzrun 3_pgzrun.py
'''
#---------------------------------------------------

''' 'pgzrun' injects a lot of objects (to be globols) before start running.
Some are provided by 'pygame' e.g. screen, keyboard, mouse, clock, ...
Some are imported from others e.g. Rect, Actor, animate, music, sounds, ...
To list all globals:
*** 
for name in sorted(globals()):
    print(name, type(globals()[name]))
'''
#------------------------------------------------

''' 'screen' is injected when 'pgzrun' starts and
will be shown when 'WIDTH' and 'HEIGHT' is defined.

draw() is called whenever the screen needs to be paint.
draw() must be at top-level scope.
*** 
WIDTH = 400; HEIGHT = 200   ## If not defined, the default is 800, 600.
def draw():
    # print(screen.width, screen.height)
    screen.clear()      ## Fill the screen with black.
    # screen.fill('red')  ## Fills the screen with 'red'.
    screen.draw.text("Hello", center=(150, 100), \
		 fontsize=60, color="white")
'''
#---------------------------------------------------

WIDTH = 400; HEIGHT = 200     ## For the rest runs.
''' 
A Pygame color is represented with class 'Color' (needs imported
pygame). A color is identified by:
   - string color name: Lowercase only and no spaces.
   - tuple of three int between 0 and 255 (red, green, blue).
To list all color names.
*** 
import pygame
print(pygame.color.THECOLORS.keys())
'''
#------------------------------------------------------

''' Rect is an injected class to draw box shape.
'screen.draw' has functions for drawing/filling shapes.
Ex. screen.draw.rect(<rec_object>, <color>)
    screen.draw.filled_rect(<rec_object>, <color>)
    screen.draw.circle(<center>, <radius>, <color>)
    screen.draw.filled_circle(<center>, <radius>, <color>)
    pygame.draw.polygon(screen.surface, <color>, [<point>,...])
    pygame.draw.ellipse(screen.surface, <color>, <rec_object>)
 	..........
*** 
def draw():
    rec = Rect((30, 20), (70, 50)) ## (<upper_left: x, y>, <width, height>)
    screen.draw.rect(rec, 'green')
    screen.draw.filled_rect(Rect((150, 20), (50, 70)), 'blue')
'''
#---------------------------------------------------------

''' Image files must be in director /images under the current directory.
File names may contain only lowercase, numbers and underscores.
Image files may be .png, .gif, and .jpg 

blit(<image>, (x, y)): Draw an image at (x,y) of the screen.
The top left corner is (0, 0).
<image> may be referred by file name (as string).
'blit' performs block copy which is very efficient.
*** 
def draw():
    screen.clear()
    screen.blit('bird3.png', (120,40))
'''
#------------------------------------------------------------

''' 'surface' is an object of class pygame.surface.Surface,
for drawing in memory then can be blit() on screen.
*** 
import pygame
from pygame.surface import Surface
sur = Surface((200, 100))
sur.fill('WHITE')
def draw():
    pygame.draw.circle(sur, 'RED', (100, 50), 30)
    screen.blit(sur, (60,30))
'''
#-----------------------------------------------------

''' Pygame has Class 'Sprite' for representing image as object.
'Actor' was introduced in PygameZero to simplify 'Sprite'.

'Actor' is an object contains an image (loaded from file or memory).
It has properties of the image e.g. x, y, pos and size.
It can draw itself, handle events and maintain visibility,
*** 
bird = Actor('bird3')      ## Create 'bird' actor from images/bird.png
bird.pos = (150, 100)     ## (top, left)
print(bird.x, bird.y)
print(bird.size)
def draw():
    bird.draw()
'''
#-----------------------------------------------------

''' PygameZero offers 'key' event handling:
*** 
def on_key_down(key):
    if key == keys.A:
        print('A')
    elif keyboard[keys.B] :
        print('B')
    elif keyboard.c :
        print('C')
    else:
        print("other")
'''
#--------------------------------------------------

''' Using keyboard to change actor position.
*** 
bird = Actor('bird3') 
bird.pos = (150, 150)
def update():
    if keyboard.left:
        bird.x -= 5
    if keyboard.right:
        bird.x += 5
    if keyboard.up:
        bird.y -= 5
    if keyboard.down:
        bird.y += 5
def draw():
    screen.clear()
    bird.draw()
'''
#---------------------------------------------------

''' Mouse even handling methods begin with 'on_mouse'
that will be executed when the mouse event happens.
Mouse buttons constants are:
    mouse.LEFT, mouse.MIDDLE (if any) and mouse.RIGHT.

Order of mouse event handling:
	1. on_mouse_down()
	2. on_mouse_move() if dragging
	3. on_mouse_up()

Ex. Testing mouse events.
'pos' is a tuple (x, y) of mouse position.
***
def on_mouse_down(pos, button):
    if button == mouse.LEFT:
        print("Left click at", pos)
    elif button == mouse.RIGHT:
        print("Right click at", pos)
    elif button == mouse.MIDDLE:
        print("Middle click at", pos)

def on_mouse_up(pos, button):
    print("Released", button, "at", pos)

def on_mouse_move(pos):
    print("Mouse moved", pos)
'''
#---------------------------------------------------
''' Ex. Paint
*** 
import pygame
WIDTH = 600; HEIGHT = 500 
lines = []		## Store drawn line segments
drawing = False		## Current drawing state
last_pos = None
current_color = "white"

def draw():
    screen.fill("black")

    ## Draw all saved lines
    for line in lines:
        start, end, color = line
        pygame.draw.line(screen.surface, color, start, end, 5)

    ## Show instructions
    screen.draw.text("Draw: Click Left and drag",
                     (10, 10), color="yellow")
    screen.draw.text("1=White  2=Red  3=Green  4=Blue  C=Clear",
                     (10, 30), color="yellow")
def on_mouse_down(pos, button):
    global drawing, last_pos
    if button == mouse.LEFT:
        drawing = True
        last_pos = pos
def on_mouse_move(pos):
    global last_pos
    if drawing and last_pos:
        lines.append((last_pos, pos, current_color))
        last_pos = pos
def on_mouse_up(button):
    global drawing
    if button == mouse.LEFT:
        drawing = False
def on_key_down(key):
    global current_color, lines
    if key == keys.K_1:
        current_color =  (255, 255, 255)
    elif key == keys.K_2:
        current_color =  (255, 0, 0)
    elif key == keys.K_3:
        current_color =  (0, 255, 0)
    elif key == keys.K_4:
        current_color =  (0, 0, 255)
    elif key == keys.C:
        lines.clear()
'''
''' Exercise:
 - Takes a picture of your face, saves in a file and shows on a screen.
 - Applies the above program to decorate: 
	moustache, horn and fang. 
'''