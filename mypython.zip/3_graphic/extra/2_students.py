##                   Student Grades.
## CSV File Reading
import csv
def read_csv(path):
    with open(path) as f:
        data = []
        for d in csv.DictReader(f):
            # print(d['id'], d['name'], d['hw'], d['mid'], d['fin'])
            data.append(d)
    return data
students = read_csv('students.csv')
# [print(s) for s in students]

def get(data, column):
    return [d[column] for d in data]

names = get(students, 'name')  # ; print(names)
fins = get(students, 'fin')    # ; print(fins)
mids = get(students, 'mid')    # ; print(mids)
hws = get(students, 'hw')      # ; print(hws)

''' Compute total score:  Suppose
          hw (0->10)   mid (0->100)    fin (0->100)
               total = 0.5*fin + 0.4* mid + hw       '''
def to_total(fin, mid, hw):
    return 0.5*float(fin) + 0.4*float(mid) + float(hw)

totals = [to_total(f, m, h) for f, m, h in zip(fins, mids, hws)]
# print(totals)

## Compute 'total' to 'grade':
def to_grade(total):
    return 'A' if total > 90 else \
           'B' if total > 80 else \
           'C' if total > 70 else \
           'D' if total > 60 else 'F'

grades = [ to_grade(t) for t in totals]
# print(grades)

## Report Grade:
# [print(name, '\t', grade) for name, grade in zip(names, grades)]

## Statistic
import numpy as np
def statistic():
    print('Number of students: %d' % len(names))
    print('Min: %1.2f\nMax: %1.2f' % (min(totals), max(totals)))
    print('Mean: %1.2f' % np.mean(totals))
    print('Median: %1.2f' % np.median(totals))
    print('SD: %1.2f' %  np.std(totals))
# statistic()

## Histograms
import matplotlib.pyplot as pl
# pl.hist(totals); pl.show()

## Pie Chart
def pie():
    gd = {'A': 0, 'B': 0, 'C': 0, 'D': 0, 'F': 0 }
    gl = len(grades)
    for g in grades:
        gd[g] += 1
    ng = [gd[g]*100/gl for g in gd] 
    pl.pie(ng, autopct='%1.1f%%', labels=['A', 'B', 'C', 'D', 'F'])
    pl.show()
# pie()
