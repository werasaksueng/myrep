''' 'matploylib' is a Python lib for ploting graphs and charts.
pip install matplotlib
'''
import matplotlib.pyplot as pl

''' plot(x, y): x and y must have the same size.
x and y may be range() or list.
x is optional, thedefault is [0, 1, 2, ...]
'''
## Default x:
y = [1, 3, 0, 5]
# pl.plot(y); pl.show()

## X-Y plot:
x = [6, 1, 2, 4]
# pl.plot(x, y); pl.show()

## x-axis is the controlled values, and scaled as needed.
# pl.plot(range(10, 50, 10), y); pl.show()

## Many Y on a default X.
# pl.plot([0, 3, 1, 4]); pl.plot([1, 0, 2, 3]); pl.show()

## Separate x-axis and y-axis on the same graph.
x1 = range(0, 4); y1 = [0, 3, 1, 4]
x2 = range(0, 10, 3); y2 = [1, 0, 2, 3]
# pl.plot(x1, y1, x2, y2); pl.show()

## Separated graphs by figures.
# pl.figure(1); pl.plot([1, 5, 2]); pl.title('Figure 1')
# pl.figure(2); pl.plot([1, 3, 1, 2]); pl.title('Figure 2'); pl.show()

''' Plot many figures on the same graph.
Subplot: <row>, <column>, <number>
'''
def subplot():
    pl.figure()        ## create a new figure

    pl.subplot(2,2,1)  ## Divide into 2 x 2 cells and select no. 1
    # pl.subplot(221)  ## Alternatively   
    pl.plot([3, 7, 1, 2, 8, 4])

    pl.subplot(222)    ## select no. 2
    pl.plot([4, 8, 3, 5, 1])

    pl.subplot(223)    ## select no. 3
    pl.plot([2, 6, 1, 8, 3])
    pl.show()
# subplot()

## Ex. Parabola Curve
def parabola():
    def poly(x):
        return x**2 + x + 1

    x = range(-10, 10)
    y = [poly(i) for i in x]
    pl.plot(list(x), y)
    pl.show()
# parabola()

import math
def log_plot():
    xr = range(1, 10)
    pl.plot(xr, [math.log2(x) for x in xr], color='green')## Base 2
    pl.plot(xr, [math.log(x) for x in xr], color='blue')  ## Base e
    pl.plot(xr, [math.log10(x) for x in xr], color='red') ## Base 10
    pl.show()
# log_plot()

## 'numpy' is a Python lib that supports vector handling.
import numpy as np          ## pip install numpy
## Linear spaces have more points creates smoother curves.
def tri_plot():
    xr = np.linspace(0, 2*np.pi)  ## A circle is 2 pi radian.
    pl.plot(xr, np.sin(xr), color='yellow')
    pl.plot(xr, np.cos(xr), color='purple')    
    pl.show()    ## Sin is 1/4 pi lag behind cos.
# tri_plot()   

## Ex. Random Distirbution Visualization.
import random
def randoms():
    xr = range(1000)
    uniform = [random.uniform(0, 2.0) for _ in xr] ## 0.0 -> 2.0
    pl.plot(uniform, 'r')

    standard = [random.random() for _ in xr]   ## 0.0 -> 1.0
    pl.plot(standard, 'g')

    gaussian = [random.gauss(1.0, 0.2) for _ in xr] ## mean, sd
    pl.plot(gaussian, 'b')
    pl.show()
# randoms()
#-------------------------------------------------------------

''' Bar Charts: X-axis and Y-axis must be the same size.
Histograms: Plots the number of occurrences for each values.
'''
def bar_his():
    pl.figure()        ## create a new figure
    y = [7, 2, 5, 3, 4, 4, 6, 5, 8, 6, 1, 5, 4, 2, 3]
    x = range(len(y))
    pl.subplot(2,1,1)
    pl.bar(x, y);
    
    pl.subplot(2,1,2)
    pl.hist(y);
    pl.show()
# bar_his()
#----------------------------------------------------------------

## Pie Charts: A circle graph that shows proportion in percentage.
data = [5, 15, 40, 30, 10]     ## The sum must be 100.
# pl.pie(data); pl.show()

def pie_plots():
    ## Divided into 2 x 2, specify the first figure.
    pl.subplot(221)
    pl.pie(data)                           ## default

    pl.subplot(222)
    pl.pie(data, autopct='%1.1f%%')        ## show percentage

    pl.subplot(223)    
    pl.pie(data, colors=('r', 'g', 'b', 'y', 'm'))   ## colors: default=('b', 'g', 'r', 'c', 'm', 'y', 'k', 'w')

    pl.subplot(224)
    grades = ('A', 'B', 'C', 'D', 'F')
    pl.title('OOP Spring 2017')         ## labels and title
    pl.pie(data, autopct='%1.1f%%', labels=grades)
    pl.show()
# pie_plots()


''' Scatter Plot:
 Scatter plots display points (x, y) that are not related by any known functions.
Used forshowing  visual correlation between two variables.
Just draws a dot at the point of (x, y).
'''
x = [7, 2, 5, 3, 3, 8, 9, 1, 2, 3]
y = [2, 4, 5, 4, 2, 2, 4, 1, 4, 1]
# pl.scatter(x, y); pl.show()

def correlation():
    ## The controlled x values
    x = np.random.randn(1000)
    y2 = np.exp(x) - x/1.3   ## An unknow function

    ## random plot means no relationship.
    pl.subplot(121)
    pl.scatter(x, y1)

    ## A curve means a and y are related by some function. 
    pl.subplot(122)
    pl.scatter(x, y2)
    pl.show()
# correlation()
 



