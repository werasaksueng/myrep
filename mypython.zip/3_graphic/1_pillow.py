## Pillow is an image-processing library for Python.
from PIL import Image   ## pip install pillow      

''' Show and Save Image:
Pillow shows images by send to the default image handling,
on Window it is 'Paint'.
'''
bird = Image.open('files/bird3.png')
# bird.show()

## save() saves an image into a file and may convert into other format.  '''
tree = Image.open('files/tree.jpg')
# tree.show()
# tree.save('tmp/tree.png')       ## Try: .gif, tif

## resize( (width, height) ) returns a resized image.
# tree.resize((200, 150)).show()

## crop( (x, y., width, height) ) returns a croped image.
# bird.crop((5, 27, 38, 92)).show()

''' Overlay: pastes an image on other image.
paste(<image>, x, y) pastes <image> at (x, y) on the called image.
paste() is an in-place operation, it has side effect (not return a result).
'''
sea = Image.open('files/sea.png')
# sea.paste(bird, (100, 100))
# sea.show()

## rotate(<degree>) rotates the called image by <degree>.
# bird.rotate(30).show()

## transpose(<operator>) processes the image by <operator>.
# bird.transpose(Image.TRANSPOSE).show()
# bird.transpose(Image.TRANSVERSE).show()
# bird.transpose(Image.ROTATE_90).show()
# bird.transpose(Image.ROTATE_180).show()
# bird.transpose(Image.ROTATE_270).show()
# bird.transpose(Image.TRANSVERSE).show()
# bird.transpose(Image.FLIP_LEFT_RIGHT).show()
# bird.transpose(Image.FLIP_TOP_BOTTOM).show()
#--------------------------------------------------------------------

''' Image Modes: The standard formats for image reprsentations.
 'RGB' is Red, Green, and Blue, 1 byte per color.
 'RGBA' is Red, Green, Blue, and Transparency, 1 byte per color.
 'CMYK' is Cyan, Magenta, Yellow, and Black, 1 byte per color.
 '1' is one bit per pixel, for black-and-white images.
 'L' is one byte per pixel values from 0 to 255 color or black and white. '''

## Create a RGB 'white' color image.
# Image.new('RGB', (400, 200), color='white').show()

## Images allow drawing graphic using ImageDraw.
from PIL import ImageDraw
def draw_objects():
    ## Create B/W image.
    im = Image.new('L', (400, 300), 255)
    imd = ImageDraw.Draw(im)
    imd.text((80, 80), 'Hello!')
    imd.line((100, 100, 200, 200))
    imd.ellipse((20, 20, 80, 50), fill=0)
    imd.rectangle((200, 20, 280, 70))
    imd.polygon([80, 220, 150, 280, 280, 250])
    im.show()
# draw_objects()
#------------------------------------------------------------

## Filter: filter(<filter>) processes an image with a filter.
from PIL import ImageFilter
road = Image.open('files/road.jpg')
rose = Image.open('files/rose.jpg')

''' Blur Filters:
ImageFilter.BLUR                  Simple blur
ImageFilter.GaussianBlur(radius)  Gaussian blur (configurable)
ImageFilter.BoxBlur(radius)	  Box blur (faster)
'''
def blurs(im):
    w, h = im.size
    ims = Image.new('RGBA', (2*w, 2*h))
    ims.paste(im, (0,0))
    ims.paste(im.filter(ImageFilter.BLUR), (w,0))
    ims.paste(im.filter(ImageFilter.GaussianBlur(10.0)), (0,h))
    ims.paste(im.filter(ImageFilter.BoxBlur(20.0)), (w,h))
    ims.show()
# blurs(tree)
# blurs(road)
# blurs(rose)

''' Smooth Filters:
ImageFilter.SMOOTH	     Mild smoothing
ImageFilter.SMOOTH_MORE	     Stronger smoothing   '''
def smooth(im):
    w, h = im.size
    ims = Image.new('RGBA', (2*w, 2*h))
    ims.paste(im, (0,0))
    ims.paste(im.filter(ImageFilter.SMOOTH), (0,h))
    ims.paste(im.filter(ImageFilter.SMOOTH_MORE), (w,h))
    ims.show()
# smooth(rose)
# smooth(road)

''' Sharpen Filters:
ImageFilter.SHARPEN	        Sharpen image
ImageFilter.DETAIL	        Enhance fine details
ImageFilter.EDGE_ENHANCE	Enhance edges
ImageFilter.EDGE_ENHANCE_MORE	Stronger edge enhancement
'''
def sharpen(im):
    w, h = im.size
    ims = Image.new('RGBA', (2*w, 2*h))
    ims.paste(im.filter(ImageFilter.SHARPEN), (0,0))
    ims.paste(im.filter(ImageFilter.DETAIL), (w,0))
    ims.paste(im.filter(ImageFilter.EDGE_ENHANCE), (0,h))
    ims.paste(im.filter(ImageFilter.EDGE_ENHANCE_MORE), (w,h))
    ims.show()
# sharpen(tree)

''' Edge Detection Filters:
ImageFilter.FIND_EDGES	Highlight edges
ImageFilter.CONTOUR	Outline contours
ImageFilter.EMBOSS	Emboss effect   '''
def edge(im):
    w, h = im.size
    ims = Image.new('RGBA', (2*w, 2*h))
    ims.paste(im, (0,0))
    ims.paste(im.filter(ImageFilter.FIND_EDGES), (w,0))
    ims.paste(im.filter(ImageFilter.CONTOUR), (0,h))
    ims.paste(im.filter(ImageFilter.EMBOSS), (w,h))
    ims.show()
# edge(road)

''' Statistical Filters:
ImageFilter.MedianFilter(size=3)	Remove noise
ImageFilter.MinFilter(size=3)	        Darken (min)
ImageFilter.MaxFilter(size=3)	        Brighten (max)
ImageFilter.ModeFilter(size=3)	        Most common pixel  '''
def statistic(im):
    w, h = im.size
    ims = Image.new('RGBA', (2*w, 2*h))
    ims.paste(im.filter(ImageFilter.MedianFilter), (0,0))
    ims.paste(im.filter(ImageFilter.MinFilter), (w,0))
    ims.paste(im.filter(ImageFilter.MaxFilter), (0,h))
    ims.paste(im.filter(ImageFilter.ModeFilter), (w,h))
    ims.show()
# statistic(sea)      ## Try: tree

def position(i, w, h):
    return (0,0) if i == 1 else (w,0) if i == 2 else (0,h) if i == 3 else (w,h)

''' Enhance: by some factors.  '''
from PIL import ImageEnhance
def enhance(im):
    w, h = im.size
    ims = Image.new('RGBA', (2*w, 2*h))
    for i in range(1, 5):
        e = ImageEnhance.Contrast(im).enhance(i)
#        e = ImageEnhance.Sharpness(im).enhance(i*10)
#        e = ImageEnhance.Brightness(im).enhance(i/2)
#        e = ImageEnhance.Color(im).enhance(i)
        ims.paste(e, position(i, w, h))
    ims.show()
# enhance(tree)
# enhance(road)

''' Image Operations '''
flower = Image.open('files/flower.jpg')
from PIL import ImageOps
def im_ops(im):   
    im = im.resize((250,200))
    w, h = im.size
    ims = Image.new('RGBA', (3*w, 3*h))
    ims.paste(ImageOps.autocontrast(im, cutoff=70), (0,0))
    ims.paste(ImageOps.crop(im, border=10), (w,0))
    ims.paste(ImageOps.expand(im, border=10), (2*w,0))
    
    ims.paste(ImageOps.flip(im), (0,h))
    ims.paste(ImageOps.mirror(im), (w,h))
    ims.paste(ImageOps.grayscale(im), (2*w,h))

    ims.paste(ImageOps.equalize(im), (0, 2*h))
    ims.paste(ImageOps.posterize(im, bits=3), (w, 2*h))
    ims.paste(ImageOps.solarize(im, threshold=128), (2*w, 2*h))    
    ims.show()
# im_ops(flower)

## Image Channel Operations
from PIL import ImageChops
def invert(im):
    w, h = im.size
    ims = Image.new('RGBA', (3*w, h))
    ims.paste(im, (0, 0))
    ims.paste(ImageOps.invert(im), (w,0))
    ims.paste(ImageChops.invert(im), (2*w,0))
    ims.show()
# invert(rose)
# invert(tree)

#---------------------------------------------------------

''' getpixel((x,y)) returns the color of the pixel at x,y.  '''
def image_process():
    im =  Image.open('files/rose.jpg')
    # im = Image.open('files/flower.jpg')
    w, h = im.size
    for x in range(w):
        for y in range(h):
            r, g, b = im.getpixel((x, y))
            im.putpixel((x,y), (g, r, b))   ## Swap red and green
                                            ## Try: (b, g, r)
    im.show()
# image_process()

