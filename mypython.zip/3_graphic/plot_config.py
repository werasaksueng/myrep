import matplotlib.pyplot as pl 

''' Plot Configuration. '''
xr = range(10)
y1 = [i for i in xr]
y2 = [i*2 for i in xr]
y3 = [i*3 for i in xr]
y4 = [i*4 for i in xr]
y5 = [i*5 for i in xr]
y6 = [i*6 for i in xr]
y7 = [i*7 for i in xr]
y8 = [i*8 for i in xr]

''' Color:
  'b' = blue(default), 'r = red, 'g' = 'green', 'y' = yellow
  'k' = black, 'w' = 'white, 'm' = magenta, 'c' = cyan,
  'orange', 'purple', 'brown', 'pink', 'gray'

Using tuple of floats (0–1) or integers (0–255).
RGB   (red, green, blue)         or in hex '#RRGGBB' 
RGBA  (red, green, blue, alpha)
'''
def colors():
    pl.plot(y1, 'b')          ## Blue
    pl.plot(y2, 'red')
    pl.plot(y3, 'orange')
    pl.plot(y4, color=(0.0, 0.8, 0.7))
    pl.plot(y5, color='#0FFF0F')
    pl.show()
# colors()

def alphas():
    pl.plot(y1, color='b', alpha=0.1)             
    pl.plot(y2, color='b', alpha=0.2)
    pl.plot(y3, color='b', alpha=0.3)
    pl.plot(y4, color='b', alpha=0.4)
    pl.plot(y5, color='b', alpha=0.5)
    pl.plot(y6, color='b', alpha=0.6)
    pl.plot(y7, color='b', alpha=0.7)
    pl.plot(y8, color='b') # default: 1
    pl.show()
# alphas() 

def line_width():
    pl.plot(y1, linewidth=1)  
    pl.plot(y2, lw=4)
    pl.show()
# line_width()

## 'linestyle' is optional if the symbol is valid.
def line_style():
    pl.plot(y1, linestyle='-')  ## Solid line (default)
    pl.plot(y2, '--')           ## Dashed line
    pl.plot(y3, '-.')           ## Dash-dot line
    pl.plot(y4, '.')            ## Dotted line
    pl.plot(y5, ':')            ## Dense Dotted line
    pl.plot(y6, '')             ## Nothing
    pl.show()
# line_style()

## 'marker' if defined, a line is drew.
def markers():
    pl.plot(y1, marker='o')   ## Circle (default)
    pl.plot(y2, '^')          ## Upward-pointing triangle
    pl.plot(y3, 's')          ## Square
    pl.plot(y4, '+')          ## Plus
    pl.plot(y5, 'x')          ## Cross
    pl.plot(y6, 'D')          ## Diamond
    pl.show()
# markers()

## Try: combinations:
##      '+r', 'xr', 'xb', 'or', and 'D-r'.

def mark_size():
    pl.plot(y1, 'o')
    pl.plot(y2, 's', ms=10)
    pl.plot(y3, 'x', ms=20)
    pl.show()
# mark_size()    

def margins():
    pl.margins(0.2)
    pl.plot(y1)
    pl.show()
# margins()

''' Limited X-Y axis and grid. '''
def xylim():
    xa = np.linspace(0, 2*np.pi)
    pl.plot(xa, np.sin(xa))
    pl.xlim([0, 2*np.pi])
    pl.ylim([-1.2, 1.2])
    pl.grid()
    pl.show()
# xylim()

def scale_axis():
    i = np.linspace(0, 2*np.pi)
    pl.figure()
    pl.subplot(221)
    pl.axis('auto')   # default
    pl.plot(np.sin(i), np.cos(i))

    pl.subplot(222)
    pl.axis('equal')
    pl.plot(np.sin(i), np.cos(i))   
    pl.show()
# scale_axis()

## puzzle
def puzzle():
    r = 1.2
    i = np.arange(0, 4*np.pi, 0.01)
    pl.axis('equal')
    pl.plot(np.sin(i)*r, np.cos(0.5*i)*r)
    pl.show()    
# puzzle()

def titles():
    pl.figure()
    
    pl.subplot(221)
    ## fontsize { 'large'(default), 'medium', 'small', or an actual size}
    pl.title('Title 1', fontsize='small')

    pl.subplot(222)
    ## verticalalignment(va) { 'top', 'baseline', 'bottom', 'center'(default) }
    pl.title('Title 2', va='bottom')

    pl.subplot(223)
    ## horizontalalignment(ha) { 'center', 'left', 'right'(default) }
    pl.title('Title 3', ha='left')

    pl.tight_layout()
    pl.show()
# titles()

def ticks():
    r = range(10)
    s = [0.5*9.8*t*t for t in r]  ## s = 0.5 * g * t^2
    pl.plot(r, s)
    pl.margins(0.1)
    x_labels = ['sec %d' % (i) for i in r]
    y_labels = ['%d meters' % (i) for i in r]
    pl.xticks(r, x_labels, rotation='vertical')
    pl.yticks(s, y_labels,)
    pl.show()
# ticks()

def xylabels():
    pl.xlabel('x label')
    pl.ylabel('y label')
    pl.show()
# xylabels()   
   
def legends():
    pl.plot(y1, label='y1')
    pl.plot(y2, label='y2')
    pl.plot(y3, label='y3')
    pl.legend()
    
    pl.legend(loc= 0)    # loc: 0 -> 10
    ## 0 best, 1 upper right, 2 upper left, 3 lower left, 4 lower right, 5 right, 
    ## 6 center left, 7 center right, 8 lower center, 9 upper center, 10 center 
    pl.show()
# legends()

## Annotate:
def annotate():
    x = np.linspace(1, 100)
    y = [np.log10(i) for i in x]
    pl.plot(x, y)
    pl.annotate("log10(50)", (50, np.log10(50)), xytext=(5, 1.8),  
           arrowprops=dict(arrowstyle='->'))
    pl.show()
# annotate()

## Text:
def text():
    pl.plot([-1, 1, 0, 0], [0, 0, -1, 1], 'o')
    pl.text(0, 0, 'origin')
    # pl.text(0, 0, 'origin', va='center', ha='center')
    pl.show()
# text()
#--------------------------------------------------
## Pie Plot Cponfig:

def pie_config1():
    d = [5, 15, 40, 30, 10]  

    pl.subplot(221)
    pl.pie(d)                           ## default

    pl.subplot(222)
    pl.pie(d, autopct='%1.1f%%')        ## show percentage

    pl.subplot(223)    
    pl.pie(d, colors=('r', 'g', 'b', 'y', 'm'))   ## colors: default=('b', 'g', 'r', 'c', 'm', 'y', 'k', 'w')

    pl.subplot(224)
    pl.pie(d, startangle=90)            ## startangle, The default is from 15 min, counter-clolkwise.
    pl.show()
# pie_config1()

def  pie_config2():
    d = [5, 15, 40, 30, 10]
    
    pl.subplot(221)
    pl.pie(d, counterclock=False)       ## counterclock: True, False

    pl.subplot(222)
    pl.pie(d, shadow=True)              ## shadow {True, False}

    pl.subplot(223)
    exp=(0.1, 0.1, 0.1, 0.1, 0.1)
    pl.pie(d, explode=exp)              ## explode = fraction of the radius to offset each wedge.

    pl.subplot(224)
    grades = ('A', 'B', 'C', 'D', 'F')
    pl.title('OOP Spring 2017')         ## labels and title
    pl.pie(d, autopct='%1.1f%%', labels=grades) 
    pl.show()
# pie_config2()

