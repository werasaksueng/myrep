## 'turtle' is a Python library for turtle graphic.
import turtle

## Creates a turtle at the center (0, 0). Its head looks to the right.
t = turtle.Pen()

## Crawling:
# t.forward(100)
# t.left(90) 

## Alternative: All turtle commans have abbreviation.
# t.fd(50) 
# t.rt(60)

''' Return ('\r'), new-line ('\n') and ';' are statement separators.
Python encourages a statement per line. 
Ex. Box:
'''
# t.fd(100); t.rt(90); t.fd(100); t.rt(90); t.fd(100); t.rt(90); t.fd(100); t.rt(90)

#--------------------------------------------------
## supplement\src\functions.py

def box(width):
    t.fd(width); t.rt(90)
    t.fd(width); t.rt(90)
    t.fd(width); t.rt(90)
    t.fd(width); t.rt(90)
# box(50)
# box(100)

#--------------------------------------------------
## supplement\src\iteration.py
## supplement\src\ranges.py

def square(width):
    ## To repeat 4 times.
    for _ in range(4):      ## _ is the don't care symbol.
        t.fd(width)
        t.rt(90)
# square(100)

#--------------------------------------------------
## supplement\src\decision.py

def flower():
    for i in range(300):
        if i < 40:
            t.color("blue")
        elif i < 80:
            t.color("purple")
        elif i < 150:
            t.color("red")
        elif i < 200:
            t.color("orange")
        else:
            t.color("yellow")
        t.forward(i)
        t.left(91)
# t.speed(100)    ## More value is faster. (0 is max speed).
# flower()

## Exercise:  What does the function draws?
def puzzle(n, angle, width=200): ## 'width' is a default parameter.
    for i in range(n):
        t.forward(width)
        t.right(angle)
# puzzle(5, 144)

'''  Homework: Draw a house, a tree, a fish, and a cat.
More commands in turtle_supplement.txt.
'''
