## Programming allowes playing with idea and concepts.

from myutil import *     ## import everything from myutil.py

## Ex. Repeatedly draw a line with rotate angle and reduce width.
def roses(): 
    def rose(rounds, angle, dif, width=3):
        for _ in range(rounds):
            t.forward(width)
            t.left(angle)     ## rotate by angle.
            width -= dif      ## width is reduced by dif.
  
    move_to(-200, 120);  rose(40, 45, 1)
    move_to(0, 120);     rose(35, 65, 2)
    move_to(200, 120);   rose(35, 85, 4)  
    move_to(-200, -100); rose(35, 97, 3)
    move_to(0, -100);    rose(40, 113, 5)
    move_to(240, -100);  rose(70, 143, 3)
# roses()

## Ex. Repeatedly draw a line with rotate angle and double width.
def spirals():
    def spiral(rounds, angle):
        for w in range(rounds): ## Using number of round as the width.
            t.forward(w*2)
            t.left(angle)
    
    move_to(-150, 120); spiral(60, 70)
    move_to(100, 120); spiral(80, 91)
    move_to(-150, -140); spiral(100, 123)
    move_to(100, -140); spiral(110, 151)
# spirals()

## Ex. Repeatedly draw a square and rotate.
def flowers():
    def square(width):
        for _ in range(4):
            t.fd(width)
            t.rt(90)

    def flower(angle, width=70, dif=2): ## Try: dif= 3, 4, 5  
        steps = (360 // angle) + 1
        for i in range(steps):
            square(width)
            t.left(angle)
            width -= dif

    move_to(-150, 130); flower(10) 
    move_to(150, 130); flower(15)
    move_to(-150, -130); flower(30)
    move_to(150, -130); flower(60)
# flowers()

## Ex. Repeat squares with reducing width and rotate angle.
def snails():
    def square(width):
        for _ in range(4):
            t.fd(width)
            t.rt(90)

    def snail(width, angle, dif):
        for _ in range(360//angle):
            square(width) 
            t.left(angle)
            width -= dif

    move_to(-250, 0); snail(60, 33, 7)
    move_to(-80, 0); snail(70, 19, 2) 
    move_to(100, 0); snail(20, 10, 4)
# snails()

## Ex. Repeating circles with a little rolated angle.
def circles():
    def circle(angle, radius=50):
        for i in range(360//angle):       ## // is integer division.
            t.color('red')
            t.circle(radius)
            t.left(angle)

    move_to(-210, 0); circle(90)
    move_to(0, 0); circle(30)
    move_to(210, 0); circle(10)
# circles()
#-------------------------------------------------------

## Exercises: Figure out how the shapes are drew?
def puzzle1():
    t.color('red')
    t.begin_fill()
    t.left(140)
    t.forward(113)
    t.circle(-57, 200)
    t.left(120)
    t.circle(-57, 200)
    t.forward(113)
    t.end_fill()
# puzzle1()        ## Hint: Slow down the drawing.

def puzzle2():
    for _ in range(10):
        for _ in range(8):
            t.forward(80)
            t.right(45)
        t.right(36)
    t.hideturtle()        
# puzzle2()

def puzzle3():
    for _ in range(10):
        t.right(36)
        for _ in range(5):
            t.forward(100)
            t.right(72);
    t.hideturtle()
# puzzle3()

def puzzle4(width, angle):
    for i in range(36):
        for j in range(5):
            t.forward(width)
            t.right(angle)
        t.left(10)
def puzzle4_ex():
    move_to(-300, 130); puzzle4(200, 131)
    move_to(180, 90); puzzle4(120, 144)
    move_to(-130, -180); puzzle4(200, 175)
    move_to(80, -130); puzzle4(150, 151)
# puzzle4_ex()

import random
def puzzle5(sides):
    for m in range(5,75):
        t.left(360/sides + 5)
        t.width(m // 25+1)
        t.penup()
        t.forward(m*4) ## Move to next corner
        t.pendown()
        t.pencolor(random.choice(colors))
        if (m % 2 == 0):
            for n in range(sides):
                t.circle(m/3)
                t.right(360/sides)
        else:
            for n in range(sides):
                t.forward(m)
                t.right(360/sides)
# puzzle5(4)
# puzzle5(5)
# puzzle5(7)

###########################################################

## Bonus.

## Random is the seed of good art and fun games.
def rand_art(number):
    ## Random shape, size, location and colors.
    def rand_xy():
        src_width = turtle.window_width()
        src_height = turtle.window_height()
        x = random.randrange(-src_width//2, src_width//2)
        y = random.randrange(-src_height//2, src_height//2)
        return x, y		## Return a tuple.

    def spiral(rounds, angle):
        for w in range(rounds):
            t.forward(w*2)
            t.left(angle)
          
    for _ in range(number):
        t.pencolor(random.choice(colors))
        move_to(*rand_xy())   ## Tuple unpacking.
        spiral(random.randint(5,50), random.randint(91,94))
        # spiral(random.randint(4,63), random.randint(81,97))
# rand_art(70)

''' Closed Objects: are figures that can be rotate and 
 drawn repeatedly then finish drawing at the starting point.
'''
def closed_ob1():
    def cobj(width):
        t.forward(width);  t.right(90)
        t.forward(width);  t.right(90)
        t.forward(width/2);   t.right(90)
        t.forward(width/2);   t.right(90)
        t.forward(width);  t.right(90)
        t.forward(width/4);   t.right(90)    
        t.forward(width/4);   t.right(90)   
        t.forward(width/2)

    ## A single draw.
    move_to(-260, 0)
    cobj(50)

    ## Nine draws that finish at the starting point.
    move_to(150, 0) 
    for i in range(9):
        cobj(50)
        t.right(10)
        t.forward(25)
# closed_ob1()

def closed_ob2():
    ## Closed object with an angle rotation.
    def cobj(width, angle, max, loop):
        for _ in range(loop):
            for i in range(1, max+1):    
                t.forward(width*i)
                t.right(angle)
        
    move_to(-300, 100);  cobj(5, 90, 10, 1)
    move_to(-150, 100);  cobj(5, 90, 10, 2)
    move_to(100, 100);   cobj(5, 45, 10, 4)
    move_to(250, 100);   cobj(5, 60, 10, 3)    
    move_to(-280, -150); cobj(3, 45, 11, 8) 
    move_to(-80, -150); cobj(3, 60, 13, 7)
    move_to(30, -150);    cobj(4, 90, 15, 4) 
    move_to(250, -150);  cobj(10, 144, 8, 5)    
# closed_ob2()
#---------------------------------------------------------

