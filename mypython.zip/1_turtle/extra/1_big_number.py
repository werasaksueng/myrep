''' Most programming languages e.g. C, C++ and Java represent integers
as a fixed size e.g. 2, 4, or 8 bytes. But Java has BigIntegeer class.
Python 'int' objects represent integer that may extend size as needed (up to memory limit).
'''
# print(123**123)


''' Mr.Ben Chess
In the ancient India there was a King Shirham who was a war addict.
His habit caused poverty and casualties.
His people, the riches and poors hated him.
So they asked Sissa Ben Dahir (Mr.Ben), a wise guy to find
a way to made the King stops enjoying wars. 
Mr.Ben invented a game (the root of today chess) and
presented to the king.
The King deeply hooked to the game, no battle anymore.
People live happyly... But the king just realized
it's time to give Mr.Ben a reward.
'Tell me what you want, only if it is on this world.'
Surprisingly the hyper-smart guy asked for grains of rice.
He pulled out an 8 x 8 board and asked for:
    	1 grains on the first cell.
	2 grains on the secound cell.
	4 grains on the third cell.
   And double number of grains on the rest of cells.
"Ha ha....!" The King laugh. "You can ask for a city or even 
a kingdom but why grains of rice? Just go to my storage, 
what ever you want."
Before long, the Minister of Finance broke out:
"Your Majesty! the number of grains he asked was:"
	2**0 + 2**1 + 2**2 + 2**3 + …+ 2**63 
 	= 2**64 - 1
        = 18,446,744,073,709,551,615
In a god blessed year, our kingdom would produce about 
1,000 million carts(เกวียน) of rice. Assume that there are about
10 million grains of rice per cart.
I don't think we can produce that amount of rice in this millennium."
Smoke came out of The King ears, but the King words cannot be defied.
"I cannot perpare that among of rice today, come back tomorrow."
Then the wise guy was dragged to beheaded.
'''
def rice():
    n = 2**64 - 1
    carts = n / 10_000_000          ## 10 million grains per cart.
    years = carts / 1_000_000_000   ## 1,000 million carts per year.
    print(round(years, 2))
# rice()

'''			Towers of Hanoi (TOH):
In a temple of Lord Shiva in city of Benares.
Since the brith of the universe, there are 3 diamond poles:
A, B and C. And 64 golden disks at pole A.
The disks have a hole in the center.
They are unequal size from the biggest at the bottom to
the smallest at the top.
We are allowed to take one disk off a pole at a time,
But the disk must be place at one of the pole, not on the ground.
And a bigger disk must not rest on a smaller one.
The task is to move all 64 discs from pole A to pole B using
pole C for temporary.

The legend told that priests in this temple had performed the task
of moving the disk (by problem reduction), all days all nights
and has never stopped.

Problem Reduction: is an approch of problem solving that
partitions the problem into sub-problems then recurively solve
each sub-problems.

It had been proved that the strategies is optimum.
Suppose moving a disk takes one second.
It will take 2**64 - 1 sec to finish moving 64 disks.
'''
def toh(n, src = 'A', target = 'B', tmp = 'C'):
    if n == 1:
        print('Move from %s to %s' % (src, target))
    else:
        toh(n-1, src, tmp, target)
        print('Move from %s to %s' % (src, target))
        toh(n-1, tmp, target, src)
# toh(3)        ## Try: more disks.

'''
			M(n)AB
		 /	   |	     \
	  M(n-1)AC	M(1)AB	      M(n-1)CB

How long (in billion years) is 2**64 - 1 seconds.
'''
def toh():
    seconds = 2 ** 64 - 1
    minutes = seconds / 60
    hours = minutes / 60
    days = hours / 24
    years = days / 365.25
    million_years = years / 1000000
    billion_years = million_years / 1000
    print(round(billion_years, 2))
# toh()
''' 
Our universe had been existed for about 3.5 billion years
and expected to last no more than 15 billion years.
'''
#--------------------------------------------------------

''' Exercises:
 1. In America, 1 billion is 10**9 but in Europe 1 billion is 10**12.
Suppose a boy starts respiring since the moment he was born and
repeats one every second.
How old is the American boy when he respires the number 1 billion.

 2. For the western, 6 is an unlucky number and 666 is the evil number.
Is 6**6 * 6**6 * 6**6 bigger than 6**(6*6)?

 3. Given n! is the factorial of n, 
             n! = n*(n-1)*(n-2)*...*1.
A googol is 10**100.
Is a google bigger than (5!)! ?       Hint: math.factorial(n)
'''
