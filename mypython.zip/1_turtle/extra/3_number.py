''' Fractions
Python supports reprsentation of fractions as numerator/denominator.
'''
from fractions import Fraction
def fract_ex():
    print(Fraction(1, 2))         ## 1/2
    print(Fraction(1/2))          ## 1/2
    print(Fraction('1/2'))        ## 1/2
# fract_ex()

## A fraction is an object that contains numerator and denominator.
a = Fraction(1, 2)
# print(a.numerator, a.denominator)   ## 1 2

## Python supports fraction math operations.   
b = Fraction(3, 4)
# print(a + b, a - b, a * b, a / b, a**2)     ## 5/4 -1/4 3/8 2/3 1/4

## Comparision operations for fractions.
# print(a < b, a <= b, a > b, a >= b, a == b) ## True True False False False

## A fraction is auto-minimized.
# print(Fraction(3, -6))        ## -1/2   

## But not auto-simplified.
x = 1 + Fraction(1, 2)
y = 2 + Fraction(1, 3)
# print(x * y)                    ## 7/2

## Excerise: Write a function to simplify fraction.
#------------------------------------------------------

'''  float
Python 'float' has size of 64-bits, that is about 15–17 decimal places.
Max float is about 1.797 × 10**308
Min positive float is about 2.225 × 10**-308
''' 
# print(1.0 / 3)	## 0.3333333333333333

## 'float' operations are not exact.
# print(0.1 + 0.2)            ## 0.30000000000000004
# print(0.3 == (1.0 + 0.2))

## 'float' is enough for most computations but not always.
#-------------------------------------------------------

''' Decimal
Python supports 'Decimal' for arbitrary high precision float.
Creating a decimal from float is a bad practice, that already imprecise!.
Using str representation is encouraged.
Decimal supports math operations: + - * / % and **.
'''
from decimal import Decimal
# print(Decimal(0.1))     ## 0.1000000000000000055511151231257827021181583404541015625
# print(Decimal('0.1'))   ## 0.1

## The default 'context precision' is 28 positions.
# print(getcontext().prec)           ## 28
# print(Decimal('1') / Decimal('3')) ## 0.3333333333333333333333333333

## To set 'context precision' to 50.
# getcontext().prec = 50 
# print(Decimal('1') / Decimal('3')) ## 0.33333333333333333333333333333333333333333333333333
#--------------------------------------------------------------

''' Complex Number
Python supports 'complex number', using 'j' as the sqroot of -1.
'''
m = 1 + 2j                  ## 1 is real, 2 is imagine.
print(m)		    ## (1+2j)
# print(m.real, m.imag)     ## 1.0 2.0

## Complex number suports math operations: + - * / % and **.
n = 3 + 4j
# print(m+n, m-n, m*n, m/n, m**2)  ## (4+6j) (-2-2j) (-5+10j) (0.44+0.08j)

## Python standard lib 'cmath' supports complex number functions.
import cmath
def cmath_ex():
    print(cmath.sqrt(-1))       ## 1j
    print(cmath.sqrt(3 + 4j))   ## (2+1j)
    print(cmath.sin(m))     ## (3.165778513216168+1.959601041421606j)
    print(cmath.log10(m))   ## (0.3494850021680094+0.480828578784234j)
    print(abs(n))	    ## ## 5.0   sqrt(3**2 + 4**2)
# cmath_ex()
