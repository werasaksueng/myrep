########################################################
## Computers never get bore doing the same task.

## Multiplication Tables:
def mul_table(n=2):
    for i in range(2, 13):
        print('%2d x %d = %4d' % (i, n, i*n))
# mul_table()       ## Try: Multiplication of 3,4,5,...

## Using 'comprehension' an iteration in an expression.
# [print('%2d x %d = %4d' % (i, 2, i*2)) for i in range(2, 13)]

''' 'for' loop can be nested.
Ex. Printing 2 to n multiplication tables.
'''
def tables(n):
    for i in range(2, n+1):
        for j in range(2, 13):
            print('%2d x %d = %4d' % (j, i, j*n))
        print()
# tables(12)        ## Try: 100 multiplication tables.

''' Exercises: Print 12 multiplication-tables in a single table.
    e.g.      1 2 3  4  5  ....... 12
            1 1 2 3  4  5  ........
            2 2 4 6  8  10 ........
            3 3 6 9  12 15 ........
            4 4 8 12 16 20 ........
            .......................
            12 ....................144
'''
#----------------------------------------------------

''' Math is fun if you don't have to do the calculation.

Ex The Multiples of 8 and 9:
For n is a number from 1 to 9.
Multiply n with the following numbers:
  88, 89, 99, 108, 109,189, 199, 898, 899, 989, 999, 1089, 1099, 10889, 10899,....
Check digits in each vertical columns of the results.
'''
def mul9():
    for n in [88, 89, 99, 108, 109,189, 199]: ## Try: some more.
        print('n is %4d' % n)
        for i in range(1, 10):
            print(f'{(n*i):5d}')
        print()
# mul9()
''' Exercises:
    1. Multiply 37 with numbers that are multiple of 3.
Starting from 3 to 100.     Hint: range(<start>, <stop>, <step>)

    2. Multiply 142857 with numbers that are multiple of 7.
Starting from 7 to 100.
'''

#----------------------------------------------------------------
## Working with random

import random
## Ex. Print 10 kumon of two 2 digits numbers.
def kumon():
    for i in range(10):
        ops = ['+', '-', 'x', '%']
        x = random.randint(2, 99)
        op = random.choice(ops)
        y = random.randint(2, 99)
        print('%2d %s %2d =' % (x, op, y))
# kumon()

#------------------------------------------------------

'''             Generate Random Passwords:
   - Length between 4 to 6 characters.
   - Contains number digits and lower/upper case letters.
       Excludes: 0, 1, o, O, i, I, l
'''
import string
def gen_symbols():
    DIGITS = list(string.digits)
    DIGITS.remove('0'); DIGITS.remove('1')
    UPPER = list(string.ascii_uppercase)
    UPPER.remove('O'); UPPER.remove('I')
    LOWER = list(string.ascii_lowercase)
    LOWER.remove('o'); LOWER.remove('i'); LOWER.remove('l')
    return DIGITS + LOWER + UPPER
SYM = gen_symbols()
# print(SYM)

## Generate a random password.
def gen_pwd():  
    pwd = ''
    for i in range(random.randint(4, 6)):
        pwd += random.choice(SYM)
    return pwd

## Generate 10 passwords.
# [print(gen_pwd()) for _ in range(10)]
#----------------------------------------------------------

''' Pi approximation by random dart throwing.

Imagine throwing random darts at a square containing a circle.
Suppose we consider only a quarter of the square.
The ratio of darts landing inside the quarter circle to
the total darts is approximately:
            <inside>      4
            --------   =  -
            <total>       PI
'''
def pi(total=1_000_000):
    inside = 0
    for i in range(total):
        # Generate random coordinates between 0 and 1
        x = random.random()
        y = random.random()

        # Check whether the dart is inside the quarter circle
        if x*x + y*y <= 1:
            inside += 1
    return 4 * inside / total
# print(pi())



