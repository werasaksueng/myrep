''' Pi is circumference / diameter

2000 BC, the Babylonians wrote on baked clays:
            Pi is about 3 + 1/8

1800 BC, the Egyptians wrote on paprus:
            Pi is about (16/9)**2  or  256/81
We do not know how they figure out the values.

Archimedes was the first to propose a systematic method
for estimating Pi. In his time, Pi value was unknown so
no formula to compute a circle area. 
Archimedes approximated a circle is bound indside a polygon.
Starting with a 6-side polygon then repeatedly doubled
the number of sides. The more number of sides, the more accuracy.
This was the earliest and greatest mathematic idea.
'''
import math
def arch_pi():
    radius = 1
    n = 6                 ## Start with a 6-sides hexagon.
    for i in range(10):
        ## Length of one side of an n-sides polygon.
        side = 2 * radius * math.sin(math.pi / n)

        ## Polygon perimeter (≈ circumference)
        perimeter = n * side

        ## pi = circumference / diameter
        pi_approx = perimeter / (2 * radius)
        print(f"n = {n:6d},  pi ≈ {pi_approx:.15f}")

        n *= 2             ## Double the number of sides
# arch_pi()

''' Archimedes found that Pi is about 211875/67441 but he
believed 22/7 is good enough (for the next two thousand years).
But it is correct for only 2 decimal points.
Python provides math.pi that is up correct to 15 decimal points.
'''
import math
# print(22/7)        ## 3.142857142857143
# print(math.pi)     ## 3.141592653589793

## The best Pi approximation using two digits fraction.
def pi_app():
    x, y, c = 0, 0, 1
    for a in range(1, 100):
        for b in range(1, 100):
            d = a/b - math.pi
            d = d if d > 0 else -d
            if d < c:
                x, y, c = a, b, d
    print("%d / %d" % (x , y))
# pi_app()

## Exercise: Find the best Pi approximation using three digits fraction.

## 150AD, Ptolemy, an Egypt king declared Pi is 377/120.
# print(377/120)              ## 3.1416666666666666 (3 digits correct)

''' 263AD, Liu Hui a Chinese guy proposed Pi is 3.1415 (4 digits correct)
and suggested 157/50 is more suitable becuase it divides by 50. '''
# print(157/50)               ## 3.14 

''' 480AD, Tsu-ching Chih an another Chinese proposed Pi is 355/113
which is the best Pi up to the 15th century, the longest champion in history. '''
# print(355/113)              ## 3.1415929203539825 (6 digits correct)

'''
1430AD, Al-Khowarizimi a Persian scholar broke the record with a 16 digits Pi.

1540AD, Ludolph Van Ceulen, a German-Dutch fencing and mathematics teacher
spent most of his lifetime computing Pi using Archimedes method.
He broke the records including his own many times. 
The 35 digits Pi was engraved on his tombstone.
            3.14159265358979323846264338327950288
        https://en.wikipedia.org/wiki/Ludolph_van_Ceulen
The tombstone was destroyed in WWII, but restored in 2000.
In Germany, Pi is sometimes referred as 'Ludolphine number' (loo-dolph-ine).

By the 16th century, most mathematicians realized that to be immortal
(at least in math textbooks) by breaking Pi record with Archimedes method
they must live a life like Mr.Ludolph.

Then someone invented a new game.
Instead of Pi approximation by fraction or formulas, they defined a serie
for Pi and repeatedly compute until an acceptable value is found.

1592AD, Francois Viete kicked off with:
  Pi = 2 * (2/sqrt(2)) * (2/sqrt(2+sqrt(2))) * (2/sqrt(2+sqrt(2+sqrt(2)))) * ...
'''
def viete(n):           ## To repeat n rounds.
    s, t = 2.0, 0.0
    for i in range(2, n+2):
        t = math.sqrt(2+t)
        s *= 2/t
    return s
# print(viete(10))       ## 3.1415914215112
## Just 10 rounds the result is correct to 5 digits, but needs sqrt().

''' 1616AD, John Wallis simplified the serie:
      Pi/2 = (2*2)/(1*3) * (4*4)/(3*5) * (6*6)/(5*7) * ....  '''
def wallis(n):
    s = 1.0
    for i in range(1, n+1):
        s *= ((2.0*i)*(2.0*i))/((2.0*i-1)*(2.0*i+1))
    return 2*s
# print(wallis(1000))    ## 3.140807746030402
## The serie is simpler but gets 2 digits correct after 1000 rounds.

''' The performance is not a matter, it is the beauty that counted.
1646AD, Leibniz propsed a surprisingly beautiful serie.
      pi = 4(1 - 1/3 + 1/5 - 1/7 ....)   '''
def leibniz(n):
    s = 0
    for i in range(1, n+1):
        t = 1 / (2*i - 1)
        if i % 2 == 0:
            s += -t
        else:
            s += t
    return 4*s
# print(leibniz(1000))        ## 3.140592653839794
## But 1000 rounds get just 2 digits correct.

''' Euler The Great would not miss the train.
1707AD, Euler gave one of the most beautiful and recognized serie.
      pi**2 = 6(1 + 1/2**2 + 1/3**2 + 1/4**2 +...)   '''
def euler(n):
    s = 0
    for i in range(1, n+1):
        s += 1/(i*i)
    return math.sqrt(6*s)
# print(euler(1000))          ## 3.1406380562059946
## 1000 rounds and 2 digits correct.
## It was clear that the serie race was just math ego.

''' 1761AD, Johann Heinrich Lambert proved that Pi is 'irrational' that means:
 - The value that can not be represented as a fraction of integers.
 - The decimal digits continues forever without repeating fixed pattern.
Therefore no exact value of Pi and no approximation is good enough.
That ends the hunting for Pi approximation with fractions.

1882AD, Ferdinand von Lindemann and Karl Weierstrass proved that Pi is
also 'transcendental' which means it cannot be the solution(root) of
any polynomial equation with integer coefficients.
In simple words, Pi cannot be computed by a polynomial.
That why it must be approximated with series.

Pi exact value has no places in real world applications at all.
22/7 is good mostly.
But Pi was a major divine force that pushed mathmatic boundary every now
and then for many thousand years.

Since the computer era, Pi is a big playground for programers
There are a lot of algorithms for computing Pi.
'''
## Quick Pi: Algorithm that produces high precision Pi with less iterations.
def quick_pi(n):
    a = 1
    b = 1 / math.sqrt(2)
    c = 1 / 4
    x = 1
    for i in range(n):
        y = a
        a = (a + b) / 2
        b = math.sqrt(b*y)
        c -= x * ((a-y) ** 2)
        x *= 2
    return ((a+b)**2) / (4*c)
## 3 rounds and 14 digits correct.
# print(quick_pi(3))            ## 3.141592653589794

''' David Bailey, Peter Borwein and Simon Plouffe proposed a formula:
  pi = sum(n=0,inf)( 4/(8*n+1) - 2/(8*n+4) - 1/(8*n+5) - 1/(8*n+6) ) / 16**n
Repeating n iterations would increase the precision.
'''
def dps_pi(n):
    s = 0.0
    for i in range(n):      
        i8 = 8*i
        s += (4.0/(i8+1) - 2.0/(i8+4) - 1.0/(i8+5) - 1.0/(i8+6)) / 16**i
    return s
# print(dps_pi(10)); print(math.pi)

## 1000 points Pi: No human had ever computed to this precision.
from decimal import Decimal, getcontext
def dps_1000pi(n):
    getcontext().prec = 1000
    d4 = Decimal(4.0)
    d2 = Decimal(2.0)
    d1 = Decimal(1.0)
    s = Decimal(0.0)
    for i in range(n):
        i8 = Decimal(8*i)
        s += (d4/(i8+1) - d2/(i8 +4) - d1/(i8+5) - d1/(i8+6)) / 16**i 
    return s
# print(dps_1000pi(825))

###################################################################

'''                    The Holy Pi
The Old Testament Bible mentions that KIng Solomon ordered to
create a bronze pot:
    "...Also he made a molten sea of ten cubits from brim to brim in
    compass and five cubits the height thereof and a line of thirty cubits
    did compass it round about. ..."
In simple english, the pot has diameter 10 units(cubits), height 5 units
and circumference 30 units. Therefore ...
                  The Bible Pi is 30/10 = 3

500AD, A christian clergy declared that Pi is 3 even.
Any disagree one must meed The God face-to-face immediately.
The church would gladly provides a free public 'BBQ' ceremony.

Bible is truer than the truth.
Between those no-use mathematicians and The Holy God, what would you believe. 
So Pi was 3.0 for more than a millennium (1000 years).

18th century, A Poland priest was assigned to solve the case.
The wise guy reinterpreted The Bible with a context sensitive technique
and recomputed the Bible Pi to be 3 * (111/106) = 3.1415094339622645.
It was correct up to 4 decimal points, what's a miracle!



                         The American Pi
1897AD, Indiana USA, Mr.Edwin Goodwin M.D.(a medical doctor) proposed
"A Bill Introducing a New Mathematical Truth" to The House of Indiana
State Legislature.
It described a geometry theorem that results a PI is
                16 / sqrt(3) = 9.2376…    the world PI record!
To celebrate the great achievement, his allowed all Indiana students
to use his Pi for free, the rest must pay royalty.
For unknown reason, Feb 15,1897 The House of Indiana State Legislature
pass the bill by 67 to 0!, God bless America.
But the second round of the bill consideration postponed the bill.
And had never been reconsidered or mentioned since then.
'''

