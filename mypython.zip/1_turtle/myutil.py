import turtle

## Set the wondows size, default is (546, 460).
turtle.setup(width=800, height=500)
# print(turtle.window_width(), turtle.window_height())

t = turtle.Pen()

## Option: Define the drawing speed.
t.speed(0)    ## More value is faster. (0 is max speed).

## Move the turtle to (x, y) without tracks.  
def move_to(x, y):
    t.up(); t.goto(x, y); t.down()

## Define a list of built-in colors.
colors = ['red', 'green', 'blue', 'orange', 'yellow', 'purple', 'pink',
          'brown', 'grey', 'violet', 'gold', 'navy', 'lime', 'maroon',
          'olive', 'teal', 'silver']
csize = len(colors)