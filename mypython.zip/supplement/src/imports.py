''' A 'module' is a .py file that contains utility, 
which can be 'imported' to be used in others .py files.
'''
from functions import hello, hi
hello('John')
hi('Jack')
