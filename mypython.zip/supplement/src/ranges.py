''' range() is a function that generates a sequence of integers.
	range(<start>, <stop>, <step>)

<start> is optional, default = 0.
<stop> is required.
<step> is optional, default = 1.
  if <step> = -1 reverese sequence.
  if <stop> = -1, <step> = -1 reverese sequence, include zero.
'''
print([x for x in range(5)])    ## [0, 1, 2, 3, 4]
print([x for x in range(1,5)])  ## [1, 2, 3, 4]
print([x for x in range(2,10, 2)])  ## [2, 4, 6, 8]
print([x for x in range(5, 0, -1)]) ## [5, 4, 3, 2, 1]
print([x for x in range(5,-1, -1)]) ## [5, 4, 3, 2, 1, 0]

## Range to list
## Ex. A list of positive even number under 10.
# print(list(range(0, 10, 2)))    ## [0, 2, 4, 6, 8]

## There are built-in function for range.
r = range(100)
# print(sum(r), min(r), max(r))      ## 4950 0 99

## Check if a number in a range.
# print(3 in r)     ## False