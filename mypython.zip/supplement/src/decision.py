''' 'Decision' is a mechanism to decide what to do.

    1.       if <condition>:
                 <body>
<body> is executed if <condition> is True.
Each condition case need a ':' to open a new scope.

x = 1
if x == 1:
    print('One')
'''
'''
    2.       if <condition>:
                 <true body>
             else:
                 <else body>
<true body> is executed if <condition> is True,
<else body> is executed.

x = 0
if x == 0:
    print('Zero')
else:
    print('Non-zero')
'''
'''         
    3.       if <condition 1>:
                 <condition 1 body>
             elif <condition 2>::
                 <condition 2 body>
              ......
             else:
                  <else body>
'elif' avoids extra block between else and if.

x = 3
if x <= 0:
    print('Nothing')
elif x == 1:
    print('One')
elif x < 4:
    print('Few')
else:
    print('Many')
'''