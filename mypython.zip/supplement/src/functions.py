''' 'Function' is block of statements with a name.
	 def <function name>(<parameter>):
                <body>
A function must be called to be executed.
It can be used as many times as needed without code duplication.
It can hide complex execution under the function name.
'''

def hello(name):
    print('Hello', name)

def hi(name):
    print('Hi', name)

def add(a, b):
    return a + b

# hello('John')
# hi('Jack')
# print(add(1, 2))