import random
## Random float in 0.0 -> 1.0.
# print([random.random() for _ in range(3)])
    ## [0.03869528441469461, 0.14942668805683035, 0.7273976478245782]

## Random int in min -> max.
# print([random.randint(1, 10) for _ in range(10)])
    ## [7, 3, 10, 6, 9, 1, 6, 7, 9, 5]

## Random int in range with step e.g. even numbers 0 -> 10.
# print([random.randrange(0, 10, 2) for _ in range(10)])
    ## [0, 2, 0, 0, 6, 6, 4, 2, 8, 2]

## (Uuniform) Random float in a range.
# print([random.uniform(10, 20) for _ in range(3)])
    ## [10.131351231483087, 18.30230465849145, 14.54018834876939]
#-----------------------

## Randomly pick one.
fruits = ["apple", "orange", "mango"]
# print([random.choice(fruits) for _ in range(5)])
    ## ['orange', 'apple', 'apple', 'mango', 'orange']

## Randomly pick k items (with replacement).
# print([random.choices(fruits, k=2) for _ in range(3)])
    ## [['mango', 'apple'], ['orange', 'mango'], ['orange', 'orange']]

## Randomly pick multiple unique items.
numbers = [1, 2, 3, 4, 5]
# print([random.sample(numbers, 3) for _ in range(5)])
    ## [[4, 5, 2], [4, 5, 1], [5, 4, 3], [3, 1, 5], [5, 3, 4]]

## Randomly shuffle a list (an operation with side-effect).
def shuffle_ex():
    for _ in range(3):
        random.shuffle(numbers)  ## [1, 5, 2, 4, 3]
        print(numbers)           ## [4, 5, 2, 1, 3]
# shuffle_ex()                   ## [3, 1, 4, 2, 5]  