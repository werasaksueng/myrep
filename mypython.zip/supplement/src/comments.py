''' 'comments' are text in source code that are ignored by compiler
and will not be executed.
Python comments:
   - A single line, # to the end of line.
   - Block comment, enclosed in a triple quotes (may be ''' or """).
For our convention:  #  is for experiment.
		     ## is for permanent documents.
'''
# print('Hello')
## print('Hi')