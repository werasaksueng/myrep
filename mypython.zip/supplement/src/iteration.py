''' 'Iteration' is a mechanism to repeat executions.
	for <item> in <iterable>:
		<body>

<iterable> is a genrator (e.g. range()) that produces <item> one at a time.
<body> will be executed for each <item> in an iteration.
'''
for i in range(3):
    print('Hello', i)
#-------------------------------------------------

''' 'for' is a statement.
'comprehension' is an expression.
    [ <expression> for <item> in <iterable> if <condition> ]

Ex. To compute squares of i where i is even and less than 10.
'''
# print([i**2 for i in range(1, 10) if i % 2 == 0]) 
## [4, 16, 36, 64]
