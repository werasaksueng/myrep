import javafx.application.Application;
import javafx.scene.Scene;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;
import javafx.scene.layout.StackPane;
import javafx.scene.control.Button;
import javafx.scene.layout.HBox;
import javafx.scene.layout.VBox;
import javafx.stage.Stage;
import javafx.geometry.Pos;

public class ClientFx extends Application {
	@Override
	public void start(Stage stage) {
		TextField itf = new TextField();
		TextField ntf = new TextField();
		TextField gtf = new TextField();
		HBox box1 = new HBox(10, new Label("Id"), itf);
		HBox box2 = new HBox(10, new Label("Name"), ntf);
		HBox box3 = new HBox(10, new Label("Gpa"), gtf);
		Button bt = new Button("Send");
		bt.setOnAction(event -> {
			int id  = Integer.parseInt(itf.getText().trim());
            		String name = ntf.getText().trim();
			float gpa  = Float.parseFloat(gtf.getText().trim());
            		Student s = new Student(id, name, gpa);
			System.out.println(s);
			Student.send(s);
        	});

		VBox vbox = new VBox(10, box1, box2, box3, bt);
        	vbox.setStyle("-fx-padding: 20; -fx-alignment: center;");


     		StackPane root = new StackPane();
        	// vbox.setAlignment(Pos.CENTER);

	        Scene scene = new Scene(vbox, 300, 200);
        	stage.setScene(scene);
       		stage.show();
    	}
	public static void main(String[] args) {
		launch(args); 
	}
}
