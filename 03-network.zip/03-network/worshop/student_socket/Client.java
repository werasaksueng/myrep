class Client {
	public static void main(String args[]) {
		Student s = Student.read();
		System.out.println(s);
		Student.send(s);
	}
}
