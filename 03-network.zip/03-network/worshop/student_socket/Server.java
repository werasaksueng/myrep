import java.io.*;
import java.net.*;

class MyServerThread extends Thread {
	private Socket sk;
	MyServerThread(Socket sk) { this.sk = sk; }
	public void run() {
		try (InputStream is = sk.getInputStream(); 
		     ObjectInputStream ois = new ObjectInputStream(is); ){
			Student s = (Student) ois.readObject();
			System.out.println(s);
		} catch(Exception e) {
			System.out.println(e);
		}
	}
}
class Server {
	public static void main(String args[]) throws Exception {
		ServerSocket ss = new ServerSocket(12345);
		System.out.println("Server is created.");
		while (true) {
			new MyServerThread(ss.accept()).start();
			if (Thread.interrupted())
				break;
		}
		ss.close();
	}
}
