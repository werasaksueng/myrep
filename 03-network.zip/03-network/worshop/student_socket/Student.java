import java.io.*;
import java.util.Scanner;
import java.net.Socket;

/* A transient object is supposed to be read only and 
 used for carrying data for a short period od tme. */
public class Student implements Serializable {
	private int id; private String name; private float gpa;
	public Student(int id, String name, float gpa) {
		this.id = id; this.name = name; this.gpa = gpa;   
	}
	public int getId() { return this.id; }
	public String getName() { return this.name; }
	public float getGpa() { return this.gpa; }
	public String toString() {
		return String.format("Id: %d, Name: %s, Gpa: %.2f", 
				this.id, this.name, this.gpa);
	}

	public static Student read() {
		// No error handling for simplicity.
		Scanner sc = new Scanner(System.in);
		System.out.print("Enter id, name, gpa: ");
        	String line = sc.nextLine();
		String a[] = line.split(",");
		int id = Integer.parseInt(a[0].trim());
		String name = a[1].trim();
		float gpa = Float.parseFloat(a[2].trim());
		return new Student(id, name, gpa);
	}

	public static void send(Student s) {
		try( Socket sk = new Socket("localhost", 12345);
		     OutputStream os = sk.getOutputStream();
		     ObjectOutputStream oos = new ObjectOutputStream(os);
		) {
			oos.writeObject(s);
		} catch (Exception e) {
			System.out.println(e);
		}
		System.out.println("Send success.");
	}
}