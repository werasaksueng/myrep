class Test {
	public static void main(String args[]) {
		Student s = Student.read();
		int id = s.getId();
		String name = s.getName();
		float gpa = s.getGpa();
		System.out.println(id + ", " + name + ", " + gpa);
	}
}