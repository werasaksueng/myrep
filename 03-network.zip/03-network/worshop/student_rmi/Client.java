import java.net.MalformedURLException;
import java.rmi.*;
class Client {
	public static void main(String args[]) throws RemoteException, NotBoundException, MalformedURLException {
		StudentRmi sr = (StudentRmi) Naming.lookup("rmi://localhost/StudentServer");  // 1099
		System.out.println(sr.get(Integer.parseInt(args[0])));
	}
}
