import java.rmi.Remote;
import java.rmi.RemoteException;
public interface StudentRmi extends Remote {
	public Student get(int id) throws RemoteException;
}