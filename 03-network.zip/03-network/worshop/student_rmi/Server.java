import java.rmi.*;
import java.rmi.server.UnicastRemoteObject;
import java.net.MalformedURLException;
class StudentImpl extends UnicastRemoteObject implements StudentRmi {
	public StudentImpl() throws RemoteException {}
	public Student get(int id) throws RemoteException {
		System.out.println("Get: " + id);
		return StudentDS.get(id);
	}
}
class Server {
	public static void main(String args[]) throws RemoteException, MalformedURLException {
		Naming.rebind("rmi://localhost/StudentServer", new StudentImpl());
		System.out.println("Server ready.");
	}
}
// start rmiregistry