import java.io.*;
import java.net.*;
class Send {
	public static String send(int _id) throws Exception {
		String req = "http://localhost:12345/student";
		URL url = new URL(req);
		HttpURLConnection c = (HttpURLConnection) url.openConnection();
		c.setDoOutput(true); c.setDoInput(true);
		c.setRequestMethod("POST");
		c.connect();
		OutputStream os = c.getOutputStream();
		PrintStream op = new PrintStream(os);
		op.println(_id);

		BufferedReader in = new BufferedReader(
				new InputStreamReader(c.getInputStream()));
		String line;
		StringBuilder res = new StringBuilder();
		while ((line = in.readLine()) != null)
			res.append(line);
		in.close();
		return res.toString();
	}
}
class Client {
	public static void main(String[] args) throws Exception {
		System.out.println(Send.send(2));
	}
}