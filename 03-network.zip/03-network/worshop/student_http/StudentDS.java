///// Student Datasource
import java.util.*;
public class StudentDS {
    static Student[] students = {
		new Student(1, "John", 1.8f),
		new Student(2, "Jack", 4.0f),
		new Student(3, "Joe", 3.4f),
		new Student(4, "Jame", 2.1f) };
    static Map<Integer, Student> studentMap = new HashMap<>();
    static {
        try {
            for (Student s : students)
                studentMap.put(s.getId(), s);                
        } catch(Exception ex) {
            System.out.println(ex);
        }
	}
    public static Student get(int id) {
        return studentMap.get(id);
    }

    public static void main(String[] args) throws Exception {
        System.out.println(StudentDS.get(1));
    }
}
