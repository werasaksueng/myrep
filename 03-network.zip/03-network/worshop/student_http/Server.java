import java.util.*;
import java.net.*;
import java.io.*;
import com.sun.net.httpserver.*;
class MyHandler implements HttpHandler {
	public void handle(HttpExchange he) throws IOException {
        InputStream is = he.getRequestBody();
		BufferedReader br = new BufferedReader(new InputStreamReader(is));
        String sid = br.readLine().trim();
        System.out.println("Get student id: " + sid);
		int _id = Integer.parseInt(sid);
        Student s = StudentDS.get(_id);
		String res = s.getName() + ": " + s.getGpa();

		he.sendResponseHeaders(200, res.length());
		OutputStream os = he.getResponseBody();
		os.write(res.getBytes());
		os.close();
	}
}
class Server {
	public static void main(String[] args) throws Exception {
        HttpServer hs = HttpServer.create(new InetSocketAddress(12345), 1);
		hs.createContext("/student", new MyHandler());
		hs.start();
		System.out.println("Server ready.");
    }
}
// curl localhost:12345/student -X POST -d 1 

