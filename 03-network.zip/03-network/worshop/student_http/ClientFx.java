import javafx.application.Application;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.layout.*;
import javafx.stage.Stage;

public class ClientFx extends Application {
    @Override
    public void start(Stage stage) {
        TextField idtf = new TextField();
        HBox box1 = new HBox(10, new Label("Student Id"), idtf);
        Button bt = new Button("Send");
        Label lb = new Label();
        bt.setOnAction(event -> {
            try {
                int _id = Integer.parseInt(idtf.getText());
                String res = Send.send(_id);
                lb.setText(res);
                idtf.clear(); // Clear the input field
            } catch(Exception ex) {
                System.out.println(ex);
            }
        });

        VBox vbox = new VBox(10, box1, bt, lb);
        vbox.setStyle("-fx-padding: 20; -fx-alignment: center;");

        // Create a scene and display the stage
        Scene scene = new Scene(vbox, 400, 200);
        stage.setTitle("Student Client");
        stage.setScene(scene);
        stage.show();
    }

    public static void main(String[] args) {
        launch(args);
    }
}
