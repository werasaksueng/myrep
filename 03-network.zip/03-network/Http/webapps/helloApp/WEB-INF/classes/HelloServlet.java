import java.io.*;
import javax.servlet.http.*;
import javax.servlet.annotation.WebServlet;
@WebServlet("/HelloServlet")
public class HelloServlet extends HttpServlet {
	public void doGet(HttpServletRequest req, HttpServletResponse res) throws IOException {
		String name = req.getParameter("name");
		System.out.println(name);
		PrintWriter pw = res.getWriter();
		pw.println("Hello! " + name + " That was a GET.");
		pw.close();
	}
}
