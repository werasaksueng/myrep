import org.apache.http.HttpEntity;
import org.apache.http.client.HttpClient;
import org.apache.http.client.methods.HttpGet;
import org.apache.http.impl.client.DefaultHttpClient;
import org.apache.http.util.EntityUtils;
class Client {
	public final static void main(String[] args) throws Exception {
		HttpClient hc = new DefaultHttpClient();
		HttpGet hg = new HttpGet("http://localhost:8080/helloApp/HelloServlet?name=Jack");
		HttpEntity he = hc.execute(hg).getEntity();
		System.out.println(EntityUtils.toString(he));
	}
}