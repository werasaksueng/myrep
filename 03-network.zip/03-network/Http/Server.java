import java.io.*;
import java.net.*;
import java.io.*;
class Server {
	public static void main(String args[]) throws IOException {
		ServerSocket ss = new ServerSocket(8080);
		System.out.println("Server created.");
		while (true) {
			(new MyHttpThread(ss.accept())).start();
			if (Thread.interrupted()) {
				ss.close();
				break;
			}
		}
	}
}
class MyHttpThread extends Thread {
	Socket s;
	MyHttpThread(Socket s) { 
		this.s = s;
		System.out.println("Connection from: " + s.getInetAddress());
	}
	public void run() {
		try {
			BufferedReader br = new BufferedReader(new InputStreamReader(s.getInputStream()));
			PrintStream ps = new PrintStream(s.getOutputStream());
			String r = br.readLine();
			if (r.indexOf("GET / ") != -1) {
				byte b[] = FileUtil.readFile("./pages/index.html");
				ps.print("HTTP/1.1 200 OK\r\n");
				ps.print("Content-length: "+ b.length + "\r\n");
				ps.print("Content-type: text/html\r\n\r\n");
				ps.write(b);
			}
			br.close(); ps.close(); s.close();
		} catch(IOException e) {
			System.out.println(e);
		}
	}
}

