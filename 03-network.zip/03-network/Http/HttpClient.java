import java.io.*;
import java.net.*;
class HttpClient {
    public static void main(String[] args) throws Exception {
	String req = "http://localhost:8080/helloApp/HelloServlet?name=john";
        URL url = new URL(req);
        HttpURLConnection c = (HttpURLConnection) url.openConnection();
        c.setRequestMethod("GET");
        BufferedReader in = new BufferedReader(
			new InputStreamReader(c.getInputStream()));
        String line;
        StringBuilder res = new StringBuilder();
        while ((line = in.readLine()) != null)
                    res.append(line);
        in.close();
	System.out.println(res.toString());
    }
}