import java.net.MalformedURLException;
import java.net.URL;
class URLTest {
	public static void main(String[] args) {
		try {
			URL u = new URL("http://www.mycomp.com/hello.html");
			// URL u = new URL("http", "www.mycomp.com", "/hello.html");
			// URL u = new URL("http", "www.mycomp.com", 8080, "/myapp/hello.html?a=1&b=2");
			System.out.println(u);
			System.out.println(u.getProtocol());
			System.out.println(u.getHost());
			System.out.println(u.getPort());
			System.out.println(u.getPath());
			System.out.println(u.getQuery());
		} catch (MalformedURLException e) {
			System.out.println(e);
		}
	}
}
