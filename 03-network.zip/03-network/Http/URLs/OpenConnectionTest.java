import java.io.*;
import java.net.*;
import java.util.*;
class OpenConnectionTest {
	public static void main(String[] args) throws Exception {
 		URL u = new URL("http://localhost:8080/tomcat.gif");
 		
		URLConnection c = u.openConnection();
		System.out.println("Content-type: " + c.getContentType());
		System.out.println("Content-length: " + c.getContentLength());
		System.out.println("Content-encoding: " + c.getContentEncoding());
		System.out.println("Date: " + new Date(c.getDate()));
		System.out.println("Expiration date: " + new Date(c.getExpiration()));
		System.out.println("Last modified: " + new Date(c.getLastModified()));
		
		c.connect();
		InputStream is = c.getInputStream();
		int n = 0;
		byte b[] = new byte[1024];
		FileOutputStream fo = new FileOutputStream("t.gif");
		while ((n = is.read(b)) != -1)	
			fo.write(b, 0, n);
		
		fo.close(); is.close();
	}
}
