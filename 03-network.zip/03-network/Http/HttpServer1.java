import java.net.*;
import java.io.*;
class HttpServer1 {
	public static void main(String args[]) throws Exception {
		ServerSocket ss = new ServerSocket(8080);
		Socket s = ss.accept();
		InputStreamReader ir = new InputStreamReader(s.getInputStream());
		BufferedReader br = new BufferedReader(ir);
		String l ;
		while ((l = br.readLine()) != null)
			System.out.println(l);
	}
}
// http://localhost:8080
