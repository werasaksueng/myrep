import java.net.*;
import java.io.*;
// We can use ServerSocket to create http server.
class HttpServer2 {
    static class MyThread extends Thread {
        Socket s;
        MyThread(Socket s) { this.s = s; }
        public void run() {
            try {
                BufferedReader br = new BufferedReader(new InputStreamReader(s.getInputStream()));
                PrintStream ps = new PrintStream(s.getOutputStream());
                String r = br.readLine();
                String file = (r.startsWith("GET / "))? "pages/index.html" :
                                (r.startsWith("GET /hello "))? "pages/hello.html" : null;
                byte b[] = FileUtil.readFile(file);
                ps.print("HTTP/1.1 200 OK\r\n");
                ps.print("Content-length: " + b.length + "\r\n");
                ps.print("Content-type: text/html\r\n\r\n");
                ps.write(b);
                br.close(); ps.close(); s.close();
            } catch (IOException e) {
            }
        }
    }

    public static void main(String args[]) throws IOException {
        ServerSocket ss = new ServerSocket(8080);
        System.out.println("Server created.");
        while (true)
            (new MyThread(ss.accept())).start();
    }
}
// http://localhost:8080
// http://localhost:8080/hello
