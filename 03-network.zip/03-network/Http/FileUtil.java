import java.io.*;
class FileUtil {
	public static byte [] readFile(String fname) {
		try (FileInputStream fis = new FileInputStream(fname);) {
			int n = fis.available();
			byte [] b = new byte[n];
			fis.read(b, 0, n);
			return b;
		} catch(Exception ex) {
			System.out.println(ex);
		}
		return null;
	}
}
