import com.sun.net.httpserver.*;
import java.net.*;
import java.io.*;
// Jdk provides HttpServer a ready to use emmbedded http server.
class JdkHttp {
	public static void main(String args[]) throws Exception {
		HttpServer hs = HttpServer.create(new InetSocketAddress(8080), 1);
		hs.createContext("/", new MyHandler());
		hs.start();
		System.out.println("Server ready.");
	}
}
class MyHandler implements HttpHandler {
	public void handle(HttpExchange he) throws IOException {
		String res = "Hello! I am JdkHttp Server.";
		he.sendResponseHeaders(200, res.length());
		OutputStream os = he.getResponseBody();
		os.write(res.getBytes());
		os.close();
	}
}



