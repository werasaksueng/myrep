package server;
import java.net.MalformedURLException;
import java.rmi.Naming;
import java.rmi.RemoteException;
public class HelloServer {
	public static void main(String args[]) throws RemoteException, MalformedURLException {
		Naming.rebind("rmi://localhost/HelloServer", new HelloImpl());
		System.out.println("HelloServer ready.");
	}
}
/* For older Java a security policy must be provided.
java -Djava.security.policy=policy.txt Client john

Alternatively: Set policy at
	%JAVA_HOME%\jre\lib\security\java.policy   */
