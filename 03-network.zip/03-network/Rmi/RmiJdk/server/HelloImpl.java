package server;
import java.rmi.*;
import java.rmi.server.UnicastRemoteObject;
import shared.Hello;
public class HelloImpl extends UnicastRemoteObject implements Hello {
	public HelloImpl() throws RemoteException {}
	public String greet(String s) throws RemoteException {
		System.out.println("Activation form: " + s);
		return "Hello! " + s + " I am HelloImpl.";
	}
}