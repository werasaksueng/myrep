import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import mybeans.Hello;

class Client {
	public static void main(String[] args) throws Exception {
		ApplicationContext bf = new ClassPathXmlApplicationContext(
					"beans.xml");
		
		Hello h = (Hello) bf.getBean("hello");
		System.out.println(h.greet("Joe"));
	}
}