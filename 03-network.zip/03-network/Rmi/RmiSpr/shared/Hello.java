package shared;
public interface Hello {
	public String greet(String s);
}