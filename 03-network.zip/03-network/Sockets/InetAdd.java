import java.net.InetAddress;
import java.net.UnknownHostException;
import java.util.Arrays;

class InetAdd {
	public static void main(String[] args) throws UnknownHostException {

		System.out.println("getLocalHost:");
		InetAddress a1 = InetAddress.getLocalHost();
		System.out.println("name: " + a1.getHostName());
		System.out.println("IP: " + a1.getHostAddress() + "\n");

		System.out.println("getByName:");
		String name = InetAddress.getLocalHost().getHostName();
		InetAddress a2 = InetAddress.getByName(name);
		System.out.println(a2.getHostAddress() + "\n");

		System.out.println("getAllByName:");
		InetAddress[] aa = InetAddress.getAllByName("google.com");
		for (InetAddress a : aa)
			System.out.print(a.getHostAddress() + ", ");
		System.out.println("\n");

		System.out.println("getByAddress:");
		InetAddress c = InetAddress.getLocalHost();
		byte b[] = c.getAddress();
		System.out.println(Arrays.toString(b));
		InetAddress a3 = InetAddress.getByAddress(b);
		System.out.println(a3.getHostName() + "\n");
	}
}
