import java.net.*;
class DgClient {
	public static void main(String args[]) throws Exception {
		int port = 12345;
		
		byte hostIp[] = {(byte)127, (byte)0, (byte)0, (byte)1};
		InetAddress hostInet = InetAddress.getByAddress(hostIp);
		
		byte msg[] = "Hello I am John Rambo.".getBytes();
		
		DatagramPacket dp = new DatagramPacket(msg, msg.length, hostInet, port);
		DatagramSocket ds = new DatagramSocket();
		ds.send(dp);
		ds.close();
		System.out.println("Send packet.");
	}
}
