import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.io.PrintStream;
import java.net.Socket;
class HelloClient {
	public static void main(String args[]) throws Exception {
		Socket s = new Socket("localhost", 12346);
		PrintStream op = new PrintStream(s.getOutputStream());
		op.println("John");
		BufferedReader br = new BufferedReader(
			new InputStreamReader (s.getInputStream()));
		System.out.println(br.readLine());

		br.close(); 
		s.close();
	}
}
