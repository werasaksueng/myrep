import java.io.IOException;
import java.net.InetAddress;
import java.net.Socket;

class PortProbe {
	private static void probe(InetAddress ia, int i) {
		try ( Socket s = new Socket(ia, i);
		) {
			System.out.print(i + ", ");
		} catch(IOException e) {
			// The server does not open this port. 
		}
	}
	public static void main(String args[]) {
		// probe Tomcat at localhost
		try {
			for (int i = 12340; i <= 12350; i++)
				probe(InetAddress.getLocalHost(), i);
		} catch (Exception e) {
			System.out.println(e);
		}
		System.out.println("Finish.");
	}
}
// netstat -a


// Try: Probe Tomcat 8080
