import java.net.*;
class DgServer {
	public static void main(String args[]) throws Exception {
		DatagramSocket ds = new DatagramSocket(12345);
		System.out.println("Server created.");
		while(true) {
			DatagramPacket dp = new DatagramPacket(new byte[100], 100);
			ds.receive(dp);
			
			String header = "\nFrom Host: " + dp.getAddress() +
							"\nLength: " + dp.getLength();
			System.out.println(header);
		
			String msg = new String(dp.getData()).trim();
			System.out.println(msg);
			
			if (Thread.interrupted())
				break;
		}
		ds.close();
	}
}
